
# Aerospace Engineering, MS
 </br>

- Educational Objectives for Graduate Program</br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- MS - Aerospace Engineering Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MSAE Program, offered by the Department of Aerospace Engineering , is designed to prepare students for professional careers in industry or advanced study in Ph.D. programs. Students develop skills in research, design, development, experiment design, testing, and systems integration in air and space transportation systems. In addition to advanced aerospace engineering courses, electives are available in science, business, and other engineering fields. Class schedules are designed for the convenience of employed engineers who wish to pursue graduate work on a part-time basis. The MSAE Program welcomes students with undergraduate degrees in other engineering or science disciplines. For more information visit the MS Aerospace Engineering website.</br>

## Educational Objectives for Graduate Program
To provide MSAE graduates with</br>

- A strong foundation beyond the undergraduate level in their chosen focus area as well as in mathematics, basic science, and engineering fundamentals, to be able to solve current aerospace engineering problems.</br>

- Contemporary professional and lifelong learning skills to successfully compete for technical engineering positions in the local, national, and global engineering market, advance in their current position or pursue doctoral studies.</br>

- Expertise necessary to work in the analysis, design, development, and testing of aerospace engineering systems with possible specialization in areas such as aircraft design or space transportation and exploration.</br>

- Strong verbal and written communication skills, including the ability to write engineering reports.</br>

- Ability to perform research and work independently to solve open-ended aerospace engineering problems.</br>


## Admissions Requirements
Candidates must meet all the university admission requirements . Students can be admitted in either classified or conditionally classified standing. If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the conditions will include taking preparatory courses to meet these requirements. Such courses will not count as part of the master’s degree program requirements.</br>
To be admitted to classified standing, a student must possess a BS degree in Aerospace Engineering or related field (e.g., Aeronautical Engineering, Astronautical Engineering or Space Engineering, etc.) from an accredited institution with a grade point average of 2.75 or better in the last 60 units.</br>
Students may be admitted with conditionally classified standing if they have a BS degree in any engineering or science discipline from an accredited institution. Students with conditionally classified standing will take a series of BS Aerospace Engineering core courses based on their evaluation by the AE Graduate Coordinator.</br>
If an applicant’s bachelor’s degree is not from a US or Canadian university, a GRE must be taken; minimum scores acceptable for admission are listed on the Graduate Program Test Requirements webpage. Applicants from countries in which the native language is not English must achieve a minimum English-Language Proficiency (ELP) test score as indicated on the Graduate Program Test Requirements webpage.</br>

## Requirements for Advancement to Graduate Candidacy
Prior to registering for the first time (or upon re-entering), a student should consult with the AE Graduate Coordinator to develop a schedule of courses. Students admitted as conditionally classified must satisfy the requirements listed in their letter of acceptance. Students who have completed matriculation and achieved classified standing in the master’s degree curriculum must next advance to candidacy for the degree. A student may advance to candidacy after completing a minimum of 9 units of graded work as a graduate student in letter-graded 100- or 200-level courses acceptable to the AE Department, as well as fulfilling the other university requirements for advancement to candidacy  for the MS degree, detailed in the Graduate Policies & Procedures  section. Candidacy includes the successful completion of the  Graduation Writing Assessment Requirement (GWAR) .</br>
Requirements for Graduation</br>

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies & Procedures . </br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## MS - Aerospace Engineering Graduation Requirements
The AE Department offers courses designed to provide a flexible curriculum structure that allows students to follow a course of study to meet their individual career goals. As shown below, the program consists of 30 semester units of approved work, including 6 units devoted to a thesis or project. The required coursework includes 3 units of advanced mathematics, 12 units of aerospace core subjects, and 9 units of electives.</br>
In selecting a project/thesis topic, the student must first identify a faculty member in his or her area of interest. Once the faculty member agrees to act as the student’s project/thesis advisor, a program of study is established, including the project/thesis topic.</br>

### Culminating Experience (Plan A or Plan B)
In selecting a Plan A (Thesis) or Plan B (Project) topic, the student must first identify a faculty member in his / her area of interest. Once the faculty member agrees to act as the student’s advisor, a program of study is established, including the thesis or project topic. In either option students perform graduate-level research and/or design and/ or development, involving aerospace systems or components of aerospace systems under the supervision of an AE faculty member. Students are encouraged to submit and present their work at student and/or professional conferences.</br>
A project or thesis proposal is due to the AE 295A / AE 299  Course Coordinator no later than the 2nd week of class. A written progress report is due at the end of each month. The first progress report must include a review of the relevant literature. An end-of-semester written report is expected at the end of the 1st semester.</br>
Plan A (Thesis)</br>
A thesis requires approval by a committee of three members. Two of the thesis committee members must be SJSU faculty. An AE faculty member must agree to serve as the chair of the committee. Students must secure the commitment of all three members of their thesis committee. The committee must approve the student’s thesis proposal no later than the 2nd week of the 1st semester. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the other committee members. The candidate for the MSAE degree must successfully pass a final oral defense of the thesis.</br>
Plan B (Project)</br>
In the Project Option students work under the supervision of an AE faculty member.</br>

## Master’s Requirements (30 units)

### Advanced Mathematics (3 units)

- AE 200 - Engineering Analysis of Aerospace Systems 3 unit(s)</br>


### Core Courses (12 units)
Complete at least one course from each of the four areas described below.</br>

#### Propulsion (3 units)
Students who have completed AE 167  or equivalent at the undergraduate level and are completing the Aircraft Design specialization may complete an additional graduate-level elective (3 units) in lieu of AE 267 . Students completing the Space Transportation and Exploration specialization must complete AE 267 .</br>

- AE 267 - Space Propulsion Systems 3 unit(s)</br>


#### Dynamics and Control (3 units)

- AE 242 - Orbital Mechanics and Mission Design 3 unit(s)</br>

- AE 243 - Advanced Astrodynamics 3 unit(s)</br>

- AE 245 - Spacecraft Dynamics and Control 3 unit(s)</br>

- AE 246 - Advanced Aircraft Stability and Control 3 unit(s)</br>

- AE 247 - Trajectory Optimization in Aerospace Applications 3 unit(s)</br>


#### Structures and Materials (3 units)

- AE 250 - Advanced Structures and Materials 3 unit(s)</br>

- AE 251 - Structural Vibrations for Aerospace Applications 3 unit(s)</br>


#### Fluid Dynamics (3 units)

- AE 262 - Advanced Aerodynamics 3 unit(s)</br>

- AE 264 - Gas Dynamics 3 unit(s)</br>

- AE 265 - Boundary Layers 3 unit(s)</br>

- AE 266 - Hypersonics 3 unit(s)</br>

- AE 269 - Advanced Computational Fluid Dynamics 3 unit(s)</br>


### Area of Specialization/Approved Electives (9 units)
Complete three electives from one of the specialization areas below in consultation with the AE Graduate Coordinator. Students electing not to complete an area of specialization must complete one GWAR Course (AE 210 , AE 271  or AE 273 ) and select two additional (100-level or 200-level) elective courses in consultation with the AE Graduate Coordinator.  </br>

#### Aircraft Design (9 units)
Complete either AE 271  or AE 273  and an additional 2 courses from below for a total of 9 units.</br>

- AE 246 - Advanced Aircraft Stability and Control 3 unit(s)</br>

- AE 247 - Trajectory Optimization in Aerospace Applications 3 unit(s)</br>

- AE 250 - Advanced Structures and Materials 3 unit(s)</br>

- AE 251 - Structural Vibrations for Aerospace Applications 3 unit(s)</br>

- AE 262 - Advanced Aerodynamics 3 unit(s)</br>

- AE 264 - Gas Dynamics 3 unit(s)</br>

- AE 265 - Boundary Layers 3 unit(s)</br>

- AE 266 - Hypersonics 3 unit(s)</br>

- AE 269 - Advanced Computational Fluid Dynamics 3 unit(s)</br>

- AE 271 - Advanced Aircraft Design 3 unit(s) (GWAR)</br>

- AE 273 - Aircraft Subsystems 3 unit(s) (GWAR)</br>


#### Space Transportation and Exploration (9 units)
Complete AE 210  and an additional 2 courses from below for a total of 9 units.</br>

- AE 210 - Advanced Space Systems Engineering 3 unit(s) (GWAR)</br>

- AE 242 - Orbital Mechanics and Mission Design 3 unit(s)</br>

- AE 243 - Advanced Astrodynamics 3 unit(s)</br>

- AE 245 - Spacecraft Dynamics and Control 3 unit(s)</br>

- AE 247 - Trajectory Optimization in Aerospace Applications 3 unit(s)</br>

- AE 250 - Advanced Structures and Materials 3 unit(s)</br>

- AE 251 - Structural Vibrations for Aerospace Applications 3 unit(s)</br>

- AE 264 - Gas Dynamics 3 unit(s)</br>

- AE 265 - Boundary Layers 3 unit(s)</br>

- AE 266 - Hypersonics 3 unit(s)</br>

- AE 269 - Advanced Computational Fluid Dynamics 3 unit(s)</br>


## Culminating Experience (6 units)
Complete one option (Plan A or Plan B):</br>

### Plan A (Thesis)

- AE 299 - Aerospace Engineering Masters Thesis 3 unit(s) (Students take AE 299  twice.)</br>


### Plan B (Project)

- AE 295A - Aerospace Engineering Masters Project I 3 unit(s)</br>

- AE 295B - Aerospace Engineering Masters Project II 3 unit(s)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the AE Graduate Coordinator. Students may also choose electives from other engineering fields, science, or business.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>