
# Justice Studies, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

The Department of Justice Studies  at San José State University offers a full-time two-year or part-time three-year Master’s program drawing upon criminology, criminal justice, sociology, political science, psychology, law, and history.</br>
Areas of teaching and research in the Department include theory, policing, law and society, human rights, policy evaluation, juvenile justice, immigration, punishment & society, race theory, history, and forensic science.</br>
The Master’s program prepares students for careers in criminal justice settings, public institutions, grassroots community organizations, and nonprofit agencies, as well as for doctoral programs and research positions in public agencies.</br>
More information is available on the Department of Justice Studies website.</br>

## Admission Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the MS, Justice Studies program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL requirements, see English Language Proficiency Requirement  .</br>

### Admission to the Program
To be considered for admission to the Justice Studies Department, applicants must complete the university admission requirements , as well as have a minimum grade point average of 3.0 in the last 60 units of university course work. Admission decisions will be based on a weighted assessment of the applicant’s grade point average, course work and preparation, two letters of recommendation from academics, and a short essay on a justice-related topic chosen each year by the Justice Studies graduate committee (see department website for further information).</br>

### Admission in Conditionally Classified Standing
Applicants meeting the university’s requirements for the Graduate Division but lacking experience in research methods in the social sciences may, at the department’s discretion, be required to take one or two classes to prepare them for the degree. These students may be admitted under conditionally classified standing. The individual admission notification will explain the required terms and conditions for attaining Classified standing.</br>

## Requirements for Advancement to Candidacy
For advancement to candidacy for the Master of Science degree in Justice Studies, students must meet the general university requirements for advancement to candidacy  outlined in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>
Advancement to Candidacy requires the following:</br>

- Classified standing</br>

- Completion of 9 units of core or required courses with a grade point average of 3.0 (“B”) or better</br>

- Completion of the GWAR</br>

Once advanced to candidacy, the student should meet with the department graduate coordinator to draft an approved plan of study. This program must identify 33 units of course work as outlined in the following list of course requirements.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . </br>

### Completing Requirements for the MS - Justice Studies
Course Requirements</br>
Each student must complete a core curriculum of 18 units (JS 201 , JS 202 , JS 203 , JS 207 , JS 211  and JS 220 ), 9 units of elective courses, and master’s thesis or project as their 6-unit culminating experience. The thesis option requires six units of JS 299 ; the project option requires completion of JS 297 and an additional 3-unit elective. Elective courses must be 200-level courses in the department. Subject to graduate coordinator approval, two graduate courses in other departments on campus may be taken as electives, if the student demonstrates their relevance to the student’s program of study and/or career goals in Justice Studies. Undergraduate courses may not count toward the 33 units of required graduate course work. Students who are academically or administratively disqualified from the program will generally not be readmitted.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students select one of the following options for their culminating experience. Students should choose the option that best suits their particular interests and goals.</br>
Plan A (with Thesis)</br>
Plan A provides an advanced program of study for those who are primarily interested in conducting research, and pursuing advanced study toward the doctorate. The Plan A is a 6-unit thesis option designed to provide opportunities for in-depth investigation in the student’s area of emphasis. The thesis will include original research on a topic approved by the thesis committee and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. The student and the thesis committee chair, with approval by the graduate coordinator, determine the thesis requirements and timelines. Approval by the graduate coordinator and thesis committee and a “B” average in the core coursework is required before a student can register for JS 299  (3 units). Students interested in this option must also submit a brief written statement to the graduate coordinator describing their research interests and expertise, and receive permission from the graduate coordinator.</br>
Plan B (Project)</br>
The Plan B option provides an advanced program of study for professionals and those who want to pursue careers in justice studies fields. It requires a 3-unit research project that is conducted with the rigor appropriate to graduate work. Its culminating experience is a substantial, original paper on a specific research topic and an associated poster presentation evaluated by a faculty panel comprised of all members of the Justice Studies graduate committee. Individual projects are agreed to by the graduate student and JS 297  academic advisor and require the approval of the Graduate Coordinator. Students choosing this option must take an additional 3-unit elective and enroll in JS 297  during their final semester.</br>

## Master’s Requirements (33 units)

### Core Courses (18 units)

- JS 201 - Justice and Social Theory 3 unit(s) (GWAR)</br>

- JS 202 - Survey of Research Methods 3 unit(s)</br>

- JS 203 - Seminar in Applied Statistics in Justice 3 unit(s)</br>

- JS 207 - Seminar in Qualitative Research Methods 3 unit(s)</br>

- JS 211 - Historical Issues in Justice Studies 3 unit(s)</br>

- JS 220 - Seminar: Criminological Theory 3 unit(s)</br>


### Electives (9 units)

- JS 204 - Justice Organizations, Ethics & Change 3 unit(s)</br>

- JS 205 - Seminar in Law and Courts 3 unit(s)</br>

- JS 206 - Seminar in Juvenile Justice 3 unit(s)</br>

- JS 208 - Seminar: Punishment & Society 3 unit(s)</br>

- JS 209 - Seminar in Police and Social Control 3 unit(s)</br>

- JS 212 - Local & Global Perspectives on Human Rights 3 unit(s)</br>

- JS 214 - Seminar: Social Movement, Community Organizing, and Social Justice 3 unit(s)</br>

- JS 218 - Seminar: Immigration, Law & Justice 3 unit(s)</br>

- JS 221 - Seminar: Deviance & Social Control 3 unit(s)</br>

- JS 223 - Seminar: Comparative Criminology & Criminal Justice 3 unit(s)</br>

- JS 281 - Justice Practicum 1-3 unit(s)</br>

- JS 298 - Special Study 1-3 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan A (with Thesis)

- JS 299 - Master’s Thesis 3-6 unit(s) (6 units required)</br>


#### Plan B (Project)

- JS 297 - Program Evaluation Project 3 unit(s)</br>

- Additional 3 units electives 3 unit(s)</br>


## Total Units Required (33 units)
Elective courses must be planned in consultation with the graduate advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>