
# Spanish, MA
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Program Requirements</br>

- Master’s Requirements (32 units)</br>

- Program Learning Outcomes  </br>

The Master of Arts Degree in Spanish offers students the opportunity to pursue studies in Hispanic literature, linguistics, and culture. The program prepares students for doctoral studies and for careers in the teaching of Spanish, bilingual education, international business, social and governmental services, and other related areas.</br>
More information can be found on the Department of World Languages and Literatures  website: www.sjsu.edu/wll.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the MA, Spanish degree program. See the GAPE Graduate Admissions website and this Catalog for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English Language Proficiency Exam (ELP) score as indicated on the Graduate Program Test Requirements webpage.</br>

### Requirements for Admission to Classified Standing
Minimum requirements for admission to the Graduate Division are outlined in this catalog. In order to be admitted to classified standing in the MA program in Spanish, students should possess the following:</br>

- A bachelor’s degree (or its equivalent, as assessed by the department), with a major in Spanish, and including at least 16 units of upper-division work in the major with a grade of “B” or better.</br>

- Evidence of college-level proficiency in Spanish.</br>


### Requirements for Admission to Conditionally Classified Standing
A student may be admitted to conditionally classified standing if he or she meets minimum requirements for admission to the Graduate Division but does not fully meet requirements for Classified admission to the MA, Spanish program. The individual admission notification will explain the required terms and conditions for attaining Classified standing.</br>

## Requirements for Advancement to Candidacy
Advancement to candidacy requires favorable action by both the departmental graduate committee and the university graduate committee. All applicants meet institutional requirements as set forth in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

### Graduation Writing Assessment Requirement
Students must pass the Graduation Writing Assessment Requirement (GWAR) . </br>

### Culminating Experience
Each candidate for the master’s degree must successfully complete a final comprehensive written examination.</br>

## Program Requirements
The minimum program for a Master of Arts in Spanish degree includes the following:</br>

- The 32 unit program for a Master of Spanish requires at least 20 semester units of 200-level courses. Included in these 32 units, students must take FORL 200W , which satisfies the Graduation Writing Assessment Requirement (GWAR) .</br>

- Up to 12 units of approved upper-division (100-level) courses not used to meet a requirement for the BA degree in Spanish at San José State University may be taken in the Graduate Division to complete the minimum 32-unit program.</br>

- Final comprehensive examination conducted in Spanish.</br>

- Demonstration of competence in written English. </br>


## Master’s Requirements (32 units)

### Required Courses (20 units)

- FORL 200W - Graduate Research & Writing 4 unit(s) (GWAR)</br>


#### Complete 16 units:

- SPAN 201 - Modern Spanish 4 unit(s)</br>

- SPAN 202 - Seminar in Hispanic Civilization and Culture 4 unit(s)</br>

- SPAN 220 - Historical Spanish Linguistics 4 unit(s)</br>

- SPAN 225 - Spanish Dialectology 4 unit(s)</br>

- SPAN 250 - Seminar in the Siglo de Oro 4 unit(s)</br>

- SPAN 260A - Hispanic Culture 4 unit(s)</br>

- SPAN 260B - Hispanic Linguistics 4 unit(s)</br>

- SPAN 260C - Hispanic Literature 4 unit(s)</br>

- SPAN 270 - Seminar in Contemporary Literature of Spain and Spanish America 4 unit(s)</br>

- SPAN 298 - Special Study 1-6 unit(s)</br>


### Electives (12 units)
A maximum of 12 units may be taken from the following:</br>
Elective courses must be planned in consultation with the Graduate Advisor.</br>

- SPAN 111 - Advanced Spanish Conversation 4 unit(s)</br>

- SPAN 120A - Spanish Literature I 4 unit(s)</br>

- SPAN 120B - Spanish Literature II 4 unit(s)</br>

- SPAN 132 - Special Topics in Spanish for Careers 4 unit(s)</br>

- SPAN 140A - Spanish American Literature 4 unit(s)</br>

- SPAN 140B - Spanish American Literature II 4 unit(s)</br>

- SPAN 160A - Hispanic Culture 4 unit(s)</br>

- SPAN 160B - Hispanic Linguistics 4 unit(s)</br>

- SPAN 160C - Hispanic Literature 4 unit(s)</br>

- SPAN 170 - Spanish Translation: Theory and Practice 4 unit(s)</br>


### Culminating Experience
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan B (Comprehensive Exam)

## Total Units Required (32 units)
Elective courses must be planned in consultation with the Graduate Advisor. Undergraduate courses required as prerequisites do not count towards the MA degree.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 12.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>