
# History, MA
 </br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- University Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

While designed to strengthen students’ depth and breadth of historical knowledge, the MA in History requires those who study the past at an advanced level to move beyond the acquisition of content knowledge and develop the more complex skills and habits of mind associated with historiography-including synthesis, analysis, and evaluation. This course of study serves those preparing to teach history at community colleges, those seeking preparation for the doctorate, museum curators, historical archivists, historians working in governmental agencies, and secondary teachers choosing a traditional Master’s degree.</br>

## Requirements for Admission to Classified Standing
Prospective students must apply separately to the university to obtain approval for graduate-level admission and to the department to obtain admission into the MA in History program. Applicants must meet all the university admission requirements  as outlined in this catalog and stated in subsequent policy changes (this refers both to admission and graduation procedures). Students can be admitted in either classified or conditionally classified standing. Admission to classified standing for the MA - History requires that the undergraduate preparation of the applicant be comparable to that of the BA degree  at San José State University. This preparation must include one upper-division or graduate course in historical method and a course in historiography. The applicant who does not have this preparation must remove all deficiencies after admission to the program. Students who have a baccalaureate degree in a field other than history will be required to complete up to 8 units in upper-division or graduate history courses. Units thus taken will not be counted toward the minimum 30 units required for the MA - History. Requirements and policies change; please refer to the Department of History  website for the most current information.</br>

## Requirements for Admission to Conditionally Classified Standing
A student who does not meet all requirements for admission in classified standing for the MA - History may be admitted in conditionally classified status. The graduate advisor will list on the admissions notification all deficiencies and courses that must be taken while in the program. </br>

## University Requirements
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . Courses that satisfy the GWAR are listed in the course requirements for the program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirement  webpage.</br>

## Requirements for Advancement to Candidacy
At least one semester before a candidate expects to graduate, the student must complete the Petition for Advancement to Graduate Candidacy form delineating the entire degree program, that is, the courses that the student has completed or expects to complete toward the Master’s. The candidate must submit the form to the Graduate Advisor and then to GAPE for final approval. Through this procedure, the student’s entire program will be examined to determine whether it complies with all departmental and university requirements for the degree, including the university requirement for demonstrated competency in written English.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Department Graduation Requirements
Following admission to the university and the department, the student should consult the history department website and speak with the graduate advisor regarding degree requirements and a proposed degree program. Candidates must complete 20 units of course work in one of the following fields of study: United States History, European History or World History. Eight units may be taken in any field of history. Two units will focus on professional development. Specialists in European History and United States History may apply one World History Colloquium (HIST 220 ) to their primary field, and World History specialists may apply one U.S. History Colloquium (HIST 210A ) or one European History Colloquium (HIST 209  or HIST 211 ) to their primary field. Five courses and the 2 units of professional development –a total of 22 units– must be completed at the graduate level. All students must maintain a 3.0 GPA average to remain in the program and either pass the comprehensive examination or complete a thesis to receive the degree.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan B (Comprehensive Examination)</br>
In addition to the course of study outlined above, graduate students must take and pass a comprehensive examination (Plan B). On the exam, the student is expected to demonstrate considerable breadth and depth of knowledge, a familiarity with historiographical issues, and adherence to acceptable rules of grammar, spelling and literary style in presentation. The examination will be scheduled toward the end of the fall and spring semesters, and students must pass the examination within three attempts or no degree will be awarded.</br>
Plan A (Thesis)</br>
In some exceptional cases, students may substitute a thesis (Plan A) for the comprehensive examination. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. A thesis option will be considered only upon the nomination of a professor, who agrees to serve as the first reader. The student must demonstrate to the nominating professor, in a written proposal, that he or she is capable of completing a thesis, both in terms of research skills and writing ability, and that he or she has sufficient time to undertake a major research and writing project. In addition, the proposed project must have intrinsic historical value. Demonstrating these points does not obligate a professor to nominate or to serve as a first reader, and no reason need be given to a student for declining to supervise a thesis. Permission to write a thesis is also contingent on finding two other professors willing to serve as second and third readers; they also serve entirely at their own discretion. Finally, the department’s graduate studies committee must approve all thesis proposals. After all three readers have signed the thesis, the candidate must submit it to the University for final approval.</br>
A thesis committee has the option of terminating the thesis option if the candidate does not submit an acceptable thesis within five semesters. In that situation, the student will be required to take the Plan B comprehensive examination as the program culminating experience.</br>
Language Requirement</br>
All candidates for general MA in History must demonstrate competency in one foreign language. The sole exception are students whose primary field is U.S. History, who may, if they do not wish to meet the language requirement, take two history graduate-level courses in substitution.</br>
The language competency requirement may be met in four ways:</br>

- Through examination by a history faculty member with expertise in your language. The exam will be a translation of approximately 500 words to be completed in two hours with a hard-copy dictionary allowed.</br>

- By taking two years of a foreign language at a university or community college. An average grade of “C” or better must have been attained, and the coursework completed within five years of admission to the university.</br>

- If your primary concentration is European History, you may also fulfill this requirement by taking one year of Greek and one year of Latin.</br>

- By taking and passing the Educational Testing Service Graduate Foreign Language Exam.</br>


## Master’s Requirements (30 units)

### Professional Development (2 units)

- HIST 298 - Special Study 1-6 unit(s) (Should be completed during student’s first semester)</br>


### Colloquia (8-12 units)

#### European History Primary Field (8 units)
HIST 209  and HIST 211  may be repeated for credit</br>

- HIST 209 - Colloquium in Ancient and Medieval Europe 4 unit(s) (GWAR)</br>

- HIST 211 - Advanced Colloquium in Modern Europe 4 unit(s) (GWAR)</br>


#### United States History Primary Field (12 units)

- HIST 210A - Advanced Colloquium United States History 4 unit(s)</br>

- HIST 210B - Advanced Colloquium United States History 4 unit(s) (GWAR)</br>

- HIST 210C - Advanced Colloquium United States History 4 unit(s)</br>


#### World History Primary Field (8 units)

- HIST 220 - Advanced Colloquium in World History 4 unit(s) (HIST 220  may be repeated for credit)</br>


### Seminars (8 units)
Graduate or Upper Division courses selected in consultation with the Graduate Advisor.</br>

### Additional Graduate or Upper Division Courses (8-12 units)
Program departments are required to certify when the culminating experience has been completed satisfactorily via the Verification of Culminating Experience form.</br>

## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 8.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>