
# Biomedical Engineering, Biomedical Devices Concentration, MS
 </br>

- Requirements for Admission</br>

- Requirements for Candidacy</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The concentration in Biomedical Devices, offered by the Department of Biomedical Engineering , offers the student the opportunity to focus on the design, development, and manufacture of medical devices that either come into contact with the human body or are implanted within the human body. This concentration area has been created to provide individuals with B.S. degrees in an engineering field or chemistry or physics with the necessary graduate-level education that prepares them to function effectively in this environment.</br>

## Requirements for Admission
Applicants must meet all university admission requirements . Applicants who have a major GPA of 3.0 or higher are not required to take the GRE. All others must take the GRE General Test and obtain a combined score of 315 or higher in the Verbal and Quantitative sections, and 3.5 or higher in the Analytical Writing section.</br>
Students can be admitted to either classified or conditionally classified standing. To be admitted to classified standing, a student must possess a BS degree in biomedical engineering, or its equivalent from an accredited institution with a grade point average of 3.0 or better in the last 60 semester units, have met the GRE requirement if their major GPA is below 3.0, and have completed any required Transition Courses, or their equivalents, with grades of B or better.</br>

### Conditionally Classified Admission
Students can be admitted to conditionally classified standing if they have a BS degree in an engineering discipline, chemistry, physics, or biology from an accredited institution. Students with conditionally classified standing will take a series of Transition Courses, as determined by the Graduate Coordinator. Once the series is completed satisfactorily, with grades of B or better, students can petition for transfer to classified standing. For more information on the transition courses see the section on Transition Courses below, or, contact the Biomedical Engineering Department Graduate Coordinator at biomedical-engineering@sjsu.edu.</br>

## Advancement to Candidacy
Students must meet the university’s requirements for candidacy, which include classified standing and the successful completion of a minimum of 9 units of graduate-level classes with grades of B or better. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy .</br>

### Course Requirements
To meet the requirements for the MS, Biomedical Engineering degree, a student must complete 30 units of approved courses. Students must achieve a minimum grade of a “C” in each course, a cumulative GPA of 3.0 or better in all their coursework, AND a GPA of 3.0 or higher for the courses listed in the Candidacy form.</br>

#### Transition Courses
Students may be required to complete some or all of the following transition courses (or equivalent courses) prior to being admitted to Classified Standing in the major.</br>

- BME 65 - Biomedical Applications of Statics  3 unit(s)</br>

- BME 68 - Biomedical Applications of Metals and Ceramics  3 unit(s)</br>

- BME 115 - Foundations of Biomedical Engineering  4 unit(s)</br>

- BME 147 - Quantitative and Statistical Methods for Biomedical Engineers  3 unit(s)</br>

- BME 165 - Applied Engineering Biomechanics  3 unit(s)</br>

- CHEM 1A - General Chemistry  5 unit(s) (5A + 5C)</br>

- CHEM 1B - General Chemistry  5 unit(s) (5A + 5C)</br>

- EE 98 - Introduction to Circuit Analysis  3 unit(s)</br>

- MATH 33A - Ordinary Differential Equations for SCI & ENGR  3 unit(s)</br>

- MATH 33LA - Differential Equations and Linear Algebra  3 unit(s)</br>

- PHYS 50 - General Physics I: Mechanics  4 unit(s) (5A + 5C)</br>

- PHYS 51 - General Physics II: Electricity and Magnetism  4 unit(s) (5A + 5C)</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . The GWAR is satisfied with BME 274 , which is a core course.</br>

### Culminating Experience
Included in the 30 units of approved courses is the requirement that students must also complete a written thesis or project report and an oral defense of their thesis or project. The candidate may choose either the Plan A (thesis) or Plan B (project) option. For either option, the student is required to develop a project proposal in BME 291 . This must be approved by the student’s project adviser and the reading committee at the culmination of BME 291. Once the proposal is approved, the student is required to:</br>

- Implement the approved research plan using appropriate methods for the investigation</br>

- Use appropriate statistical techniques for analysis of the data and drawing conclusions</br>

- Discuss the results in light of findings reported by other investigators</br>

- Write a professional report of appropriate length</br>

- Present it and defend the project to the reading committee</br>

Plan A (Thesis)</br>
Please see the “Plan A (Thesis)” description under the requirements for the Biomedical Engineering, MS  degree.</br>
Plan B (Project)</br>
Please see the “Plan A (Thesis)” description under the requirements for the Biomedical Engineering, MS  degree.</br>

## Master’s Requirements (30 units)

### Core Courses (18 units)

- BME 207 - Experimental Methods in BME 3 unit(s)</br>

- BME 210 - Mathematical Methods in Biomedical Engineering 3 unit(s)</br>

- BME 272 - Biomedical Device Design and Principles 3 unit(s)</br>

- BME 274 - Regulatory, Clinical and Manufacturing Aspects of Medical Devices 3 unit(s)</br>

- (GWAR)</br>

(GWAR)</br>

- BME 276 - Project Management in Biomedical Technologies 3 unit(s)</br>

- BME 291 - MS Thesis/Project Preparation Seminar 3 unit(s)</br>


### Concentration Requirements (6 units)

- BME 168 - Medical and Biological Polymers 3 unit(s)</br>

- BME 254 - Microscale Biomedical Systems: Physics and Applications 3 unit(s)</br>


### Electives (0-3 units)
Complete 0-3 units:</br>

- BME 217 - Experimental and Computational Biofluid Mechanics 3 unit(s)</br>

- BME 254 - Microscale Biomedical Systems: Physics and Applications 3 unit(s)</br>

- BME 256 - Biomedical Applications of Nanoplatforms 3 unit(s)</br>

- BME 258 - Medical Imaging for Engineers 3 unit(s)</br>

- BME 280 - Graduate Research Studies 1-3 unit(s)</br>

- BME 288 - Tissue Engineering 3 unit(s)</br>


### Culminating Experience (3-6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan A (Thesis Option) (6 units)

- BME 298 - MS Project 3 unit(s)</br>

- BME 299 - MS Thesis 3 unit(s)</br>


#### Plan B (Project Option) (3 units)

- BME 298 - MS Project 3 unit(s)</br>


## Total Units Required (30 units)
 </br>