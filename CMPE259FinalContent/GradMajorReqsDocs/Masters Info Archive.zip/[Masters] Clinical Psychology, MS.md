
# Clinical Psychology, MS
 </br>

- Admission Requirements</br>

- Degree Requirements</br>

- Master’s Requirements (60 units)</br>

- Program Learning Outcomes    </br>

The Master of Science (MS) degree in Clinical Psychology, offered by the Department of Psychology , is designed to provide the student with both theoretical and practical training in the assessment, diagnosis, and treatment of a wide variety of individual (adult and children), couples’, and family mental health problems, and to prepare the student to work in private or public service agencies, independent practice, community mental health centers, or hospitals. The program values and emphasizes evidence-based practice of psychotherapy. The required academic course work and supervised fieldwork of 60 semester units meets the course work requirements for the California State Marriage and Family Therapist (MFT) license (see www.bbs.ca.gov for requirements). An additional 2500-3000 post-degree hours of acceptable supervised experience is required for admission to the state MFT licensing examination.</br>

## Admission Requirements
To be eligible for admission into the Clinical Psychology program, you must:</br>

- Meet all of the University graduate admission requirements .</br>

- Have a baccalaureate degree (BA or BS) in Psychology OR any baccalaureate degree (BA or BS) and a minimum of 30 semester units (45 quarter units) in Psychology.</br>

- Have taken the REQUIRED six courses in psychology from the list provided below. These are to be included in the minimum 30 semester units (10 semester courses).</br>

- Have a minimum GPA of 3.0 in all Psychology coursework AND a minimum of 3.0 the last 2 years of academic work attempted (60 semester or 90 quarter units).</br>

- Provide evidence of a minimum of 100 hours of paid or volunteer applied clinical experience working with persons in a counseling/helping capacity (e.g. provide counseling on a suicide and crisis telephone hotline).</br>

- Provide three letters of recommendation. One reference MUST be from a clinical supervisor and another MUST come from a professor or instructor who can comment on the applicant’s academic work. Additional references may come from former instructors and from supervisors of previous work in volunteer placements in the clinical field.</br>


### Undergraduate Courses in Psychology Required for Admission

- General or Introduction to Psychology (SJSU code PSYC 1 )</br>

- Elementary Statistics (SJSU code STAT 95 )</br>

- Introduction to Research Methods (SJSU code PSYC 18  or PSYC 118  or PSYC 120 )</br>

- Psychobiology or equivalent (SJSU code PSYC 30 )</br>

Each of the above four (1-4) may be taken at the community college or university level and may be lower-division courses.</br>

- Upper-division course in Abnormal Psychology (SJSU code PSYC 110 )</br>

- Upper-division course in Theory and Methods of Counseling, or Clinical Psychology (SJSU code PSYC 160 , or PSYC 165 )</br>


## Degree Requirements
General university requirements and procedures for completing the Master of Science degree are described in the Academic Regulations section of this catalog . In addition to these, the following departmental requirements must be fulfilled.</br>

- The student must complete a total of 60 units in clinical psychology as specified in the table below.</br>

- Candidates must demonstrate satisfactory performance on one or more final comprehensive examinations. These examinations are both written and oral.</br>

- The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . Courses that satisfy the GWAR are listed in the course requirements for the program.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
The culminating experience for the Clinical Psychology program is a comprehensive (“comp”) exam completed in two phases. The first phase is the written portion, and the second is the oral portion. The written portion of the second-year comp evidences the student’s conceptualization, treatment development, and professional and ethical delivery of therapy for a specific client while on fieldwork placement. This written portion is evaluated by two faculty members and scored according to the criteria provided in the MS Clinical Student Handbook. If and when students pass the minimum criteria for the written portion, they advance to the oral portion of the comp.</br>
The oral portion provides time for students to briefly present the same case that was described in the written portion, to interact with other students about each other’s cases, and to field questions about their cases from faculty member examiners. The oral portion is scored according to the criteria provided in the MS Clinical Student Handbook.</br>

## Master’s Requirements (60 units)

### Core Courses (48 units)

- PSYC 203 - Clinical Assessment 3 unit(s) (GWAR)</br>

- PSYC 208 - Family Assessment and Intervention 3 unit(s)</br>

- PSYC 209 - Psychology of Contemporary Families 3 unit(s)</br>

- PSYC 210 - Advanced Psychopathology 3 unit(s)</br>

- PSYC 211 - Child Psychopathology 3 unit(s)</br>

- PSYC 212 - Lifespan Development 3 unit(s)</br>

- PSYC 222 - Multiculturalism, Ethnicity and Gender in Psychotherapy 3 unit(s)</br>

- PSYC 224A - Clinical Psychology Practicum I 3 unit(s)</br>

- PSYC 224B - Clinical Psychology Practicum II 3 unit(s)</br>

- PSYC 225 - Advanced Group Dynamics 3 unit(s)</br>

- PSYC 226 - Addictions and Treatment 3 unit(s)</br>

- PSYC 228 - Professional Ethics for Psychologists 3 unit(s)</br>

- PSYC 258 - Methods of Psychotherapy 3 unit(s)</br>

- PSYC 260 - Crisis and Trauma Counseling 3 unit(s)</br>

- PSYC 223 Multiculturalism and Diversity: Clinical Practice 3 unit(s)</br>

- PSYC 265 Advanced Conceptualization and Treatment Application 3 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Students will take PSYC 298  twice.</br>

- PSYC 298 - Special Problems 1-6 unit(s)</br>


### Field Work (6 units)

- PSYC 243 - Field Work in Psychology 3 unit(s)</br>


## Total Units Required (60 units)
 </br>