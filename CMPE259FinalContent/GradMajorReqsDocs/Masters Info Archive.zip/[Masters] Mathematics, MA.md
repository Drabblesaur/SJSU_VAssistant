
# Mathematics, MA
 </br>

- Requirements for Admission</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

This degree, offered by SJSU’s Department of Mathematics and Statistics  is recommended for future community college teachers and for students who plan to continue toward the PhD in mathematics.</br>

## Requirements for Admission
Candidates must meet all the university Graduate Admissions . Students can be admitted in either classified or conditionally classified standing. If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the conditions will include taking preparatory courses to meet these requirements. Such courses will not count as part of the master’s degree program requirements.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Classified Standing
To enter this program with classified standing, a student must meet the minimum requirements for admission to the Graduate Division, have completed 18 semester units of upper-division undergraduate mathematics with a GPA of at least 3.0, and have one to three letters of recommendation submitted on his or her behalf. The coursework must be acceptable toward a bachelor’s degree in mathematics and may not be counted toward the MA degree.</br>

### Conditionally Classified Standing
A student who meets the minimum requirements for admission to the Graduate Division but does not satisfy the mathematics coursework requirements stated above may be admitted as a conditionally classified student. Eligibility is determined on a case-by-case basis. The individual admission letter will explain the required terms and conditions for attaining classified standing. After arrival at SJSU, a conditionally admitted student must complete additional coursework to make up for the unit deficiency in order to achieve classified status. These make-up units will not be included in the MA degree unit requirement total.</br>

## Requirements for Advancement to Graduate Candidacy
To advance to candidacy  in the MA Mathematics, a student must meet the university candidacy requirements, as stated in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>
The student must complete the Petition for Advancement to Graduate Candidacy form. This form lists, among other things, all the coursework to be counted toward the master’s degree. After the form has been signed by the student’s thesis or writing project advisor (if applicable) and the Graduate Coordinator, it is forwarded to GAPE for final approval. Any subsequent changes to the student’s program require approval from GAPE.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
Students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Program Graduation Requirements

#### Culminating Experience
Students must choose one of three options: The Plan A (Thesis), Plan B (Project), or Plan B (Comprehensive Examination).</br>
Plan A (Thesis)</br>
A student who selects the Thesis option must find a willing tenured or tenure-track faculty member to serve as the thesis advisor, and complete a thesis under that advisor’s supervision. The thesis must be reviewed and approved by a committee composed of the advisor and two other faculty members chosen by the student in consultation with the advisor. The student must give a public presentation on the thesis, which is followed by an oral examination (defense) conducted by the committee. The thesis must be filed with the College of Graduate Studies, subject to the SJSU Master’s Thesis and Doctoral Dissertation Guidelines and deadlines established by that office.</br>
Thesis students must enroll in MATH 299  (3 units). Students receive credit when the thesis is completed, successfully defended, and all committee members have signed off on it. Students who do not complete their theses during the semester in which they are enrolled in MATH 299  will receive a grade of “RP” for that course. If all other degree requirements have been completed, students must subsequently enroll in MATH 1290R  in compliance with university regulations until the thesis is completed, defended, and approved by Graduate Studies.</br>
Plan B (Project)</br>
A student who selects the Project option must find a willing tenured or tenure-track faculty member to serve as the project advisor, and complete a written project under that advisor’s supervision. The project must be reviewed and approved by a committee composed of the advisor and two other faculty members chosen by the student in consultation with the advisor. The student must give a public presentation on the project, which is followed by an oral examination (defense) conducted by the committee.</br>
Students choosing the Plan B (Project) option must enroll in MATH 298  (3 units). Students receive credit when the writing project is completed, successfully defended, and all committee members have signed off on it. Students who do not complete their projects during the semester in which they are enrolled in MATH 298  will receive a grade of “RP” for that course. If all other degree requirements have been completed, students must subsequently sign up for MATH 1290R  in compliance with university regulations until the writing project is completed and defended.</br>
Plan B (Comprehensive Examination)</br>
Students who select this option must pass two written comprehensive examinations. One examination will be in Higher Algebra (MATH 221A  and MATH 221B ). The second exam will be in Analysis (MATH 231A  and MATH 231B ).</br>
Students choosing the Plan B (Comprehensive Exam) option must enroll in an additional elective (3 units) selected in consultation with the program graduate advisor. Students complete the program Culminating Experience when they pass both exams. Students who successfully complete all other program requirements but not one or both exams must subsequently enroll in MATH 1290R  for the following semester or semesters in compliance with the university requirement for continuous enrollment until both exams have been passed in one sitting.</br>

## Master’s Requirements (33 units)

### Core Courses (21 units)

- MATH 200W - Communication in the Mathematical Sciences 3 unit(s) (GWAR)</br>

- MATH 221A - Higher Algebra I 3 unit(s)</br>

- MATH 221B - Higher Algebra II 3 unit(s)</br>

- MATH 231A - Real Analysis 3 unit(s)</br>

- MATH 231B - Functional Analysis 3 unit(s)</br>


#### Complete Two Courses From:

- MATH 229 - Advanced Matrix Theory 3 unit(s)</br>

- MATH 238 - Advanced Complex Variables 3 unit(s)</br>

- MATH 275A - Topology 3 unit(s)</br>

- MATH 279A - Graph Theory 3 unit(s)</br>


### Electives (6 units)

- MATH 203 - Applied Mathematics, Computation, and Statistics Projects 3 unit(s)</br>

- MATH 226 - Theory of Numbers 3 unit(s)</br>

- MATH 229 - Advanced Matrix Theory 3 unit(s)</br>

- MATH 233A - Applied Mathematics I 3 unit(s)</br>

- MATH 234 - Advanced Dynamical Systems 3 unit(s)</br>

- MATH 238 - Advanced Complex Variables 3 unit(s)</br>

- MATH 243A - Numerical Solution of PDEs 3 unit(s)</br>

- MATH 243M - Numerical Linear Algebra 3 unit(s)</br>

- MATH 261A - Regression Theory and Methods 3 unit(s)</br>

- MATH 263 - Stochastic Processes 3 unit(s)</br>

- MATH 275A - Topology 3 unit(s)</br>

- MATH 279A - Graph Theory 3 unit(s)</br>

- MATH 279B - Advanced Graph Theory 3 unit(s)</br>

- MATH 285M - Advanced Topics in Pure Mathematics 3 unit(s)</br>

- MATH 297A - Preparation for Writing Project, Research Project or Thesis 3 unit(s)</br>


### Additional Electives (3 units)
Complete an additional 100-level or 200-level courses selected in consultation with MA Mathematics advisor. Elective courses may include a maximum of 3 units of MATH 280  and/or MATH 297A .</br>
Courses excluded: MATH 102 , MATH 105 , MATH 106 , MATH 287 .</br>

### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan A (Thesis)

- MATH 299 - Master’s Thesis 1-4 unit(s) (3 units required)</br>

- Oral Presentation</br>

- Oral Defense</br>


#### Plan B (Writing Project)

- MATH 298 - Special Study 1-4 unit(s) (3 units required)</br>

- Oral Presentation</br>

- Oral Defense</br>


#### Plan B (Comprehensive Exam)

- Additional 3-unit elective selected in consultation with graduate advisor</br>

- Comprehensive Exam</br>


## Total Units Required (33 units)
Elective courses must be planned in consultation with the MA Mathematics Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 6.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>