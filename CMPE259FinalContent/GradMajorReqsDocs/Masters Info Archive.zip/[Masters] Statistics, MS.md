
# Statistics, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (36 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Statistics prepares students to become practicing statisticians in business, government and industry fields. It features theoretical and applied coursework in statistics and advanced statistical techniques, and its skills-based coursework emphasizes writing and communication skills and provides students with practical project experience. The program was developed in concert with industry and is designed to dovetail into professional career opportunities.</br>
Persons with bachelor’s degrees in engineering, the sciences, economics, business, the social sciences or other fields that use statistics are encouraged to apply. Those with bachelor’s degrees in mathematics or statistics are welcome to apply for the program in order to advance their technical and theoretical skills.</br>
Information about MS Statistics is available on the Department of Mathematics and Statistics  website.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. See the Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the Policies and Procedures  section, Graduate and Post-Baccalaureate Information .</br>

### Requirements for Admission to Classified Standing
To enter this program with classified standing, an applicant must meet the minimum requirements for admission to the Graduate Division. Applicants must also have completed the following SJSU courses or their equivalents each with a grade of “B” or better (this coursework is not counted toward the MS degree):</br>

- A calculus series through multiple integration and partial differentiation (equivalent to the SJSU courses MATH 30 , MATH 31  and MATH 32 );</br>

- Linear algebra equivalent to MATH 39 ; and</br>

- Introductory calculus-based probability and statistics equivalent to MATH 161A .</br>

In addition, applicants must have two letters of recommendation submitted on their behalf.</br>

### Requirements for Admission to Conditionally Classified Standing
An applicant who meets the minimum requirements for admission to the Graduate Division but does not yet satisfy the mathematics and statistics coursework program requirements stated above may be admitted as Conditionally Classified. The student must complete additional coursework to make up the deficiency before beginning the program. The units earned from this additional coursework may not be counted towards the total number of units required for the MS degree. The individual admission letter will explain the required terms and conditions for attaining Classified standing.</br>

## Requirements for Advancement to Candidacy
To be advanced to candidacy for the MS Statistics degree:</br>

- A student must meet the candidacy requirements   as stated in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. The GWAR requirement is fulfilled by passing CS 200W  or MATH 200W .</br>

- Complete MATH 163  and MATH 164 , each with a grade of at least B.</br>

- Complete at least 18 units towards the degree with at least a 3.0 average.</br>

- Complete the Request for Candidacy and Graduate Degree Program form for the Master of Science degree. This form lists, among other things, all the coursework to be counted toward the master’s degree. After the form has been signed by the Graduate Coordinator, it is forwarded to the GAPE for final approval. Any subsequent changes to the student’s program require approval from GAPE.</br>


## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Program Graduation Requirements
Students in the MS Statistics program complete all courses in the program core, project experience or written exam, and culminating experience. Those choosing the Specialization in Machine Learning complete the electives MATH 251 , MATH 252 , and six units of additional electives selected in consultation with, and approved by, the Statistics Coordinator.</br>
All other students complete MATH 261B  and 9 units of electives selected in consultation with, and approved by, the Statistics Coordinator. The electives should form a coherent set of courses associated with the student’s career goals. They may include a maximum of 6 units of MATH 203 , MATH 288I , or MATH 298 . Although they may be repeated, each of the courses: MATH 203 , MATH 288I , MATH 297A , MATH 298 , may count at most once towards the degree. The maximum number of 100-level undergraduate units that can be applied toward the master’s degree is 12. The maximum number of units graded on a CR/NC basis that can be applied towards the degree is 12.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . This requirement in the MS Statistics program is satisfied by completing CS 200W  or MATH 200W .</br>

### Culminating Experience
Project or Comprehensive Exam</br>
Students in the MS Statistics either complete a project course (MATH 203 , MATH 288I , or MATH 298 ) or they take a comprehensive exam together with an extra elective course. In order for the project course or comprehensive exam to count towards the culminating experience, the student must have completed at least MATH 163  and MATH 164  (each with grade B or better) as well as MATH 261A  (with grade C or better) at the time they begin their project or take the exam. </br>

## Master’s Requirements (36 units)

### Core Courses (21 units)

- MATH 163 - Probability Theory 3 unit(s)</br>

- MATH 164 - Mathematical Statistics 3 unit(s)</br>

- MATH 167R - Statistical Programming with R 3 unit(s)</br>

- MATH 167PS - Introduction to Python Programming and SQL 3 unit(s)</br>

- MATH 250 - Mathematical Data Visualization 3 unit(s)</br>

- MATH 261A - Regression Theory and Methods 3 unit(s)</br>

- CS 200W Graduate Technical Writing  or  MATH 200W - Communication in the Mathematical Sciences 3 unit(s) (GWAR)</br>


### Electives or Specialization (12 units)
Complete 12 Units of Electives or the Specialization in Machine Learning. Specializations are a cluster of courses designed around a common theme and do not appear on transcripts or diplomas.</br>

#### Electives

- Students not pursuing a specialization take MATH 261B  and 9 units of electives selected in consultation with the graduate advisor 9 unit(s)</br>

- MATH 261B - Design and Analysis of Experiments 3 unit(s)</br>


#### Specialization in Machine Learning

- MATH 251 - Statistical and Machine Learning Classification 3 unit(s)</br>

- MATH 252 - Cluster Analysis 3 unit(s)</br>

- 

6 units of additional electives selected in consultation with, and approved by, the Statistics Coordinator. 6 units(s)
</br>
6 units of additional electives selected in consultation with, and approved by, the Statistics Coordinator. 6 units(s)</br>

### Culminating Experience (3 units)

#### Course Option
Complete one course from:</br>

- MATH 203 - Applied Mathematics, Computation, and Statistics Projects 3 unit(s)</br>

- MATH 288I - Statistics Internships 3 unit(s)</br>

- MATH 298 - Special Study 1-4 unit(s) (3 units required)</br>


#### Elective and Exam Option
One additional elective approved by the graduate advisor (3 units) and a comprehensive written exam on material from all of the following courses: MATH 163 - Probability Theory , MATH 164 - Mathematical Statistics , and MATH 261A - Regression Theory and Methods .</br>

## Total Units Required (36 units)
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>