
# Human Factors/Ergonomics, User Experience Concentration, MS
 </br>

- Admission Requirements</br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy for the MS - Human Factors/Ergonomics, Concentration in User Experience</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes    </br>

The Department of Industrial and Systems Engineering  (ISE) administers the Master of Science in Human Factors/Ergonomics (HF/E) degree program with a Concentration in User Experience (UX). This program provides students with competency in human computer interaction (UX) through their course work and culminating project and creates a recognizable employment credential on the MS diploma from the MS HF/E program accredited by the Human Factors and Ergonomics Society (HFES). Students take 3 core courses, 3 required courses, and 2 electives in topics of their choosing. A one-semester weekly seminar is required of all students. The program culminates in a thesis or project. Additional information can be found at the Human Factors/Ergonomics Program website.</br>

## Admission Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply portal and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the MS, Human Factors/Ergonomics program with User Experience Concentration. See the Graduate Admissions website and this Catalog  for general information about graduate admissions at SJSU. </br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the English Language Proficiency Requirement  section in this Catalog.</br>

## Requirements for Admission to Classified Standing
Applicants must meet all university admission requirements . Applicants who meet the following requirements beyond university requirements will be considered for admission into the ISE Department. Applicants for classified standing must have completed a BS or BA degree in Psychology, Engineering, Computer Science, Industrial Design, or other related field at an accredited institution. A grade point average of 3.0 (“B”) or better in the last two years of academic work is preferred. Applicants for classified standing will also be expected to have completed upper division courses in statistics, cognition, and perception.</br>

## Requirements for Admission to Conditionally Classified Standing
Applicants who do not meet the requirements for classified standing may be admitted with specific conditions as conditionally classified; any conditions stated in the admission notification must be fulfilled within the first year and before the student can be advanced to candidacy for the degree. If the conditions are not fulfilled, the program reserves the right to dismiss the student from the program by a process known as Administrative Academic Disqualification (see Section 41300.1, Title 5, California Code of Regulations).</br>

## Requirements for Advancement to Candidacy for the MS - Human Factors/Ergonomics, Concentration in User Experience
Students seeking the Master of Science degree in Human Factors/Ergonomics, Concentration in User Experience must meet the general all-university requirements for candidacy as outlined in the Academic Requirements section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Please refer to the SJSU catalog section titled “Graduation Writing Assessment Requirement” for details. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, the applicant must demonstrate aptitude for advanced professional work in human factors/ergonomics, as measured by instructor appraisals, analysis of previous academic work or other appropriate means. Advancement to candidacy and approval of programs will be handled by the student’s graduate advisor.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures.</br>

### Culminating Experience
Students choose the Plan A (Thesis) or Plan B (Project) option as their program culminating experience.  The decision as to whether to embark on a thesis or project will be made by the student in consultation with the program’s assigned advisor.</br>
Plan A (Thesis)</br>
Students wishing to pursue the thesis option must begin by obtaining the approval of the HF/E program Director, and then secure the agreement of a qualified faculty member to serve as Chair of the thesis committee. The candidate must provide the name of the committee Chair to the HF/E Program Director prior to the beginning work on the thesis. The thesis and thesis process must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines (pdf). The thesis will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
The project is the expected choice for the HF/E candidate’s culminating experience. Students must begin the project by identifying a qualified faculty advisor, or by having one appointed by the HF/E program Director. The advisor and the student mutually agree on the scope of the project. The advisor determines when the student has met agreed upon project requirements and when the project report is acceptable for submission to the HF/E program, and notifies the HF/E program Director of the student’s satisfactory completion of the culminating experience requirement.</br>

### Course Requirements
Students must maintain a GPA of 3.0 or above in all courses taken in fulfilling prerequisites and the 30 graduate units required for completion of the program. The general requirements for the course completion are as follows:</br>

## Master’s Requirements (30 units)

### Core Courses (8 units)

- ISE 210 - Human Factors/Ergonomics 3 unit(s)</br>

- ISE 212 - Human Factors Experiments 3 unit(s) (GWAR)</br>

- ISE 290 - Human Factors & Ergonomics Professional Seminar 2 unit(s)</br>


### Concentration Courses (12 units)

- ISE 215 - Usability Evaluation and Testing 3 unit(s)</br>

- ISE 217 - Human Computer Interaction 3 unit(s)</br>

- ISE 218 - Interaction Design I 3 unit(s)</br>

- ISE 220 - Interaction Design II 3 unit(s)</br>


### Approved Electives (6 units)
Elective courses must be planned in consultation with the graduate advisor.</br>

### Culminating Experience (4 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Plan A (Thesis) or Plan B (Project)</br>
Complete four units from:</br>

- ISE 298 - Special Problems 1-4 unit(s)</br>

- ISE 299 - Master’s Thesis 1-4 unit(s)</br>


## Total Units Required (30 units)
Two (2) elective courses must be planned in consultation with the Graduate Advisor. Electives may be selected from a wide range of graduate courses in industrial engineering, psychology, industrial design and other departments. Course descriptions can be found under the listings for the respective departments elsewhere in this catalog. The program develops and offers its own elective courses from time to time in topics such as usability testing, human-computer interaction, safety and others. Please see the program website for further details.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.  </br>
 </br>