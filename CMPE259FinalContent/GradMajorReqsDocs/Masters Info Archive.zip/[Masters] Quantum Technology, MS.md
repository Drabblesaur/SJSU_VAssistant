
# Quantum Technology, MS
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- ​Program Learning Outcomes  </br>

Quantum technologies exploit intricate quantum mechanical phenomena such as superposition and entanglement to obtain and process information in fundamentally new ways. ‘Quantum technology’ encompasses the fields of quantum computation, quantum sensing, and quantum communication, all of which are expected to revolutionize industrial computing technologies as well as pose new challenges and opportunities for national security and defense.</br>
The interdisciplinary MS in Quantum Technology program at SJSU brings together faculty from the College of Science and College of Engineering to train the next generation of engineers and scientists for the workforce and research needs of the Quantum Information Science & Engineering enterprise. The program offers a modern education in quantum science, including the fundamentals of quantum information science and hands-on quantum software and hardware laboratory courses. Research experiences are integrated into the curriculum via project-based learning and a culminating master’s thesis or research project. Students are trained in a broad set of skills across physics and engineering towards the convergent goal of becoming well-equipped for a career in quantum science and technology. The MS in Quantum Technology is jointly offered by the Department of Physics and Astronomy  and the Department of Electrical Engineering .</br>

## Admissions Requirements
Candidates must meet all of the university admission requirements . Students can be admitted in either classified or conditionally classified standing.</br>
Classified Standing: applicants must have earned a Bachelor’s degree in the sciences or engineering or other STEM discipline from an accredited institution with a minimum GPA of 3.0 (based on a 4.0 scale), and have completed classes in mechanics, linear algebra, electricity and magnetism, and computer programming or their equivalent.</br>
Conditionally Classified Standing: Conditional acceptance means that the candidate does not meet one or more of the above requirements and​ must fulfill additional specific requirements, such as completing additional coursework, in order to be eligible to apply for advancement to candidacy. These conditions will be stipulated as part of the acceptance agreement between the faculty adviser and the applicant.</br>
Applicant should submit a) a resume or curriculum vitae, b) 1-2 page statement of purpose that addresses (1) how your previous coursework, research, or employment prepares you for our program; and (2) how our program fits into your career interests and goals, and c) one signed letter of recommendation from an academic or employment reference.</br>
Failure to fulfill these requirements will result in disqualification from the program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

## Advancement to Candidacy
Each semester, students should consult with their graduate advisor to develop a schedule of courses. Students admitted as conditionally classified must satisfy the requirements listed in their acceptance agreement before advancing to candidacy. Students who have achieved classified standing in the master’s degree curriculum must next advance to candidacy for the degree. A student may advance to candidacy after:</br>

- Completing a minimum of 9 units of letter-graded work as a graduate student in 100- or 200-level courses acceptable to the program as well as fulfilling the other university requirements for advancement to candidacy .</br>

- Completing the Graduation Writing Assessment Requirement (GWAR) .</br>


## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Course Requirements
Students must have a cumulative GPA of 3.0 or better.</br>

- Students who enter the program having already completed courses equivalent in level and content to any of those required for the degree may be allowed to substitute an appropriate alternative course upon advance approval by the MS Quantum Technology Program Director.</br>

- Up to 9 credits toward the degree may be transferred from an outside institution with approval of the Program Director.</br>

- A maximum of 9 upper-division undergraduate units can be applied toward the degree.</br>

- Electives make up 12 units of the degree; at least 6 units of electives must be 200-level letter graded courses in physics or electrical engineering. For the additional 6 units of electives students may enroll in letter-graded 100- or 200-level physics, mathematics, science or engineering courses. All electives must be selected in consultation with the Program Director.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) , which is satisfied in this degree by the completion of PHYS 200W  or PHYS 220E  or EE 295  with a grade of “B” or better.</br>

### Culminating Experience
Students in the MS Quantum Technology program are required to complete one of the following options to fulfill the culminating experience requirements. The students should enroll in project/thesis courses matching the home department of their research advisor (Physics & Astronomy or Electrical Engineering). Students must complete 6 units of research and project courses to fulfill the degree requirements.</br>
Plan A (Thesis)</br>
Students choosing the thesis option must complete 3-5 units of directed research or project proposal courses (4-5 units of PHYS 297  or exactly 3 units of EE 299A ) and 1-3 units of thesis writing (1-2 units of PHYS 299  or exactly 3 units of EE 299B ) to fulfill the degree requirements. Students should enroll in the research and project courses corresponding to their research advisor’s home department. Students are responsible for identifying a faculty thesis advisor and two additional thesis committee members. At least one faculty member must be full-time in PHYS or EE; this person will serve as the committee chair.</br>
The written thesis must meet university requirements as stipulated in the Graduate Policies & Procedures  section of this catalog and in the  SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis advisor with the assistance of the thesis committee. The MS thesis document must be approved by the thesis committee before submission. Candidates for the Quantum Technology MS degree must successfully pass a final oral thesis defense. The defense talk will be open to the public.</br>
Plan B (Written Project) </br>
Students choosing the written project option must complete 3-5 units of directed research or project proposal courses (4-5 units of PHYS 297  or exactly 3 units of EE 297A ) and 1-3 units of a project writing course (1-2 units of PHYS 298  or exactly 3 units of EE 297B ). Students are responsible for identifying a faculty project advisor and one additional project committee member. At least one faculty member must be full-time in EE or PHYS; this person will serve as the committee chair. Students must complete a public oral presentation of the project and the project manuscript must be approved by the student’s committee.</br>

## Master’s Requirements (30 units)

### Core Courses (12 units)

- PHYS 161 - Fundamentals of Quantum Information 3 unit(s)</br>


#### GWAR Course (3 units)

- PHYS 200W - Research and Communication in Physics 3 unit(s) (GWAR)</br>

- PHYS 220E - Graduate Optics Lab 3 unit(s) (GWAR)</br>

- EE 295 - Technical Writing - Engineering Ethics 3 unit(s) (GWAR)</br>


#### Core Technical Courses (6 units)
Complete two courses from the following:</br>

- PHYS 250 - Quantum Programming 3 unit(s)</br>

- PHYS 253 - Quantum Many-Body Physics 3 unit(s)</br>

- EE 274 - Quantum Computing Architectures 3 unit(s)</br>


### Electives (12 units)
Complete at least 2 200-level PHYS or EE courses. Up to 2 100-level elective courses may count towards the degree. Other mathematics, computer science, engineering or STEM courses may count with prior approval by the program director.</br>

- EE 225 - Introduction to Quantum Computing 3 unit(s)</br>

- EE 226 - Cryogenic Nanoelectronics 3 unit(s)</br>

- EE 250 - Probabilities, Random Variables and Stochastic Processes 3 unit(s)</br>

- PHYS 163 - Quantum Mechanics 4 unit(s)</br>

- PHYS 208 - Introduction to Electro-Optics 3 unit(s)</br>

- PHYS 240 - Computational Physics 3 unit(s)</br>

- PHYS 263A - Quantum Theory 3 unit(s)</br>

- PHYS 268 - Laser Spectroscopy 3 unit(s)</br>

- PHYS 275 - Solid State Physics 3 unit(s)</br>

- Other mathematics, computer science, engineering or STEM courses with prior approval.</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one of the following 4 options. Students should enroll in project/thesis courses matching the home department of their research advisor.</br>

#### Plan A (Thesis):

- Advisor in Physics & Astronomy Department:</br>

Advisor in Physics & Astronomy Department:</br>

- PHYS 297 - Directed Research 1-5 unit(s)  (4-5 units required)</br>

- PHYS 299 - Master’s Thesis 1-4 unit(s) (1-2 units required)</br>

- Advisor in Electrical Engineering Department:</br>

Advisor in Electrical Engineering Department:</br>

- EE 299A - MSEE Thesis Proposal 3 unit(s)</br>

- EE 299B - MSEE Thesis 3 unit(s)</br>


#### Plan B (Project):

- Advisor in Physics & Astronomy Department:</br>

Advisor in Physics & Astronomy Department:</br>

- PHYS 297 - Directed Research 1-5 unit(s) (4-5 units required)</br>

- PHYS 298 - Graduate Research Report 1-4 unit(s) (1-2 units required)</br>

- Advisor in Electrical Engineering Department:</br>

Advisor in Electrical Engineering Department:</br>

- EE 297A - MSEE Project Proposal 3 unit(s)</br>

- EE 297B - MSEE Project 3 unit(s)</br>


## Total Units Required (30 units)
 </br>