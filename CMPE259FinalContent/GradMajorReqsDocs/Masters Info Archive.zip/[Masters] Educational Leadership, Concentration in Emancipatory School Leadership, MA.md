
# Educational Leadership, Concentration in Emancipatory School Leadership, MA
 </br>

- Admission Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MA Educational Leadership with a concentration in Emancipatory School Leadership (MELS), offered by the Department of Educational Leadership , prepares school leaders through deep engagement with research and practice through applied consulting on living case studies. Emancipatory school leadership approaches create organizational cultures to reflect the diversity of experience and knowledge within school communities through collaborative approaches to deconstruct power systems, challenge inequitable practices and policies, and cultivate community cultural wealth.</br>

## Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet admission requirements. See the GAPE Graduate Admissions website and admissions requirements  section as well as the program website. Applicants must submit a letter of nomination/recommendation from a school leader as part of their application. Upon review of the applications, all applicant finalists will participate in an interview by the admissions committee to finalize admission to the program. Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on GAPE’s Graduate Program Test Requirements webpage. For TOEFL requirements, see the admissions requirements  section.</br>

### Requirements for Admission to Classified Standing
Applicants may be admitted to classified standing if they meet the admissions requirements for both the Graduate Division and the department. The minimum requirements for the program are a bachelor’s degree in any discipline, 3 years of experience working with K-12 schools or with school-communities, and a nomination/recommendation from a school or community leader. Preference is given to candidates who demonstrate a commitment to emancipatory practices in education.</br>
Candidates must meet all university admissions requirements.</br>
Department of Educational Leadership San José State University
One Washington Square, SH 491
San Jose, CA, 95192-0072</br>
Autobiographical and Professional Goals Statement (two to three pages, double-spaced) that includes the applicant’s:</br>

- educational background</br>

- experiences demonstrating work with K-12 schools or with school-communities </br>

- professional goals in pursuing the degree (include areas of interest in leadership)</br>

- any additional information explaining interest in the Emancipatory Leadership for Schools master’s degree program</br>

- One nomination/recommendation from a K-12 school leader.</br>

- Official sealed transcripts from each college/university attended should be sent to:


	Graduate Admissions and Program Evaluations San José State University
	One Washington Square, SH 219
	San Jose, CA, 95192-0072 </br>

## Graduation Requirements
Complete the following requirements:</br>

- PASC/CalAPA Transfer Units or Area of Specialization (12 units);</br>

- Core Courses: EDLD 201 , EDLD 202 , EDLD 204 , EDLD 205 , EDLD 206 , and EDLD 253 . Students must achieve a minimum of a “C” in each course, a cumulative GPA of 3.0 or better in all their coursework, AND a GPA of 3.0 or higher for the courses listed in the Candidacy form. At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . The GWAR is satisfied with the degree requirements core course EDLD 201 ;</br>

- Both culminating experiences: Applied Consulting Project and the Emancipatory Leadership as Praxis Statement.</br>


## Master’s Requirements (30 units)

### PASC/CalAPA Transfer Units or Area of Specialization (12 units)
Students who have completed the PASC/CalAPA will be able to transfer 12 units of coursework and will take the remaining 18 units.</br>
Students who have not completed the PASC/CalAPA will take courses as a specialization in an area of interest that is related to educational leadership (e.g. Ethnic Stuides or Literacy). These courses will be pre-approved by the coordinator.</br>

### Summer (6 units)

- EDLD 201 - Epistemologies of Educational Leadership: Personal, Political, & Intellectual 3 unit(s)</br>

- EDLD 202 - Emancipatory Teaching and Learning 3 unit(s)</br>


### Fall (6 units)

- EDLD 204 - Critical Studies of Educational Policy 3 unit(s)</br>

- EDLD 205 - Equity & Access: Practices, Policies, & Pedagogies 3 unit(s)</br>


### Spring (6 units)

- EDLD 206 - Emancipatory Leadership as Praxis Seminar 3 unit(s)</br>

- EDLD 253 - Envisioning Emancipatory Leadership for Schools 3 unit(s)</br>

-  

Note: Students who are enrolled in the Individualized Pathway, may supplement Individualized Pathway coursework with one of these EDD courses: EDD 510 ,  EDD 511 , EDD 512 , EDD 515 , EDD 520 , EDD 522 , EDD 530 , and EDD 536  for a total of 6 units. Students must be admitted to Educational Leadership, EdD program. Email edleadership.edu for information. 
View the three MA Pathways for more information.</br>
 </br>
Note: Students who are enrolled in the Individualized Pathway, may supplement Individualized Pathway coursework with one of these EDD courses: EDD 510 ,  EDD 511 , EDD 512 , EDD 515 , EDD 520 , EDD 522 , EDD 530 , and EDD 536  for a total of 6 units. Students must be admitted to Educational Leadership, EdD program. Email edleadership.edu for information. </br>
View the three MA Pathways for more information.</br>

### Culminating Experiences
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
The culminating experience contains an experience-based component requiring enrollment in both EDLD 205  and EDLD 206  in addition to submitting an approved praxis statement after completing EDLD 253 .</br>

#### 1. Applied Consulting Project
Upon identifying a school leadership challenge that a school or district is struggling with (living case study), students work as a cohort to research the problem, explore possible solutions, and work closely with the school or district to address the challenge with emancipatory leadership solutions.</br>

#### 2. Emancipatory Leadership as Praxis Statement
Students prepare an individualized 3-year leadership action plan that outlines their core values, a personal vision statement, current and lacking leadership skills and actionable goals to practice areas of growth.</br>

## Total Units Required (30 units)
 </br>