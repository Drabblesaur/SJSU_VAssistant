
# Nursing, MS
 </br>
MSN Program Coordinator and Advisor: Dr. Nicole Zhang</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (36 units)</br>

- Program Learning Outcomes  </br>

A graduate of this program is prepared for advanced nursing practice with a focus as a Nurse Educator (NE). Please see an advisor at The Valley Foundation School of Nursing  for more details.</br>

## Requirements for Advancement to Graduate Candidacy
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR) as a condition for advancement to candidacy and for conversion from conditional to classified standing. The MS - Nursing degree also requires that the applicant has been granted classified standing and has removed any deficiencies involved. In addition, the candidate must have:</br>

- Earned at least a “B” (3.0) average in a minimum of nine graded semester units of 100- and/or 200-level work completed in graduate standing at San José State University and in any coursework completed in graduate standing at other institutions before enrollment here.</br>

- Classified standing.</br>

- MSN Project Plan approved by the Nursing School Graduate Coordinator.</br>


## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS Nursing Graduation Requirements

#### Culminating Experience: Project
Candidates for the degree complete a written capstone project as part of their 40-unit regular degree requirement. This project is an investigation of an evidenced-based nursing topic.  It shall identify a clinical problem and question(s), state the major theoretical perspectives, explain the significance of the undertaking, relate it to relevant, scholarly and professional literature, set forth the appropriate sources for and methods of gathering and analyzing the data, and offer a conclusion or recommendation.</br>

#### Completion of Clinical Hours: Practice
All students shall complete direct patient care supervised clinical hours.</br>

#### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (36 units)

### Required Core Courses (19 units)

- NURS 200 - Population Based Health Care Systems 3 unit(s)</br>

- NURS 201 - Clinical Leadership Role Development 2 unit(s)</br>

- NURS 202 - Theoretical Foundations 2 unit(s)</br>

- NURS 248 - Advanced Health Assessment 3 unit(s)</br>

- NURS 259 - Advanced Clinical Pharmacology 3 unit(s)</br>

- NURS 260 - Advanced Physiology and Pathophysiology for Advanced Practice Nursing 3 unit(s)</br>

- NURS 295A - Research Methods 3 unit(s) (GWAR)</br>


### Functional Area of Specialization (14 units)

#### Nurse Educator

- EDUC 186 - Using Instructional Media 3 unit(s)</br>

- NURS 212 - Curriculum Development in Nursing 3 unit(s)</br>

- NURS 214 - Nurse Educator Theory and Direct Care Practicum I 4 unit(s)</br>

- NURS 216 - Academic Theory & Practicum II 4 unit(s)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one course from:</br>

- NURS 297 - Master’s Project 1-4 unit(s)</br>

- NURS 299 - Master’s Thesis 1-4 unit(s)</br>


## Total Units Required (36 units)
 </br>