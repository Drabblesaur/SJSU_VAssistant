
# Speech Language Pathology, MS
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (66 units)</br>

- Program Learning Outcomes  </br>

The Department of Communicative Disorders and Sciences  (CDS) Master of Science degree program in Speech Language Pathology offers an in-depth study of communication disorders with an emphasis on articulation and phonological disorders, fluency disorders (stuttering), augmentative and alternative communication (AAC), voice disorders, dysphagia (swallowing disorders), neurogenic disorders, hearing disorders, language disorders, social aspects of communication, and cognitive-communication disorders. Courses and clinical training opportunities place a high priority on assessment and intervention within an evidence-based, ethical, inclusive, and culturally responsive framework. Clinical practices are completed in varied settings, including the Kay Armstead Center for Communicative Disorders housed in the department. Signature speech, language and hearing services include screenings, evaluations, and a variety of therapy clinics including an AAC clinic, a voice clinic, a clinic for adults with intellectual disability, a clinic for children with language disorders, the Spartan Aphasia Research Clinic, and a summer camp for children who stutter. Students have clinical opportunities for working with toddlers, children, adolescents, and adults in multiple settings, including public, private and charter schools (preschool, elementary, middle, high schools), rehabilitation agencies, private practices, skilled nursing facilities, and hospitals.</br>

## Admission Requirements
The MS in Speech Language Pathology (MS-SLP) program requires a two-step application process for admission:</br>

- University Application: Cal State Apply </br>

- Department Application: Communication Sciences and Disorders Centralized Application Service (CSDCAS) </br>

Both applications must be completed by the deadline to be considered for admission.</br>

### University Requirements
Applicants must apply through the CSU admissions portal, Cal State Apply, and meet the graduate admission requirements at SJSU.</br>

### Department Requirements
Applicants must also apply through the Communication Sciences and Disorders Centralized Application Service (CSDCAS), and meet the program minimum eligibility and requirements. </br>
The program admits students to either classified or conditionally classified standing based on the completion of program prerequisites before program start date. Eligible applicants who will have completed program prerequisites before enrolling in the program may apply to the two-year program and be considered for admission to classified standing. Eligible applicants who will not have completed all prerequisites before enrolling in the program should consider applying to the three-year extended program and be considered for admission to conditionally classified standing.</br>
Instruction for applying to the MS in Speech-Language Pathology Program</br>
Applicants from countries in which the official language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Admissions Test Requirements webpage.</br>

## Advancement to Candidacy
Students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MS degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) . The department’s GWAR is met by completing the EDSP 221  course with a grade of B or better.</br>

## Graduation Requirements

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . Completion of the degree also requires a minimum grade of “B” in all courses taken and a minimum overall GPA of 3.0.</br>

### Degree Requirements
Students are expected to complete all required courses, the culminating experience, clinical practica, and observation requirements. To meet degree requirements, candidates for the MS degree must maintain a 3.0 GPA in all courses with no single course grade below a B- (B minus) and no single clinical practicum below a B. Students who earn less than a B- (B minus) in any required course or less than a B in any clinical practicum must retake the course and meet the minimum grade requirement.</br>

- Complete 24 practicum/fieldwork units including EDSP 277  (3 times in 3 different types of clinics), EDSP 276 , EDSP 269  (School-based SLP placement), and EDSP 278  (Non-school based SLP placement). Candidates for the Master’s degree must accumulate a minimum of 375 required clock hours in a supervised clinical practicum in three distinctly different settings, and a minimum of 25 hours of observation;</br>

- Complete 39 units of required academic courses, corresponding to national and state accreditation standards in Speech-Language Pathology;</br>

- Apply for graduation via MySJSU; and, </br>

- Complete the Culminating Experience: Successfully pass the Comprehensive Exam or complete a Master’s Thesis as a required culminating experience in the graduate program.</br>

Prior to providing any speech, language, or communication assessment or intervention services during clinical practica, students must show evidence of all of the following:</br>

- Certificate of Clearance;</br>

- Negative TB (tuberculosis) test;</br>

- Negative Hepatitis test;</br>

- Physical Clearance to provide speech-language pathology services;</br>

- Successful completion of online training related to HIPAA (Health Insurance Portability and Accountability Act); </br>

- CPR (Cardiopulmonary resuscitation) Certification; and</br>

- Compliance with additional practicum site policies and requirements.</br>


#### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . GWAR in this program is fulfilled by EDSP 221 .</br>

#### Culminating Experience
All students in the Master of Science (MS) in Speech-Language Pathology program must successfully complete the culminating experience requirement by selecting one of the following two options.</br>
Plan A (Thesis)</br>
Students who have a strong interest in research may be approved to complete the Thesis (Plan A). It requires students to secure a thesis advisor and a thesis committee and enroll in EDSP 299  during the final semester. The thesis must be defended and approved by a thesis committee and follow the College of Graduate Studies Master’s Thesis and Doctoral Dissertation Guidelines.</br>
Plan B (Comprehensive Exam/Project)</br>
The comprehensive exam/project assesses broad knowledge and competency across topics in speech, language, hearing, cognitive-communication, and swallowing disorders. It requires students to enroll in EDSP 298   during the Spring semester of the final year. </br>

### Program Delivery

#### On-Campus Program
The on-campus MS-SLP program offers a regular (two-year) and an extended (three-year) plan of study. The two-year plan is designed for students with completed prerequisite coursework or a Bachelor’s degree in communication disorders and sciences. The two-year plan requires continuous enrollment over five semesters, including summer. The three-year plan is designed for students without prerequisite coursework or a degree in communication disorders and sciences. The three-year plan includes one year of leveling coursework followed by the regular two-year plan of study. For detailed information about the program, see the MS-SLP program webpage.</br>

#### Online/Hybrid Program (Special Session)
SJSU SPEAKS (Speech-Language Pathology Education and Applied Knowledge and Skills) is a two-year online graduate program that requires continuous enrollment over five semesters. In SJSU SPEAKS, academic courses are completed online (with asynchronous sessions and synchronous sessions usually on weekday evenings), and clinical placements are completed in-person. The SPEAKS program degree requirements and the speech-language pathology competencies covered are the same as those of the on-campus MS-SLP program. </br>
SJSU SPEAKS is an academic program offered through Special Session, operated by SJSU Professional and Continuing Education (PaCE). Registration and enrollment in a Special Session  must use the special session application form and will follow special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit Special Session  for more information. </br>

## Master’s Requirements (66 units)

### Core Courses (39 units)

- EDSP 221 - Research Seminar in Communicative Disorders 3 unit(s) (GWAR) (Students must earn a B (3.0) or better in EDSP 221 )</br>

- EDSP 222 - School Age Language, Literacy, and Social Communication 3 unit(s)</br>

- EDSP 250 - Seminar in Voice Disorders 3 unit(s)</br>

- EDSP 251 - Seminar in Phonological Disorders 3 unit(s)</br>

- EDSP 252 - Seminar Fluency Disorders 3 unit(s)</br>

- EDSP 254 - Seminar in Neurological Disorders 3 unit(s)</br>

- EDSP 255 - Seminar in Motor Speech Disorders 3 unit(s)</br>

- EDSP 259 - Seminar in Language Disorders in Children 3 unit(s)</br>

- EDSP 260 - Seminar in Dysphagia 3 unit(s)</br>

- EDSP 262 - Speech and Language in a Cross-Cultural Society 3 unit(s)</br>

- EDSP 264 - Contemporary Professional Issues 3 unit(s)</br>

- EDSP 265 - Seminar in Cognitive Disorders 3 unit(s)</br>

- EDSP 288 - Seminar in AAC and Communication Disorders 3 unit(s)</br>


### Practicum (24 units)
Complete the following 24 practicum/fieldwork units for a minimum of 400 clinic hours (375 practicum hours + 25 observation hours):</br>

- EDSP 269 - Field Experience in Public Schools - Speech Pathology and Audiology 6 unit(s)</br>

- EDSP 276 - Practicum in Advanced Assessment 3 unit(s)</br>

- EDSP 277 - Advanced Practicum-Speech Pathology 1-3 unit(s) (Students take EDSP 277  (3 units) three times for a total of 9 units)</br>

- EDSP 278 - Clinical Management and Practicum 6-10 unit(s) (Students take EDSP 278  once for a total of 6 units)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (Thesis)

- EDSP 299 - Master’s Thesis 1-4 unit(s) (3 units required)</br>


#### Plan B (Comprehensive Exam/Project)

- EDSP 298 - Special Studies 1-3 unit(s) (3 units required)</br>


## Total Units Required (66 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>