
# Library and Information Science, MLIS
 </br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (43 units)</br>

- Program Learning Outcomes  </br>

The San José State University (SJSU) School of Information  prepares individuals for careers as information professionals. Graduates work in diverse areas of the information profession, such as user experience design, digital asset management, information architecture, electronic records management, information governance, digital preservation, and librarianship. The SJSU School of Information delivers all of its graduate degrees and certificates fully online. It is a recognized leader in online education and received the Online Learning Consortium’s Outstanding Online Program award.</br>
For more information: ischool.sjsu.edu.</br>

## Requirements for Admission to Classified Standing
Candidates must meet all university admission requirements . Applicants who meet the following requirements beyond university requirements will be considered for admission into the School of Information:</br>

- A bachelor’s degree from any regionally accredited institution in any discipline with a GPA of at least 3.0 at the bachelor’s degree institution or in the last 60 semester or 90 quarter units.</br>

- A general understanding of computers and technology. See Technology Literacy Requirements.</br>

- The School requires that all students have computer access from home. See Home Computing Requirements.</br>

- Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>


## Requirements for Admission to Conditionally Classified Standing
The School of Information does not admit students on a conditional basis.</br>

## Requirements for Advancement to Graduate Candidacy
In order to achieve candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MLIS degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
Students must complete and submit the Petition for Advancement to Graduate Candidacy after completion of nine units and by the posted deadlines for the semester in which they plan to graduate. For additional program requirements and submission instructions, refer to the MLIS Candidacy Approval Form Information website.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
Special Session Program Information</br>
Academic Programs offered through Special Session are operated by Professional and Continuing Education. Registration and enrollment in a Special Session course or program are subject to special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing INFO 200 .</br>

### Culminating Experience
Plan A (Thesis)</br>
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (ePortfolio)</br>
The e-Portfolio provides a program-based assessment to ensure that each student demonstrates mastery of all program learning outcomes for the MLIS degree before graduation. It requires students to select, document, and assemble evidence of their competence in a series of skill areas the faculty have deemed essential for entry-level professional performance.</br>

## Master’s Requirements (43 units)

### Core Courses (13 units)
INFO 200 , INFO 202 , and INFO 204  must be passed with a grade of B or better.</br>

- INFO 200 - Information Communities 3 unit(s) (GWAR)</br>

- INFO 202 - Information Retrieval System Design 3 unit(s)</br>

- INFO 203 - Online Learning: Tools and Strategies 1 unit(s)</br>

- INFO 204 - Information Professions 3 unit(s)</br>

- INFO 285 - Applied Research Methods 1-4 unit(s)</br>


### Electives (27 units)

- INFO 210 - Reference and Information Services 1-3 unit(s) (3 units required)</br>

- INFO 220 - Resources and Information Services in Professions and Disciplines 1-3 unit(s)</br>

- INFO 221 - Government Information Sources 3 unit(s)</br>

- INFO 230 - Issues in Academic Libraries 3 unit(s)</br>

- INFO 231 - Issues in Special Libraries and Information Centers 3 unit(s)</br>

- INFO 232 - Issues in Public Libraries 3 unit(s)</br>

- INFO 233 - School Library Media Centers 3 unit(s)</br>

- INFO 234 - Intellectual Freedom Seminar 3 unit(s)</br>

- INFO 237 - School Library Media Materials 3 unit(s)</br>

- INFO 240 - Information Technology Tools and Applications 3 unit(s)</br>

- INFO 241 - Automated Library Systems 1-3 unit(s) (3 units required)</br>

- INFO 242 - Database Design and Management 3 unit(s)</br>

- INFO 244 - Online Searching 3 unit(s)</br>

- INFO 246 - Information Technology Tools and Applications - Advanced 1-3 unit(s)</br>

- INFO 247 - Vocabulary Design 3 unit(s)</br>

- INFO 248 - Beginning Cataloging and Classification 3 unit(s)</br>

- INFO 250 - Design and Implementation of Instructional Strategies for Information Professionals 3 unit(s)</br>

- INFO 251 - Web Usability 3 unit(s)</br>

- INFO 254 - Information Literacy and Learning 3 unit(s)</br>

- INFO 256 - Archives and Manuscripts 3 unit(s)</br>

- INFO 259 - Preservation Management 3 unit(s)</br>

- INFO 263 - Materials for Children 3 unit(s)</br>

- INFO 265 - Materials for Young Adults Ages 3 unit(s)</br>

- INFO 266 - Collection Management 3 unit(s)</br>

- INFO 267 - Services to Youth 1-9 unit(s)</br>

- INFO 268 - History of Youth Literature 3 unit(s)</br>

- INFO 269 - Early Childhood Literacy 3 unit(s)</br>

- INFO 271A - Genres and Topics in Youth Literature 1-9 unit(s)</br>

- INFO 275 - Library Services for Racially and Ethnically Diverse Communities 3 unit(s)</br>

- INFO 281 - Seminar in Contemporary Issues 1-3 unit(s)</br>

- INFO 282 - Seminar in Library Management 1-3 unit(s)</br>

- INFO 283 - Marketing of Information Products and Services 1-3 unit(s) (3 units required)</br>

- INFO 284 - Seminar in Archives and Records Management 1-3 unit(s)</br>

- INFO 286 - Interpersonal Communication Skills for Librarians 1-3 unit(s)</br>

- INFO 287 - Seminar in Information Science 1-3 unit(s)</br>

- INFO 293 - Introduction to Data Networking 3 unit(s)</br>

- INFO 294 - Professional Experiences: Internships 2-4 unit(s)</br>

- INFO 295 - School Library Field Work 3 unit(s)</br>

- INFO 298 - Special Studies 1-3 unit(s)</br>


### Culminating Experience (3 units)
Complete One Option (Plan A Thesis Or Plan B Portfolio):</br>

#### Plan A (Thesis)

- INFO 299 - Thesis 3 unit(s)</br>


#### Plan B (Portfolio)

- INFO 289 - Advanced Topics in Library and Information Science 3 unit(s)</br>


## Total Units Required (43 units)
Students can transfer up to 9 units subject to the School’s transfer policies.</br>
Elective courses must be planned in consultation with the Graduate Advisor</br>
A maximum of 15 upper-division undergraduate units can be applied toward the master’s degree.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>