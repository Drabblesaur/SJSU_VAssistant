
# Physics, MS
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

At the core of all science, physics helps us understand chemical reactions, protein folding, the Earth’s interior, and the life cycle of stars. Physicists invented the semiconductor, the laser, and the electron microscope. They play key roles in the design and operation of spacecraft and in the development of electronic and optical instrumentation. The Department of Physics and Astronomy  faculty are experts in lasers and optics, computational physics, condensed matter, astrophysics, and physics education research. The department receives on average approximately $1.8 million annually in external funding for sponsored research.</br>
See the Department of Physics and Astronomy website.</br>

## Admissions Requirements
Candidates must meet all the university admissions requirements . Students can be admitted in either classified or conditionally classified standing:</br>

- Classified Standing: Students admitted with classified standing will have an undergraduate degree in Physics or other STEM discipline with classes completed in upper-division Mechanics, Electricity and Magnetism and Quantum Mechanics.</br>

- Conditional Classified Standing: Conditional acceptance means that the candidate must fulfill specific requirements in order to be eligible to apply for advancement to candidacy. These conditions will be stipulated as part of the acceptance agreement between the faculty adviser and the applicant. Failure to fulfill these requirements will result in disqualification from the program.</br>

Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

## Advancement to Candidacy
Each semester, students should consult with their graduate advisor to develop a schedule of courses. Students admitted as conditionally classified must satisfy the requirements listed in their acceptance agreement before advancing to candidacy. Students who have achieved classified standing in the master’s degree curriculum must next advance to candidacy for the degree. A student may advance to candidacy after:</br>

- Completing a minimum of 9 units of letter-graded work as a graduate student in 100- or 200-level courses acceptable to the department as well as fulfilling the other university requirements for advancement to candidacy .</br>

- Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which is satisfied in this degree by the completion of PHYS 200W  or PHYS 220E  with a grade of “B” or better.</br>


## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Program Graduation Requirements
Students must complete program requirements, which consists of 30 semester units of approved work. The student consults with their advisor to select a thesis or project topic.</br>

#### Culminating Experience
Plan A (Thesis)</br>
Thesis: The thesis must meet university requirements as stipulated in the Graduate Policies and Procedures  section of this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s research committee chair with the assistance of the research committee. The MS thesis document must be approved by the student’s research committee before submission. Typically, the research committee will provide the candidate feedback during the Thesis Defense and may request changes to the thesis before final approval. Oral Thesis Defense: All MS candidates are required to present a public seminar based on their research project.</br>
Plan B (Project)</br>
Written Project: The written project must be a manuscript describing the student’s research project, written following a professional journal’s format for submission. It will be written under the guidance of the candidate’s research committee chair with the assistance of their research committee. The manuscript must be approved by the student’s research committee. Typically, the committee will provide the candidate feedback during the Project Defense and may request changes to the manuscript before final approval. </br>

## Master’s Requirements (30 units)

### Graduation Writing Assessment Requirement (3 units)
Students must pass the Graduation Writing Assessment Requirement (GWAR) . Complete one of the following:</br>

- PHYS 200W - Research and Communication in Physics 3 unit(s) (GWAR)</br>

- PHYS 220E - Graduate Optics Lab 3 unit(s) (GWAR)</br>


### Core Courses (9 units)
Choose 3 of the following:</br>

- PHYS 205 - Advanced Dynamics 3 unit(s)</br>

- PHYS 210 - Electromagnetic Theory 3 unit(s)</br>

- PHYS 230 - Methods in Mathematical Physics 3 unit(s)</br>

- PHYS 260 - Statistical Mechanics 3 unit(s)</br>

- PHYS 263A - Quantum Theory 3 unit(s)</br>


### Electives (12 units)
6 units letter-graded 200-level physics, 3 units letter-graded 200-level physics, mathematics, science or engineering courses approved by graduate advisor, 3 units 100- or 200-level physics, mathematics, science or engineering courses approved by the graduate advisor.</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one option (Plan A or Plan B):</br>

#### Plan A (Thesis)

- PHYS 297 - Directed Research 1-5 unit(s) (5 units required)</br>

- PHYS 299 - Master’s Thesis 1-4 unit(s) (1 unit required)</br>


#### Plan B (Project)

- PHYS 297 - Directed Research 1-5 unit(s) (2 units required)</br>

- Additional 3 units of PHYS 297  or elective selected in consultation with graduate advisor</br>

- PHYS 298 - Graduate Research Report 1-4 unit(s) (1 unit required)</br>


## Total Units Required (30 units)
 </br>