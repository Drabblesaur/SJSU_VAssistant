
# Applied Anthropology, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (36 units)</br>

- Program Learning Outcomes  </br>

Offered by the Department of Anthropology , more information about the Masters in Applied Anthropology program and important dates can be obtained at the Anthropology department website.</br>

## Admissions Requirements
Candidates must meet all the university admission requirements . The university-level graduate application is separate from the application you send to the department. You will need to apply separately to the university  to obtain approval for university-level admission and to the department to obtain admission into the Applied Anthropology Program. Minimum requirements for the program are a bachelor’s degree in Anthropology or a core of introductory Cultural and Physical or Archaeological Anthropology; an upper-division methods course in Ethnography, Archaeology, or Osteology; an upper-division anthropological theory course; and 6 elective units in upper-division Anthropology (approximately 18 units overall). A 3.0 grade point average (B or better) in the last 60 semester units of undergraduate work and all Anthropology courses is required. Depending on their level of preparation, applicants can be admitted in either classified or conditionally classified standing.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage</br>

## Requirements for Advancement to Graduate Candidacy
Students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
Further requirements of the department for advancement to candidacy include completion of 18 units in the graduate program and submission of a project or thesis proposal to the department’s Graduate Committee. In order to advance to candidacy, all students must participate in the First Year Review in their second semester. Further information on the First Year Review is available on the program FAQ page on the Department of Anthropology website.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . </br>

### MA -Applied Anthropology Graduation Requirements
Each course of study must include 36 semester units. Eighteen of the units are in the Applied Anthropology core. Six units of upper-division or graduate Anthropology depth courses will be taken with the permission of the student’s advisor, and 6 units of upper-division or graduate classes outside of Anthropology emphasizing the student’s area of application will be taken with the permission of the student’s advisor. Six additional units will reflect research or professional internships and thesis or project report preparation. SJSU Studies courses may not be used to fulfill the Anthropology depth requirement or field of application requirement. In addition, students are expected to conduct original research and write a thesis or, alternatively, to be engaged in professional activity and write a project report. All research or professional activity must conform to the ethical standards of the discipline of Anthropology as outlined by the American Anthropological Association, the Society for Applied Anthropology, and the university’s Institutional Review Board. The policy on timely progression to the degree is available on the Applied Anthropology program website.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students must choose between Plan A (Thesis) or Plan B (Project) in order to graduate. In both cases, students must submit (to the department) and have approved a proposal for the work they are undertaking. For more information on Plan A and Plan B options and how to choose between them, please see the program FAQ on the Department of Anthropology website.</br>
Plan A (Thesis)</br>
Plan A students enroll in ANTH 299 - Master’s Thesis  and complete a thesis under the supervision of a department committee. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. A thesis is a scholarly contribution to general knowledge and follows a fairly standard, traditional form across disciplines and fields. Typically, a thesis has an introductory chapter that includes a problem statement, a literature review chapter followed by one on methodology, one or more chapters of data and findings, an analytical/interpretive chapter, and a concluding chapter. This basic template can be modified to best meet your needs, but it must be done in consultation with your committee chair to ensure it meets university requirements.</br>
Plan B (Project)</br>
Plan B students enroll in ANTH 298 - Anthropology Project  and undertake a project in applied anthropology and prepare a report documenting the process and results. The report is submitted to the anthropology graduate faculty, but not the College of Graduate Studies. All research or professional activity must conform to the ethical standards of the discipline of anthropology as outlined by the American Anthropological Association, the Society for Applied Anthropology, and the requirements of the university’s Institutional Review Board. A project report documents some activity that the student undertook to apply anthropological skills and knowledge. Because it is not submitted to the College of Graduate Studies, it does not have to meet that office’s thesis requirements. Specifically, its length and organization are more variable and must be negotiated with the committee chair and the graduate faculty of the department. Project reports may be as brief as 50 pages and as long as several hundred. The report will typically document the problem, question, or issue that stimulated the application; a literature review that includes both the history of the specific problem and its context, as well as comparable problems elsewhere are included. It will document in detail the application (i.e., what the student did), its rationale (i.e., why the student took the steps he or she did), and the outcomes (i.e., what happened). Although the emphasis will be on solving or addressing a particular problem, the report will also include a systematic reflection on what happened and why, the larger lessons the student learned, and how they might inform practice in the future.</br>

## Master’s Requirements (36 units)

### Core Courses (18 units)

- ANTH 230 - Theory in Practice 3 unit(s) (GWAR)</br>

- ANTH 231 - Applications Core 3 unit(s)</br>

- ANTH 232 - Applications Core 3 unit(s)</br>

- ANTH 233 - Fields of Application 3 unit(s)</br>

- ANTH 234 - Advanced Research Methods 3 unit(s)</br>

- ANTH 235 - Quantitative Methods 3 unit(s) (Advisor approved elective may be substituted for ANTH 235 )</br>


### Anthropology Depth Requirement (6 units)
Two 3-unit upper division anthropology courses approved by faculty advisor</br>

### Field of Application Requirement (6 units)
Two 3-unit upper division SJSU courses approved by faculty advisor</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form. </br>

- ANTH 280 - Individual Studies 1-4 unit(s) (3 units required)</br>


#### Complete One Option From (Plan A or Plan B):

- ANTH 299 - Master’s Thesis 1-6 unit(s)</br>

- ANTH 298 - Anthropology Project 1-6 unit(s) (3 units required)</br>


## Total Units Required (36 units)
Elective courses must be planned in consultation with the Anthropology Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>