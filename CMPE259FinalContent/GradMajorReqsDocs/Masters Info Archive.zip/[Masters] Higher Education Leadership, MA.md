
# Higher Education Leadership, MA
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes</br>

The Higher Education Leadership, MA offered by the Department of Educational Leadership prepares higher education leaders through an equity-minded praxis approach to engage in transformative thinking and practice with the aim of disrupting how power, in the form of racism, classism, sexism, and related oppressions, have historically intersected to (re)produce and sustain disparate opportunities in higher education. Students are also required to participate in one day-long in person seminar per semester. </br>

## Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants must also respond to two short essay prompts. Upon review of the applications, all applicant finalists will participate in an interview by the admissions committee to finalize admission to the program. Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Admissions Test Requirements webpage. </br>

### Requirements for Admission to Classified Standing
To be admitted to classified standing, applicants must have earned a Bachelor’s degree from a regionally accredited institution with a minimum G.P.A. of 3.0 (based on a 4.0 scale). Two letters of recommendation are required, a third letter is optional.</br>

## Advancement to Candidacy
Students must meet the university requirements for candidacy. General university requirements for advancement to candidacy for the MA degree are detailed in the Graduate Policies and Procedures  section. </br>

## Graduation Requirements
Complete the following requirements:</br>

- Core courses: EDLD 210 , EDLD 211 , EDLD 212 , EDLD 213 , EDLD 214 , EDLD 215 , EDLD 216 , EDLD 217A , EDLD 217B , EDLD 298 . A student must maintain an overall grade point average (GPA) of 3.0 at all times, otherwise they will be placed on academic probation and required to raise the overall GPA above the 3.0 minimum during the subsequent semester (failing to do so will result in disqualification from the program).  </br>

- The program requires an individual two-semester, six-unit case-study sequence, as well as a culminating capstone project. For the required culminating experience (EDLD 298 ), Higher Education Leadership MA students must complete a final master’s capstone project. A project is a significant undertaking that evidences originality and independent thinking, appropriate form and organization, and a rationale. Beginning Summer ‘24, the culminating capstone project will be a group assignment.</br>

- At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR). This requirement is satisfied by the passing of EDLD 212 .</br>


## Streamlined Pathway to the Educational Leadership Doctorate (EdD)
The Department of Educational Leadership offers a streamlined pathway from the MA to the Ed.D. to students enrolled in the Department of Educational Leadership’s Master’s Programs. Eligible students must be in good academic standing with no probation and/or academic notices, and with intentions to pursue an Ed.D. in Educational Leadership. </br>
Pre-requisites to this Pathway:</br>

- Currently enrolled in an Educational Leadership MA Program, including the Higher Education Leadership Master’s Program</br>

- In good academic standing (3.0 GPA or above)</br>

- Have advanced to candidacy in your MA program</br>

- Have applied for Summer graduation</br>


## Master’s Requirements (30 units)

### Summer (6 units)

- EDLD 210 - Socio-Cultural Foundations of U.S. Higher Education 3 unit(s)</br>

- EDLD 211 - Higher Education Leadership 3 unit(s)</br>


### Fall (9 units)

- EDLD 212 - Diversity, Equity, and Social Justice in Higher Education 3 unit(s) (GWAR)</br>

- EDLD 213 - Policy and Ethics of Higher Education Governance and Finance 3 unit(s)</br>

- EDLD 214 - Critical Data Analysis in Higher Education 3 unit(s)</br>


### Spring (9 units)

- EDLD 215 - Contemporary Issues in Higher Education 3 unit(s)</br>

- EDLD 216 - Law, Policy, and Ethics in Higher Education 3 unit(s)</br>

- EDLD 217A - Equity-Minded Leadership in Higher Education: Practices, Policies, and Pedagogies 3 unit(s)</br>


### Summer (6 units)

- EDLD 217B - Equity-Minded Leadership in Higher Education as Praxis 3 unit(s)</br>

- EDLD 298 - Higher Education Leadership Master’s Capstone/Culminating Experience Course 3 unit(s)</br>

- *Note: Students may substitute EDLD 215, EDLD 217B with one of these EDD courses: EDD 520, 536, 510, 522, 515, 530, 511, and 512 for a total of 6 units. Students must be admitted to Educational Leadership, EdD program. Email edleadership.edu for information. </br>

*Note: Students may substitute EDLD 215, EDLD 217B with one of these EDD courses: EDD 520, 536, 510, 522, 515, 530, 511, and 512 for a total of 6 units. Students must be admitted to Educational Leadership, EdD program. Email edleadership.edu for information. </br>

### Culminating Experience
Program departments are required to certify when the culminating experience has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Prerequisite to the culminating capstone project, students enroll in two semesters of coursework (EDLD 217A  & EDLD 217B  - 6 units) in which they conduct living case study projects. In EDLD 298 , students have the option of completing a culminating project within one of two strands: researcher-focused (producing a research project on a topic in higher education) or practitioner-focused (producing a practitioner project on a problem of practice in higher education). Final capstone topics must be approved by the Higher Education Leadership Master’s Coordinator and/or EDLD 298 instructor of record.</br>
 </br>