
# Communication Studies, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (32 units)</br>

- Program Learning Outcomes  </br>

The Master of Arts in Communication Studies, offered by the Department of Communication Studies , is a comprehensive 32-unit program that provides advanced study in theories of communication, methodologies reflected in diverse approaches to communication research, and practice in applying concepts and methods in scholarly and “real world” contexts. A broad range of coursework in diverse areas of communication including environmental, interpersonal, intercultural, health, organizational, media studies, pedagogy, performance studies, and rhetoric provides students with a deeper understanding of the communication process, the study of communication, and the dimensions of ethical communication and research. Select students in the hybrid track can teach at the college level through the Teaching Associate (TA) program. Our alumni continue on to doctoral programs, teaching at colleges and universities, and careers in a wide range of professions in Silicon Valley and beyond.</br>
The program is offered in a hybrid and a fully online track. Students may switch from the online to hybrid track by completing the Change of Graduate Program Petition.</br>
Information about the MA in Communication Studies can be found on the Department of Communication Studies website. </br>

## Admissions Requirements

### University Admission
Candidates who meet all university admission requirements may apply through the CSU admissions portal, Cal State Apply. </br>
Applicants from countries in which the primary language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. Applicants who possess a baccalaureate degree from a post-secondary institution where English is the principal language of instruction are exempt from this requirement. The program does not currently require the GRE for admission.</br>

### Admission to the Program
Minimum requirements for admission to the MA in Communication Studies are a baccalaureate degree in Communication Studies or a related field, usually in the social sciences, humanities, or arts. A 3.0 grade point average (B or better) is desired. Depending on their level of preparation, applicants may be admitted in either classified or conditionally classified standing.</br>
See how to apply for the MA in Communication Studies.</br>

### Program Requirements for Admission to Classified Standing
To be admitted to the Master of Arts in Communication Studies program in classified status, an applicant must have a grade point average of 3.0 or better in their last 60 units, and possess a baccalaureate degree in Communication Studies, or related field in the social sciences, humanities, or arts from an accredited U.S. or international university.</br>

### Program Requirements for Admission to Conditionally Classified Standing
If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the conditions of admission  will include additional BA or MA level coursework in Communication Studies, depending on the nature of the applicant’s case. The program admissions letter will explain the terms and requirements.</br>

## Requirements for Advancement to Graduate Candidacy
Students must meet the university requirements for advancement to graduate candidacy. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies & Procedures  section. Candidacy includes the successful completion of the  Graduation Writing Assessment Requirement (GWAR) . For Communication Studies, candidates meet the GWAR requirement by taking COMM 297C , a required course that students will take in their second semester.</br>
Further requirements of the department for advancement to candidacy include completion of a minimum of 12 letter-graded units, all with grades of “C” or higher, and a minimum GPA of 3.0.</br>
Students will submit a culminating experience plan to the department’s Graduate Coordinator. If the plan is satisfactory and the student is considered to be a potentially competent and mature practitioner, they will be advanced to candidacy. Students who fail to meet the expected standards will be terminated from the program.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . </br>
This requirement is satisfied by passing COMM 297C .</br>

### Culminating Experience
Students in the MA in Communication Studies complete the program with a 1-4-unit Culminating Experience selected from three options: a master’s thesis, master’s project, or comprehensive exam.</br>
Plan A (Thesis) COMM 299 4 unit(s)</br>
Students opting to complete a master’s thesis will take 4 units of COMM 299 . The student is responsible for securing a full-time tenured or tenure-track Communication Studies faculty member to serve as thesis advisor and committee chair. In order to do this, it is recommended that the student demonstrate, in a written proposal, that they are capable of completing a thesis, both in terms of research skills and writing ability, and that they have sufficient time to undertake a major research and writing project. Demonstrating these points does not obligate a professor to serve as an advisor, and no reason need be given to a student for declining to supervise a thesis. In consultation with their thesis advisor, the student must also secure two additional university faculty members, one of whom must be a full-time tenured or tenure-track faculty member, to serve as the thesis committee. The student must write a thesis proposal (prospectus) and have it approved by the thesis committee before enrolling in COMM 299  (typically this is done through a prospectus defense.) The thesis is written under the guidance of the thesis advisor with the assistance of the committee members. The student must pass an oral defense of the thesis. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines.</br>
A thesis committee has the option of terminating the thesis option if the candidate does not submit an acceptable thesis within five semesters. In that situation, the student will be required to take the Plan B comprehensive examination as their culminating experience.</br>
Plan B (Project) COMM 298 4 unit(s)</br>
Students opting to complete a master’s thesis will take 4 units of COMM 298 . The student is responsible for securing a full-time tenured or tenure-track Communication Studies faculty member to serve as project advisor and committee chair. In order to do this, it is recommended that the student demonstrate, in a written proposal, that they are capable of completing a project, both in terms of research skills and writing ability, and that they have sufficient time to undertake a major research and writing project. Demonstrating these points does not obligate a professor to serve as an advisor, and no reason need be given to a student for declining to supervise a thesis. In consultation with their thesis advisor, the student must also secure two additional university faculty members, one of whom must be a full-time tenured or tenure-track faculty member, to serve as the thesis committee. The student must write a project proposal (prospectus) and have it approved by the thesis committee before enrolling in COMM 298 . (Typically, this is done through a prospectus defense.) The project is completed under the guidance of the project advisor with the assistance of the committee members. The student must pass an oral defense of the project.</br>
Plan C (Comprehensive Exam) COMM 298 1 unit(s)</br>
Most students will take a comprehensive exam as the culminating experience. Students taking exams will enroll in 1-unit of COMM 298 . Students taking an exam will therefore complete an additional 4 units of coursework.</br>

## Master’s Requirements (32 units)
The program is offered in a hybrid and a fully online track. Students may switch from the online to hybrid track by completing the Change of Graduate Program Petition.</br>
In addition to three core courses taken during the first year of the program, students are required to complete coursework in three areas: theoretical foundations of one or more divisions within communication studies; specific research methods/modes of inquiry; and engagement with theories and methods through applied practice.</br>

### Core Courses (12 units)
Offered synchronously online.</br>

- COMM 200C - Graduate Study in Communication 4 unit(s)</br>

- COMM 201C - Methods and Methodologies of Communication Studies 4 unit(s)</br>

- COMM 297C - Advanced Writing Workshop 4 unit(s) (GWAR)</br>


### Seminars (12 units)
Offered online only. </br>
Complete a minimum of 4 units from each area (Foundations, Inquiry, and Practice).</br>

#### Foundations (Theory) Seminar Courses (4 units)

- COMM 210F - Interpersonal Communication 4 unit(s)</br>

- COMM 222F - Performance and Culture 4 unit(s)</br>

- COMM 244F - Organizational Communication 4 unit(s)</br>

- COMM 249F - Rhetorical Theory 4 unit(s)</br>

- COMM 250F - Communication Theory: Critical and Interpretive 4 unit(s)</br>

- COMM 255F - Seminar in Communication Theory 4 unit(s)</br>

- COMM 274F - Intercultural Communication 4 unit(s)</br>


#### Inquiry (Research Methods) Courses (4 units)

- COMM 221I - Performing Narratives 4 unit(s)</br>

- COMM 245I - Communication Criticism 4 unit(s)</br>

- COMM 295I - Special Topics in Communication Inquiry 4 unit(s)</br>


#### Practice (Applied) Courses (4 units)

- COMM 282P - Communication Pedagogy 4 unit(s)</br>

- COMM 285A - Teaching Associate Practicum I 2 unit(s)</br>

- COMM 285B - Teaching Associate Practicum II 1-3 unit(s)</br>


### Advanced Specialization/Electives (4 units)

- Additional 200-level seminar (see above) 4 unit(s)</br>

- COMM 193 - Activity Projects in Intercultural/International Communication 1-3 unit(s) (Requires instructor consent.)</br>

- COMM 280 - Independent Study 1-4 unit(s) (Requires instructor consent.)</br>

- COMM 291 - Communication Studies Graduate Internship Program 1-4 unit(s) (Requires instructor consent.)</br>

- Study Abroad units from other departments. 1-4 unit(s) (Requires approval from Graduate Program Director.)</br>

- 200-level course from a program other than Communication Studies. 1-4 unit(s) (Requires approval from Graduate Program Director.)</br>


### Culminating Experience (4 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A Thesis, Plan B Project, or Plan C Comp Exam).</br>

#### Plan A (Thesis) (4 units)
Students opting to complete a Thesis register for 4 units of COMM 299 .</br>

- COMM 299 - Master’s Thesis 1-6 unit(s) Requires instructor consent.</br>


#### Plan B (Project) (4 units)
Students opting to complete a Project register for 4 units of COMM 298 .</br>

- COMM 298 - Master’s Project or Comprehensive Exam 1-4 unit(s) Requires instructor consent.</br>


#### Plan B (Comprehensive Exam) (4 units)
Students opting to take Comprehensive Exams register for 1 unit of COMM 298  and complete 3 units of additional coursework (Seminars or Electives) to earn a minimum of 32 total units.</br>

- COMM 298 - Master’s Project or Comprehensive Exam 1-4 unit(s)</br>

- Additional seminar or elective chosen from above. 3 unit(s)</br>


## Total Units Required (32 units)
In order to graduate, students must achieve a minimum grade point average of 3.0 in both their candidacy coursework and in their SJSU cumulative coursework.</br>
Seminar substitution: when deemed necessary for extenuating circumstances or a specific course of study, students may substitute an F, I, or P seminar for a seminar from another category (i.e., an F for a P, and I for an F. etc.) with the approval of the Graduate Program Director. </br>
Credit for undergraduate coursework: Students may earn up to 4 units of coursework for study abroad (COMM 193 /COMM 195 ). In rare circumstances, students may argue for the inclusion of an upper division undergraduate course other than study abroad, such as COMM 198  or an F, I, or P course in a specific area of study. Students must demonstrate the importance of the course to their program of study and receive approval from the Graduate Program Director.</br>
All 295 courses may be repeated for credit for up to 8 units. </br>
Core substitution: In rare circumstances, students may substitute a core course from another MA Program with the approval of the Graduate Program Director and the department Chair.</br>
 </br>