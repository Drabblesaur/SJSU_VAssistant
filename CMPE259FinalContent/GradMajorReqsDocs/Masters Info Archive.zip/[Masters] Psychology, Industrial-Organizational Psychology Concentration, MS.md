
# Psychology, Industrial/Organizational Psychology Concentration, MS
 </br>

- Admission Requirements</br>

- Degree Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science (MS) degree in Industrial/Organizational (I/O) Psychology program, offered by the Department of Psychology , is designed to provide students with a fundamental grounding in theory, research, and application in the field of I/O Psychology and to prepare them to work in a wide range of settings including medium-to-large sized organizations, government agencies, human resources or management consulting firms, and large research organizations. The program places particular emphasis on the science-practitioner approach in which students understand and appreciate theory and research as they apply their knowledge and skills to the needs and challenges of organizations.</br>

## Admission Requirements
To be eligible for admission into the Industrial/Organizational Psychology program, you must:</br>

- Meet all of the University graduate admissions requirements</br>

- Have completed either a baccalaureate degree (BA/BS) in psychology or any baccalaureate degree and a minimum of 30 semester (45 quarter) units in psychology</br>

- Have a minimum GPA of 3.0 in the last 60 semester units (90 quarter units) of all college and/or university course work</br>

- Have a minimum GPA of 3.0 in all college and/or university psychology courses taken</br>


## Degree Requirements
General university requirements and procedures for completing the Master of Science degree are described in the Academic Regulations section of this catalog . In addition to these, the following departmental requirements must be fulfilled.</br>

- The student must complete a total of not less than 30 semester units for the industrial/organizational concentration as specified in the degree below.</br>

- Candidates in the MS Industrial/Organizational program must complete a thesis or thesis project as part of their 30 semester unit degree requirement. The nature of the thesis is to be determined in consultation with a committee of three committee members. The thesis ordinarily consists of a quantitative investigation. The thesis will generally constitute the final comprehensive examination.</br>

- The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . Courses that satisfy the GWAR are listed in the course requirements for the program.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- PSYC 240 - Research Design and Applied Psychometrics 3 unit(s)</br>

- PSYC 249 - Field Work in Industrial/Organizational Psychology 1-6 unit(s) (3 units required)</br>

- PSYC 270 - Seminar in Industrial and Organizational Psychology 3 unit(s) (GWAR)</br>

- PSYC 271 - Seminar in Personnel Psychology 3 unit(s)</br>

- STAT 235 - Multivariate Analysis 3 unit(s)</br>


### Electives (9 units)

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one course from:</br>

- PSYC 298 - Special Problems 1-6 unit(s)</br>

- PSYC 299 - Master’s Thesis 1-6 unit(s)</br>


## Total Units Required (30 units)
 </br>