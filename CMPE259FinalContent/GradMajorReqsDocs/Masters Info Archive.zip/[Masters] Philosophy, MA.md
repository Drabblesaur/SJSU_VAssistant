
# Philosophy, MA
 </br>

- Requirements for Admission to Classified Standing</br>

- Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy for the MA - Philosophy</br>

- Completing Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MA Philosophy program is offered by the Department of Philosophy .</br>
Advisors: Dr. Carlos A. Sanchez</br>

## Requirements for Admission to Classified Standing
Candidates must meet all university requirements for admission. In addition, a student will be admitted to classified status only if:</br>

- At least 18 units in philosophy have been taken including at least 6 units in upper-division work, at least 6 units in the history of philosophy, at least 3 units in ethics, and at least 3 units of symbolic logic (Phil 9 or its equivalent). Exceptions based on comparable studies and experience may be made with graduate committee approval.</br>

- The average grade received in the 18 units is at least a “B”.</br>

- Three letters of recommendation have been submitted.</br>


## Admission to Conditionally Classified Standing
Applicants who meet the requirements for admission to the Graduate Division but who do not meet all the requirements for classified standing will be admitted as conditionally classified.</br>

## Requirements for Advancement to Candidacy for the MA - Philosophy
The basic requirements for advancement to candidacy  for the MA Philosophy are outlined in detail in the Academic Requirements section. The University requires that all graduate students satisfy the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

## Completing Requirements

### Plan A - Thesis
Designed for students who wish to do a thesis.</br>

### Plan B - Option 1: Reading Intensive
Designed for students who wish to do a guided, individualized reading project.</br>

### Plan B - Option 2: Applied Philosophy Project
Designed for students who wish to do a project.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- PHIL 289 - Graduate Proseminar 3 unit(s)</br>

- PHIL 290 - Advanced Seminar in a Selected Philosopher or Tradition 3 unit(s) (GWAR)</br>

- PHIL 291 - Advanced Seminar in Epistemology and Metaphysics 3 unit(s) (GWAR)</br>

- PHIL 292 - Advanced Seminar in Ethics or Aesthetics 3 unit(s)</br>


#### Complete One Course From:

- PHIL 157 - Intermediate Logic & Language Analysis 3 unit(s)</br>

- PHIL 293 - Advanced Seminar in Logical Theory 3 unit(s)</br>


### Elective Courses (12 units)
One or more of 290, 291, 292, and 293 may be repeated as electives when the course content is different</br>

- 100- or 200-level courses within the department</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Comprehensive Exam

#### Choose One Plan

- PHIL 299 - Master’s Thesis 3 unit(s)</br>

- PHIL 298 - Special Studies 1-3 unit(s)</br>

- PHIL 298 - Special Studies 1-3 unit(s) (3 units required)</br>


## Total Units Required (30 units)
 </br>