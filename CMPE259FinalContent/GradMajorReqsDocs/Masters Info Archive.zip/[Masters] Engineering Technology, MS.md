
# Engineering Technology, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Engineering Technology degree program, offered by the Department of Aviation and Technology , prepares students with advanced managerial, leadership, analytical and business-based skill sets to improve the way an organization functions. Engineering technologists gain the ability to contribute to an organization’s success by improving processes and systems, identifying and meeting customers’ needs and assuring high quality of products and services through application of engineering principles and proper analytical tools and technical skills.</br>
Various organizations, from global manufacturing corporations, government organizations, and industrial enterprises to small service-oriented businesses, such as healthcare systems, manufacturing operations, network and security systems, and educational institutions, can benefit from implementing engineering technology principles and approaches. Students are required to have completed a BS in a STEM-related major such as Engineering, Physics, Mathematics or Business with a strong analytical background. </br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system. Applicants must meet all university admission requirements. See the Graduate Admissions  section for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE. For TOEFL Requirements, see the Graduate Admissions   section of this catalog.</br>

### Requirements for Admission to Classified Standing
The Department of Aviation and Technology admits students to the Master of Science in Engineering Technology program in Classified or Conditional Standing. Contact the department or see our admissions materials for specific application deadlines. For admission to classified standing the department requires the following:</br>

- A baccalaureate degree from an accredited academic institution in a technical or scientific discipline. Individuals from non-accredited or non-technical disciplines who demonstrate exceptional promise may be conditionally admitted to the graduate program;</br>

- Transcripts from an academic institution which verify a minimum grade point average of 3.0 in the last 60 upper-division university units;</br>

- Evidence of written and oral communication skills essential to meet the demands of graduate-level study and research. A well-written personal statement is often used for partial verification of these competencies; this statement should discuss the applicant’s career plans and make note of how the master’s degree will enhance career objectives; and</br>

- Foreign students must present a TOEFL score of at least 550.</br>


### Requirement for Admission to Conditionally Classified Standing
Applicants from non-technical disciplines may be conditionally admitted to the graduate program pending completion of additional undergraduate course work as prescribed by the program graduate coordinator. Students who are conditionally classified may seek admission to classified standing only after completion of nine units of graduate-level coursework with a minimum grade point average of 3.0. The individual admission letter will explain required terms and conditions for attaining Classified standing.</br>

## Requirements for Advancement to Candidacy
General university requirements for advancement to candidacy  for the Master of Science degree are outlined in the Academic Regulations section of this catalog. After successfully completing a minimum of 12 graduate units, with a minimum grade point average of 3.0, and satisfied the university GWAR, students must finalize their programs of study with the guidance of the Program’s Graduate Advisor.</br>
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Successfully passing TECH 200  course meets the GWAR requirement.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
In consultation with the department graduate advisor, the candidate will develop and pursue a program of study. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approval Program.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students choose a Plan A (Thesis) or Plan B (Project) option as their program culminating experience. </br>
Plan A (Thesis)</br>
Students opting to complete a thesis enroll in six units of TECH 299 . They must secure the commitment of three faculty members of the department, college or university, two of whom must be members of the faculty (permanent or part-time), to serve as members of the student’s Plan A (thesis) committee, with one permanent faculty member agreeing to serve as chair. The committee must approve the student’s thesis proposal for the master’s degree no later than one semester prior to the end of the semester preceding the one in which enrollment in the final thesis course is planned. The thesis will include original research on a topic approved by the thesis committee, and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will undergo a thorough review and revision process under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. In addition, the candidate for the MS degree must successfully pass a final oral defense of the thesis. This includes a one-hour professional presentation with applicable slides outlining the work performed including an introduction, background and review of the relevant previously published literature, methodology, analysis/experiment/simulation, results and discussion, followed by conclusion(s).</br>
Plan B (Project)</br>
Students opting to complete a project enroll in TECH 295A (3 units) and TECH 295B (3 units). They must secure the commitment of three faculty members of the department, college or university, two of whom must be members of the faculty (permanent or part-time), to serve as members of the student’s Plan B (Project) committee, with one permanent faculty member agreeing to serve as chair. The committee must approve the student’s project proposal for the master’s degree no later than one semester prior to the end of the semester preceding the one in which enrollment in the final project course is planned. The project will include original research on a topic approved by the project committee. It will undergo a thorough review and revision process under the guidance of the candidate’s project committee chair and with the assistance of the committee members. In addition, the candidate for the MS degree must successfully pass a final oral defense of the project. This includes a one-hour professional presentation with applicable slides outlining the work performed including an introduction, background and review of the relevant previously published literature, methodology, analysis/ experiment/simulation, results and discussion, followed by conclusion(s).</br>

## Master’s Requirements (30 units)

### Required Courses (9 units)

- TECH 200 - Research Methods for Engineering and Technology 3 unit(s) (GWAR)</br>

- TECH 230 - Six-Sigma and Continuous Improvement Systems Management 3 unit(s)</br>

- TECH 233 - Design and Analysis of Experiments 3 unit(s)</br>


### Specialization Area (9 units)
Complete 3 courses in one Specialization Area: Smart Manufacturing or Applied Networks Systems</br>

- Smart Manufacturing Specialization</br>

Smart Manufacturing Specialization</br>

- TECH 235 - Measurement Systems and Analysis 3 unit(s)</br>

- TECH 239 - Technology Product Management 3 unit(s)</br>

- TECH 241 - Application of Artificial Intelligence in Manufacturing 3 unit(s)</br>

- TECH 244 - Selective Laser Melting Process 3 unit(s)</br>

- TECH 245 - Advanced Solid-State Welding/Joining Processes 3 unit(s)</br>

- Applied Network Systems Specialization</br>

Applied Network Systems Specialization</br>

- TECH 231 - Systems Reliability and Maintainability 3 unit(s)</br>

- TECH 236 - Foundations in Quality Assurance for Software 3 unit(s)</br>

- TECH 273 - Computer and Network System Auditing 3 unit(s)</br>


### Approved Electives (6 units)
Complete 2 courses from the following</br>

- TECH 172 - Database Server System Management 3 unit(s)</br>

- TECH 174 - Blockchain Technology and Applications 3 unit(s)</br>

- TECH 175 - Industrial Internet of Things (IIoT) 3 unit(s)</br>

- TECH 176 - Machine Learning Technology and Applications 3 unit(s)</br>

- TECH 177 - Data Science in Industrial Systems Management 3 unit(s)</br>

- TECH 234 - Quality Systems Management: ISO 9000 and 14000 3 unit(s)</br>

- TECH 236 - Foundations in Quality Assurance for Software 3 unit(s)</br>

- TECH 251 - Cybersecurity Operations Management 3 unit(s)</br>

- A graduate level course (from another department) with Graduate Advisor’s approval</br>

A graduate level course (from another department) with Graduate Advisor’s approval</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (Thesis)

- TECH 299 - Master’s Thesis 2-6 unit(s) (6 units required)</br>


#### Plan B (Project)

- TECH 295A - Engineering Technology Project I  (3 units)</br>

- TECH 295B - Engineering Technology Project II  (3 units)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>