
# Creative Writing, MFA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Master’s Requirements (44 units)</br>

- Program Learning Outcomes  </br>

The Master of Fine Arts degree in Creative Writing, offered by the Department of English and Comparative Literature , is the recognized terminal degree that offers the minimum professional training deemed necessary by the major schools in the United States for university and college teaching and for positions in the publishing industry. It is also the degree most frequently held by professional writers.</br>
For additional information, please see the MFA program website.</br>

## Admissions Requirements

### Requirements for Admission to Classified Standing
Applicants must meet university requirements for admission  to the Graduate Division and classified standing as outlined in this catalog. In addition, they must meet the following department requirements:</br>

- Earned a 3.0 grade point average in major courses.</br>

- Demonstrate ability in Creative Writing by submitting a creative writing portfolio in Fiction (20-30 pages), Creative Nonfiction (20-30 pages), Poetry (10 pages), or Scriptwriting (20-30 pages).</br>

- Be approved by the departmental MFA in Creative Writing Committee. For each annual cycle, applications are due by February 1, when the review will begin.</br>

Achieved one of the following:</br>

- Possess a bachelor’s degree or master’s degree in English, Creative Writing, or a related field from an accredited institution.</br>

- Passed a minimum of 12 semester hours in English, Creative Writing, or a related field beyond freshman composition.</br>

- Demonstrated equivalent literary training or experience as determined by the Director of the MFA in Creative Writing Program.</br>

Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Requirements for Admission to Conditionally Classified Standing
Students who do not qualify for classified standing but who meet university requirements for graduate admission and whose past performance and creative writing ability give promise of satisfactory completion of requirements for admission to classified graduate standing may, with the approval of the departmental MFA in Creative Writing Committee, be admitted as conditionally classified in the MFA program.</br>

## Requirements for Advancement to Graduate Candidacy
Candidacy denotes that the classified graduate student is fully qualified to complete the final stages of the MFA in Creative Writing program and is thus eligible to enroll in ENGL 291  and ENGL 299 . In order to advance to candidacy, the student must meet the university requirements for advancement to candidacy  as outlined in this catalog. The university requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Most graduate-level literary seminars meet the GWAR. In addition, the student must:</br>

- complete 24 units of an approved 44-unit program with a GPA of 3.0 or better. At least one-half of these units must be graduate-level (i.e., 200-numbered) courses. Any upper-division courses to be applied to the MFA must be approved in advance by the MFA Director.</br>

- formalize his or her MFA thesis committee by obtaining the signatures of three university faculty members (two must be members of the Creative Writing or English faculty) to serve as members of the student’s committee. A tenure-line Creative Writing faculty member who teaches in the student’s major area of emphasis must serve as chair.</br>

- propose to write a substantial full-length work, with critical introduction or preface (see below), in one of the four program emphases: Poetry, Fiction, Nonfiction, or Script Writing.</br>

- sign up to take the MFA Comprehensive Examination, which a student must pass before an MFA degree is awarded.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . </br>

### Culminating Experience
All candidates for the MFA degree in Creative Writing must complete a book-length thesis in their primary genre. The thesis must be approved by a three-member committee, of which at least two members must be full-time SJSU faculty. Thesis committees and projects are declared in the Departmental Thesis Proposal, which is submitted to the Graduate Committee of the Department of English & Comparative Literature the semester before the candidate registers for four units of ENGL 299D  or ENGL 299 .</br>
At the time of filing for candidacy, MFA candidates must select from two options for filing the final documents. Plan A (Thesis), which we refer to as a University Thesis, will require enrollment in ENGL 299 , and the resulting thesis will be reviewed by the College of Graduate Studies and published online, as described below. Plan B (Project), which the Department of English and Comparative Literature refers to as a Departmental Thesis, will require enrollment in ENGL 299D  and is considered by the university as a “project” and thus not subject to review by the College of Graduate Studies nor to the policy requiring university theses to be published. Please note that the departmental requirements for the thesis itself as well as the composition of the thesis committee are the same under both options.</br>
Candidates select their Thesis Plan on the Petition for Advancement to Graduate Candidacy form, typically submitted the semester prior to graduation (e.g., in October for May graduation, or in April for December graduation). Although the Candidacy Form lists three plans – A, B, and C – MFA candidates may select only Plan A or Plan B.</br>
Plan A (Thesis): University Thesis</br>
After approval by the three-member thesis committee, MFA candidates submit the final manuscript as a PDF to the University’s College of Graduate Studies, where it is checked for format. Once certified by Graduate Studies, the PDF is published in two places: on ProQuest (a commercial academic publisher) and on ScholarWorks (the University’s open-access repository). Distribution through these two channels assures that research generated by SJSU students is available to as many readers as possible. Candidates who wish to shield their work from public view temporarily, for example, to allow time for commercial publication, can request an embargo of up to five years. After the embargo expires, candidates can ask for an extension or allow the document to be released online. It is possible for access to be restricted to users of the SJSU campus network. Embargo and access options are chosen by candidates when they submit their theses to Graduate Studies.</br>
Only theses submitted via Plan A are eligible for the University’s Outstanding Thesis Award, a distinction given annually to the one or two exceptional theses in the entire university. The award is presented at graduation and includes a monetary stipend. Candidates should ask their thesis directors or department chairs for more information about this award.</br>
Plan B (Project): Departmental Thesis</br>
Under this option, the thesis manuscript is prepared according to University guidelines and approved by a three-member thesis committee, and then signed off by the Chair of the Graduate Committee and the Department Chair. The manuscript is not submitted to the College of Graduate Studies. Instead, candidates must deposit a printed, bound copy of their thesis in the collection of the Department of English & Comparative Literature and, optionally, on the thesis shelf of the University Library (binding paid for by the candidate). Because the Departmental Thesis is never published online, this option makes sense for MFA candidates who wish to give their work the maximum possible protection. It is recommended for those students who wish to protect the copyright of their creative work for future publication.</br>
Departmental Theses are neither eligible for the University’s Outstanding Thesis Award nor for nomination to the Proquest Thesis Award.</br>

## Master’s Requirements (44 units)

### Core Courses (4 units)

- ENGL 291 - Lit Practicum 4 unit(s)</br>


### Workshops (20 units)
Complete 12 units in primary genre and 8 units in secondary genre from the following.</br>
The workshop courses are all repeatable for credit as long as the topic has changed:</br>

- ENGL 240 - Poetry Writing Workshop 4 unit(s)</br>

- ENGL 241 - Fiction Writing Workshop 4 unit(s)</br>

- ENGL 242 - Nonfiction Writing Workshop 4 unit(s)</br>


### Literary Research (8 units)

- ENGL 202 - Poetic Craft and Theory 4 unit(s)</br>

- ENGL 203 - Narrative Craft and Theory 4 unit(s)</br>

- ENGL 204 - Seminar in Modern Approaches to Literature 4 unit(s) (GWAR)</br>

- ENGL 208 - Seminar in Comparative Literature 4 unit(s) (GWAR)</br>

- ENGL 211 - Seminar in Twentieth Century Poetry 4 unit(s) (GWAR)</br>

- ENGL 215 - Seminar in Myth and Symbolism 4 unit(s) (GWAR)</br>

- ENGL 216 - Seminar in Medieval English Literature 4 unit(s) (GWAR)</br>

- ENGL 224 - Studies in English Early Modern Literature 4 unit(s) (GWAR)</br>

- ENGL 225 - Seminar in Shakespeare 4 unit(s) (GWAR)</br>

- ENGL 228 - Seminar in Genre Studies 4 unit(s) (GWAR)</br>

- ENGL 230 - Seminar in Thematic Studies in British Literature 4 unit(s) (GWAR)</br>

- ENGL 232 - Seminar in Form and Genre Studies in British Literature 4 unit(s)</br>

- ENGL 233 - Seminar in Period Studies of British Literature 4 unit(s) (GWAR)</br>

- ENGL 253 - Seminar in Period Studies of American Literature 4 unit(s) (GWAR)</br>

- ENGL 254 - Seminar in Genre Studies of American Literature 4 unit(s) (GWAR)</br>

- ENGL 255 - Seminar in Thematic Studies of American Literature 4 unit(s) (GWAR)</br>

- ENGL 256 - Seminar in Twentieth Century British Literature 4 unit(s) (GWAR)</br>


### Professional Development (8 units)

- ENGL 133 - Reed Magazine 4 unit(s)</br>

- ENGL 257 - Seminar in the History of Rhetoric 4 unit(s)</br>

- ENGL 259 - Seminar in Composition Studies 4 unit(s)</br>

- ENGL 298 - Special Study 1-6 unit(s)</br>

- Other literary research classes with consent of advisor</br>


### Culminating Experience (4 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan A (Thesis)

- ENGL 299 - University Thesis 1-6 unit(s) (4 units required)</br>

- Comprehensive Exam</br>


#### Plan B (Project)

- ENGL 299D - Departmental Thesis 1-6 unit(s) (4 units required)</br>

- Comprehensive Exam</br>


## Total Units Required (44 units)
*Note that College of Graduate Studies requires all creative works that serve as theses (novels, poetry collections, screen plays, and so forth) to be accompanied by a preface. At a minimum of 10 pages, the preface should put the creative work in historical, cultural, literary, or other contexts. It should also expound on the literary influences on the student. The text must be written according to a style guide, MLA being the guide of choice in the English and Comparative Literature Department, and include formal literature citations and a References Cited section, both written in accordance with the style guide rules.</br>
Elective courses must be planned in consultation with the English MA Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>