
# Geology, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MS program provides graduates with advanced training in the Geosciences, culminating in the completion of an independent research thesis project. The academic curriculum and extensive faculty expertise provide the opportunity for study in many areas of the Geosciences. Graduates are employed as environmental consultants, engineering geologists, hydrogeologists, hydrologists, and geotechnical engineers.</br>
The Department of Geology  welcomes students with undergraduate degrees in other disciplines.</br>
For more information visit the SJSU Geology website.</br>

## Admission Requirements
Candidates must meet all university admission requirements . Students can be admitted in either classified or conditionally classified standing. If an applicant’s preparation for advanced graduate work is considered insufficient to meet the course prerequisites or other departmental requirements (typically because the student does not have a BS in Geology or related field), the conditions will include taking the core Geology BS courses to meet their requirements.</br>
The GRE is not required.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

## Requirements for Advancement to Graduate Candidacy

### University Candidacy Requirements
A student is eligible for advancement to candidacy for the MS degree in Geology after the student has fulfilled the general all-university requirements for advancement to candidacy  as outlined in the Graduate Policies and Procedures  section of this catalog and the department requirements. Candidacy includes the successful completion of the  Graduation Writing Assessment Requirement (GWAR) . In addition, the student’s approval of the candidacy must be done by the departmental graduate advisor.</br>

### Department Candidacy Requirements
The student will prepare a written thesis proposal in consultation with her/his thesis adviser. The student will defend her/his proposal in an oral examination with her/his thesis advisor and a minimum of two other thesis committee members</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Geology Department Requirements
An approved program for each candidate may be designed in consultation with the advisor on the basis of each individual’s objectives. The program shall include at least 30 semester units earned beyond the bachelor’s degree in 200-level and 100-level courses approved for graduate credit. This total includes 4 semester units of thesis research. At least 12 units must consist of 200-level courses. All students are required to take a 2-unit seminar (GEOL 285 ). All candidates are required to submit a master’s thesis.</br>
An oral presentation of thesis research is to be made before an open meeting of the Geology Department. The thesis must be approved by the student’s thesis committee and submitted in final form, as defined in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines, to the Graduate Division of the university in accordance with published deadlines.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core (14 units)

- GEOL 285 - Seminar 2 unit(s)</br>


#### Complete Twelve Units From:

- GEOL 213 - Advanced Igneous and Metamorphic Petrology 4 unit(s) (GWAR)</br>

- GEOL 214 - Volcanology 4 unit(s)</br>

- GEOL 222 - Advanced Sedimentary Geology 4 unit(s)</br>

- GEOL 231 - Advanced Structural Geology and Tectonics 4 unit(s) (GWAR)</br>

- GEOL 234 - Advanced Geomorphology 4 unit(s) (GWAR)</br>

- GEOL 238 - Advanced Hydrogeology 4 unit(s) (GWAR)</br>

- GEOL 242 - Advanced Paleontology 4 unit(s)</br>

- GEOL 255 - Advanced Geology 4 unit(s)</br>


### Electives (12 units)
Other 100-level or 200-level courses, selected with advisor approval. GEOL 285  may be taken a second time.</br>

### Culminating Experience (4 units)
Program departments are required to certify when Plan A has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Plan A (Thesis)</br>

- GEOL 297 - Graduate Research in Geology 1 unit(s) (3 units required, 1 of GEOL 297   in each of three semesters is recommended) </br>

- GEOL 299 - Master’s Thesis 1 unit(s)</br>

- Thesis Defense (oral presentation)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Geology Department Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>