
# Occupational Therapy, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (72 units)</br>

- Program Learning Outcomes  </br>

The SJSU Department of Occupational Therapy  offers the oldest accredited OT program in the CSU system. Founded in 1943, the Master of Science in Occupational Therapy (MSOT) degree program is designed for those who have already earned a baccalaureate degree in another field. The program of study enables students to obtain the education and degree necessary to be eligible to practice as an occupational therapist. Once the MS degree in Occupational Therapy is complete, including the successful completion of the OCTH 201A  and OCTH 201B  courses, the student is eligible to sit for the national certification examination. Successful completion of the examination qualifies the candidate to apply for national certification and state licensure.</br>
The MOST program is accredited by the Accreditation Council for Occupational Therapy Education (ACOTE), located at 7501 Wisconsin Ave., Suite 510E, Bethesda, MD 20814. ACOTE’s telephone number is (301) 652-6611. National Board for Certification in Occupational Therapy (NBCOT) School Program Performance Data is also available on the NBCOT website.</br>
See the department website for more information.</br>

## Admission Requirements
The curriculum of the Master of Science in Occupational Therapy degree program is designed for those who have already earned a baccalaureate degree in another field. The program of study enables students to obtain the education and degree necessary to be eligible to practice as an occupational therapist. Once the MS degree in Occupational Therapy is complete, including the successful completion of the OCTH 201A  and OCTH 201B  courses, the student is eligible to sit for the national certification examination. Successful completion of the examination qualifies the candidate to apply for national certification and state licensure. Applications are accepted October 1 - March 1 for the subsequent Fall semester. It is important that students apply as early as possible.</br>

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements . Applicants apply separately to the Occupational Therapy Centralized Application Service (OTCAS) and to the department to obtain admission into the Occupational Therapy program. See the Graduate Admissions website and this Catalog  for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the English Language Proficiency Requirement .</br>

### Admission to Classified Graduate Standing
Prospective students must meet the following prerequisites. All prerequisite courses must be completed before acceptance into the program:</br>

- Cumulative GPA of 3.0 (on 4.0 scale) in the last 60 semester units (or 90 quarter units) of coursework and a minimum grade of B or better for all prerequisite courses.</br>

- Minimum of 80 hours of volunteer experience or equivalent paid work experience preferably in 2 different types of therapeutic settings; 60 of the hours must be completed under the supervision of an occupational therapist. The additional 20 hours must be completed in a community service setting. Hours must be verified by a supervisor on the Evaluation Form for Volunteer Experience available on the Department of Occupational Therapy website; forms are submitted at the time of application.</br>

- Completion of Student Information Form available on the OTCAS and subsequent submission of the first page of the OTCAS application form and the general essay from the OTCAS application directly to the Occupational Therapy department.</br>

- Human Anatomy with human cadaver laboratory (virtual laboratory acceptable), 3 semester units or 4 quarter units. Course must be taken within 7 years of application to the program.</br>

- Physiology with laboratory, 3 semester units or 4 quarter units.</br>

- General psychology course, 3 semester or 4 quarter units.</br>

- Introductory Sociology or Cultural Anthropology course, 3 semester or 4 quarter units.</br>

- Abnormal Psychology course, 3 semester or 4 quarter units.</br>

- College-level skills course which may be taken through adult education. The purpose of the course is to have students work with an artistic medium. Acceptable courses include Ceramics, painting, weaving, graphic arts and woodworking. Previous work may be accepted as fulfilling this requirement at the discretion of the Admissions Committee.</br>

- Statistics course, either an upper-division course offered by the departments of education, social sciences, psychology or division of health professions or a lower division statistics course that covers correlations and analysis of variance, 3 semester or 4 quarter units. Course must be completed within seven years of the application.</br>

- Neuroanatomy - Course available online via Open University through the SJSU Occupational Therapy department. Courses from other institutions may also be acceptable at the discretion of the Admissions Committee. Accepted list of courses available on the OT Program website. 3 semester or 4 quarter units.</br>

- Evidence of an understanding of occupational therapy and defined career goals in relation to the profession as stated on the Student Information Form and/or accompanying personal written statements (see #3 above).</br>

- Ability to write as demonstrated in the student information form (see #3 above), transcripts of all previous work submitted and any correspondence.</br>

- Three letters of recommendation from former instructors, employers, supervisors, or other individuals knowledgeable about the candidate’s academic abilities, capacity for goal-directed behavior, and the ability to integrate and synthesize ideas. One letter must be from an academic instructor.</br>

All prerequisite courses must be completed before acceptance into the program. All transcripts must be sent to OTCAS in addition to the University. For current admission procedures, please visit the Occupational Therapy Department website.</br>
These requirements exist for all prospective students holding baccalaureate degrees in other disciplines. The department reviews completed files and makes recommendations for acceptance or denial to the SJSU Admissions Office.</br>

## Requirements for Advancement to Candidacy
Matriculated graduate students must submit a Petition for Advancement to Graduate Candidacy a minimum of one semester prior to graduating. General university requirements for advancement to candidacy  are detailed in the Graduate Policies and Procedures section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. Successful completion of OCTH 245 , including passing the final written paper in this course with a grade of “B” or better, fulfills the GWAR in this program.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
In consultation with the department graduate coordinator, the candidate will develop and pursue a program of study. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approval Program.</br>

### Global Experience
To satisfy the Department’s International Experience  requirement, students may participate in an international experience. Alternatives to the requirement must be approved by the Occupational Therapy department. Specific details can be found on the department’s website.</br>

### Culminating Fieldwork Requirement
Following completion of the academic coursework (60 units), students must be enrolled in and complete two Fieldwork Courses, OCTH 201A  and OCTH 201B , prior to the University awarding the Master of Science degree in Occupational Therapy.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan B (Project)</br>
Students in this program fulfill their culminating experience requirement with a Plan B (Project). The Comprehensive Master’s project requires critical analysis and synthesis of information gathered, crafted into a publishable paper with a poster and oral presentation. Students will enroll in 3 units of  OCTH 295 - Advanced Research Methods in Occupational Therapy  which supports inquiry into advanced topics in occupational therapy practice, including theoretical and clinical problems.</br>

## Master’s Requirements (72 units)

### Core Courses (57 units)

- OCTH 211 - Historical and Theoretical Foundations of Occupational Therapy 3 unit(s)</br>

- OCTH 212 - Occupations through the Lifespan 3 unit(s)</br>

- OCTH 213 - Professional Development I 3 unit(s)</br>

- OCTH 216 - Evaluation in Occupational Therapy 3 unit(s)</br>

- OCTH 221 - Occupational Analysis 3 unit(s)</br>

- OCTH 222 - Functional Kinesiology for Occupational Therapists 3 unit(s)</br>

- OCTH 224 - Occupational Therapy Practice in the Community I 3 unit(s)</br>

- OCTH 226 - Occupational Therapy with Children 3 unit(s)</br>

- OCTH 233 - Professional Development II 3 unit(s)</br>

- OCTH 234 - Occupational Therapy Practice in the Community II 3 unit(s)</br>

- OCTH 236 - Occupational Therapy with Youth 3 unit(s)</br>

- OCTH 245 - Introduction to Research Methods 3 unit(s) (GWAR)</br>

- OCTH 246 - Occupational Therapy with Young Adults 3 unit(s)</br>

- OCTH 256 - Occupational Therapy with Middle Aged Adults 3 unit(s)</br>

- OCTH 266 - Occupational Therapy with Older Adults 3 unit(s)</br>

- OCTH 275 - Evidence Based Practice in Occupational Therapy 3 unit(s)</br>

- OCTH 276 - Practicum and Seminar 1A 3 unit(s)</br>

- OCTH 286 - Practicum and Seminar 1B 4 unit(s)</br>


#### Complete One Course (Chosen with Advisor):

- OCTH 210 - Seminar in Occupational Therapy 2-3 unit(s)</br>

- OCTH 210ITL - Seminar in Occupational Therapy: International Experience 2-3 unit(s)</br>


### Culminating Fieldwork (12 units)

- OCTH 201A - Field Work Experience 3-6 unit(s) (6 units required)</br>

- OCTH 201B - Advanced Field Work Experience 3-6 unit(s) (6 units required)</br>


### Culminating Experience (3 units)

- OCTH 295 - Advanced Research Methods in Occupational Therapy 3 unit(s)</br>


## Total Units Required (72 units)
 </br>