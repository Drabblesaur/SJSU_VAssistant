
# Social Work, MSW
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (37-60 units)</br>

- Program Learning Outcomes  </br>

The MSW Program offers graduate professional education in advanced generalist social work practice from a transcultural multi-systems perspective. It prepares graduates for advanced practice and leadership in areas of interest such as: health and aging; children, youth, and families; and mental health. The curriculum emphasizes the application of skills in those areas of practice where the need for social workers in the next decade will be the greatest in the State of California. The graduate program, offered by SJSU’s School of Social Work  has been fully accredited by the National Commission on Accreditation of the Council on Social Work Education since 1973.</br>
Department Website: www.sjsu.edu/socialwork.</br>

## Admissions Requirements

### University Admissions Requirements
All graduate applicants must submit a complete graduate application by applying through the CSU Cal State Apply system. Candidates must meet all university-level admissions requirements .</br>

### Program Admissions Requirements
In addition to these general requirements established by the university, applicants for admission for the Master’s of Social Work degree must demonstrate a commitment to social work goals either by having completed undergraduate social work education, or by holding a baccalaureate in a related field and having significant experience, and/or personal involvement with social issues as they relate to various marginalized groups and communities.</br>
To be admitted to the School of Social Work, an applicant must first complete the graduate application for admission to the University through Cal State Apply. The applicant then submits a separate application to the MSW program which includes:</br>

- A personal statement describing the applicant’s interest in the field and professional goals.</br>

- Three recommendations from professionals in the field or former professors who can testify to the applicant’s ability to succeed in a graduate-level academic program and his or her suitability to meet the challenges of the profession.</br>

- A description of all social work-related experience (paid, internship, and/or volunteer).</br>

- A sample of the applicant’s best writing, i.e., a paper written for an upper-division or graduate-level class, technical report, or other example of academic or professional written work.</br>

Applications to the Master’s in Social Work program and all supporting materials must be sent directly to the School of Social Work for review and recommendation by the MSW Program Admissions Committee.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirement webpage.</br>

#### Advanced Standing Option
The Advanced Standing option allows qualified candidates with a Bachelor’s degree in Social Work from an accredited program to complete the Master’s program in one summer and one academic year. Admission to Advanced Standing (AS) in the MSW Program at SJSU is competitive. The following are areas of evaluation for admission to AS. Meeting these minimum requirements does not guarantee admission into AS. Please also note our ability to offer AS and thus admission to AS is dependent on program level resources.</br>

- Bachelor’s degree in social work from a program accredited by CSWE at the time of admission or within the last 7 years;</br>

- GPA (minimum of 3.5);</br>

- Minimum grade of A- in all BSW/BASW (social work major) courses;</br>

- At least 400 hours of recent social work-related experience (cumulative internship, paid, or volunteer experience) in addition to the 400-hours requirement for the BSW degree;</br>

- Three letters of recommendation specific to qualifications for Advanced Standing, in addition to the usual scored recommender forms;</br>

- Evaluations from BSW/BASW field internships;</br>

- Personal statement; and, </br>

- Personal interview.</br>


#### Conditionally Classified Standing
An applicant who does not meet all requirements for admission in classified standing for the Master’s in Social Work may be admitted into the program on a conditionally classified basis. The MSW Program Admissions Committee may consider applicants who possess strong or considerable work experience and who can by additional preparation remedy minor academic deficiencies. Such admissions will be conditional upon completion of specific courses listed by the graduate advisor on the admission notification.</br>

## Advancement to Candidacy
Students must complete all university requirements for advancement to candidacy  for the master’s degree as outlined in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
The student will consult with the MSW graduate advisor to complete a petition for advancement to candidacy. The petition includes an official plan of study listing all courses needed to complete the requirements for the degree. The plan of study must be approved by the MSW Graduate Advisor and then by the Office of Graduate Admissions and Program Evaluations (GAPE), which notifies the student of advancement to candidacy.</br>
The student must also demonstrate an aptitude for advanced study in social work, as measured by successful completion of the Foundation Year of study, instructor appraisals, and/or evaluation of previous academic work (i.e., applicable transfer units or course substitutions).</br>

## Graduation Requirements

### University Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . Students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

#### Culminating Experience: Project (Plan B)
Candidates for the degree complete a capstone project as part of their 37-unit for Advanced Standing or 60-unit regular degree requirement. This project is a complete research study on a social work-related topic.</br>

### Program Requirements
The School of Social Work offers an On-Campus MSW Program and an Online/Hybrid MSW Program. All students in the Master’s of Social Work program must complete a total of 60 semester units of study in social work with a minimum cumulative grade point average of 3.0 overall. This includes two years (1,200 hours) of field internship in a social agency or community setting selected and approved by the MSW Field Education Committee. Students must pass all letter-graded classes with a “C” or better grade, and pass all field practicum courses with a credit “CR” grade.</br>
Students admitted in the Advanced Standing Option are required to take and clear two bridge courses and the Graduation Writing Assessment Requirement (GWAR)  during the summer before the start of the Fall semester. Once students in this program option complete these courses they enter their final year of the MSW program. </br>

#### On-Campus Program
The On-Campus MSW Program offers a Two-Year, Three-Year plan of study, and an Advanced Standing option. The Two-Year Plan requires a full-time commitment to the program. The Three-Year plan is designed for working professionals. It includes two years of field practicum and coursework spread over three academic years, with courses taught primarily in the evening but with daytime commitments for internship and some curricular programming. Both plans have similar course requirements for completing the degree.</br>
To assist matriculated students in progressing more rapidly toward their MSW degree and to increase accessibility to the course curriculum for both Two-Year and Three-Year students, the MSW Program sometimes offers courses during the summer and winter terms when the budget allows for this. The number and type of courses are dependent upon student interest and faculty resources.</br>
For detailed information on the program, see the School of Social Work Master of Social Work (MSW) webpage.</br>

#### Online/Hybrid Program (Special Session)
The Online/Hybrid MSW Program offers a two-year continuous enrollment program and an Advanced Standing option. The two-year program requires continuous enrollment (i.e., two to three academic courses and a field education course concurrently through the calendar year). In the Online/Hybrid program, academic courses are completed online (with asynchronous sessions and synchronous sessions usually on weekday evenings), and field education is completed in-person. Note that the three areas of interest are also offered in the Online/Hybrid MSW Program (children, youth, and families; mental health; and health and aging). The Online/Hybrid MSW Program degree requirements and the social work competencies covered are the same as those of the On-Campus MSW Program.</br>
Academic Programs offered through Special Session are operated by the Professional and Continuing Education (PaCE). Registration and enrollment in a Special Session must use the special session application form and will follow special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Professional and Continuing Education for more information.</br>

## Master’s Requirements

### Program Options (9-32 units)

#### Regular Program Option Foundation Core Curriculum (32 units)
Students admitted to the regular program option have the choice to complete the program in 2 years or 3 years. The 2-Year students will complete all of their Generalist (core) Curriculum in their first year of the program, whereas the 3-Year students complete the core curriculum in two years.</br>

- SCWK 200W - Social Work Graduate Writing Course 3 unit(s) (GWAR)</br>

- SCWK 202 - Social Policy and Services: History and Values 3 unit(s)</br>

- SCWK 204 - Social Policy Analysis 3 unit(s)</br>

- SCWK 212 - Human Behavior in Social Environment I 3 unit(s)</br>

- SCWK 214 - Human Behavior in Social Environment II 3 unit(s)</br>

- SCWK 220 - Transcultural Generalist Practice I 3 unit(s)</br>

- SCWK 221 - Transcultural Generalist Practice II 3 unit(s)</br>

- SCWK 230 - Social Work Practicum I 1-6 unit(s)</br>

- SCWK 231 - Social Work Practicum II 1-6 unit(s)</br>

- SCWK 240 - Research Methods and Design 3 unit(s)</br>


#### Advanced Standing Option Summer Bridge Courses (9 units)
Students admitted to the Advanced Standing Option use their Summer Bridge courses to replace the Foundation Core Curriculum courses (32 units).</br>

- SCWK 243 - Advanced Standing SW Bridge - Grad 2 unit(s)</br>

- SCWK 215 - Advanced Standing Bridge Integrated 4 unit(s)</br>

- SCWK 200W - Social Work Graduate Writing Course 3 unit(s) (GWAR)</br>


### Advanced Year Core Curriculum (12 units)

#### Transcultural Multi-Systems Areas of Interest
Elective courses must be planned in consultation with the Graduate Advisor.</br>
Students are required to take one advanced course from each bucket; Advanced Practice, Advanced Policy, and Advanced General Elective. </br>

- On-campus program: students are required to take an additional Advanced Practice Course in the Fall.</br>

- Online/hybrid students are required to take an additional Advanced Elective course in the Spring.</br>


#### Advanced Practice (3 units)
Complete one course:</br>

- SCWK 222 - Transcultural Advanced Generalist Practice I: Family Systems Focus 3 unit(s)</br>

- SCWK 223 - Transcultural Advanced Generalist Practice II: Community Systems Focus 3 unit(s)</br>

- SCWK 251 - Social Work in Health and Aging 3 unit(s)</br>

- SCWK 261 - Social Work Practice with Children 3 unit(s)</br>

- SCWK 262 - Social Work Practice with Adolescents 3 unit(s)</br>

- SCWK 265 - Child Welfare Practice in Public and Government Systems 3 unit(s)</br>

- SCWK 272 - Social Work in Educational Settings 3 unit(s)</br>

- SCWK 281 - Social Work in Mental Health 3 unit(s)</br>


#### Advanced Policy (3 units)
Complete one course:</br>

- SCWK 250 - Policy Practice in Health and Aging 3 unit(s)</br>

- SCWK 260 - Policy Practice in Child and Family Welfare 3 unit(s)</br>

- SCWK 280 - Policy Practice in Mental Health 3 unit(s)</br>


#### Advanced General Electives (6 units)
Two courses selected in consultation with graduate advisor.</br>

- SCWK 224 - Advanced Generalist Practice With Spanish Speaking Populations 3 unit(s)</br>

- SCWK 263 - Social Work and the Law 3 unit(s)</br>

- SCWK 283 - Psychopharmacology for Social Workers 3 unit(s)</br>

- SCWK 285 - Social Work and Social Problems 3 unit(s)</br>

- SCWK 285ITL - Social Work and Social Problems: International Experience 3 unit(s)</br>

- SCWK 287 - Advanced Generalist Practice in Substance Abuse 1-3 unit(s)</br>

- An additional 200-level course selected in consultation with graduate advisor.</br>


### Practicum (10 units)

- SCWK 232 - Social Work Practicum III 1-6 unit(s)</br>

- Students generally take 5 units of SCWK 232 . </br>

Students generally take 5 units of SCWK 232 . </br>

- SCWK 233 - Social Work Practicum IV 1-6 unit(s)</br>

- Students generally take 5 units of SCWK 233 . </br>

Students generally take 5 units of SCWK 233 . </br>

### Culminating Experience (6 units)

#### Project (Plan B)

- SCWK 298A - Special Study A 1-4 unit(s) (3 units required)</br>

- SCWK 298B - Special Study B 1-4 unit(s) (3 units required)</br>

- Comprehensive Examination 0 unit(s)</br>


## Total Units Required (37-60 units)
Students in the Regular Program Option complete the program with 60 units and students in the Advanced Standing Option complete the degree with 37 units. </br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>