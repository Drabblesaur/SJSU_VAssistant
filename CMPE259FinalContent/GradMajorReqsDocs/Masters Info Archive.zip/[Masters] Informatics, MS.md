
# Informatics, MS
 </br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

Informatics is an interdisciplinary and inter-professional field that focuses on collecting, analyzing, securing, and managing data and information; and turning that data and information into actionable knowledge from a user-centered perspective within the context of another domain, such as health or cybersecurity/privacy.</br>
Students will take 18 units of course work that will provide the foundations and skills needed to:</br>

- Design and develop secure user-centered knowledge structures for the Web environment using design thinking, prototyping, and human-computer interaction tools.</br>

- Set up secure digital assets management systems (DAM) working with metadata, workflow, taxonomy, data security, governance, and preservation of digital assets.</br>

- Define, identify, control, manage, secure, and preserve electronic records and information including the management of records and information as operational, legal, and historical evidence in electronic environments.</br>

- Manage projects: people, timelines, resources, goals, and outcomes.</br>

The central set of knowledge and skills obtained in the foundation and skills courses can be applied to many different domains as graduates develop their careers.</br>
For more information visit the MS Informatics website.</br>

### Requirements for Admission to Classified Standing
Candidates must meet all university admission requirements .</br>
Applicants who meet the following requirements beyond university requirements will be considered for admission into the School of Information :</br>

- A bachelor’s degree from any regionally accredited institution in any discipline with a GPA of at least 2.8 at the bachelor’s degree institution or in the last 60 semester or 90 quarter units.</br>

- Skill with HTML5 and CSS3 - or updated standards -as demonstrated via class transcripts or work experience.</br>

- The School requires that all students have computer access from home. See Home Computing Requirements.</br>

- Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>


### Requirements for Admission to Conditional Classified Standing
The School of Information does not admit students on a conditional basis.</br>

### Requirements for Advancement to Graduate Candidacy
In order to achieve candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the Informatics degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
Students must complete and submit the Petition for Advancement to Graduate Candidacy after completion of nine units and by the posted deadlines for the semester in which they plan to graduate.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
Special Session Program Information</br>
Academic Programs offered through Special Session are operated by Professional and Continuing Education. Registration and enrollment in a Special Session course or program are subject to special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements.</br>

## Master’s Requirements (30 units)

### Foundation and Skills (18 units)

- INFM 200 - Informatics: Fundamentals 3 unit(s) (GWAR)</br>

- INFM 201 - Informatics: Technology Foundations 2 unit(s)</br>

- INFM 202 - Informatics: Security Overview 1 unit(s)</br>

- INFM 203 - Big Data Analytics and Management 2 unit(s)</br>

- INFM 204 - Human Centered Design 2 unit(s)</br>

- INFM 205 - Informatics: Project Management 2 unit(s)</br>

- INFM 206 - Electronic Records: Foundations 3 unit(s)</br>

- INFM 207 - DAM: Digital Assets Management 2 unit(s)</br>

- INFM 208 - Information Security: Info Assurance 1 unit(s)</br>


### Specialization Area (9 units)
Specializations will be offered on a rotating basis: Health, and Cybersecurity and Privacy</br>

#### Health Specialization

- INFM 210 - Health Informatics 3 unit(s)</br>

- INFM 213 - Epidemiological Methods 3 unit(s)</br>

- INFM 214 - Health Data and Analytics 3 unit(s)</br>


#### Cybersecurity and Privacy Specialization

- INFM 215 - Network Security 3 unit(s)</br>

- INFM 216 - Computer Digital Forensics 3 unit(s)</br>

- INFM 217 - Tools Lab 3 unit(s)</br>


### Culminating Experience (Plan B Only) (3 units)

- INFM 211 - Informatics Culminating Project 3 unit(s)</br>


## Total Units Required (30 units)
 </br>