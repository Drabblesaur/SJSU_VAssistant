
# Computer Engineering, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

The MS-CMPE program provides students with an educational experience that combines electrical engineering and computer science with the best of academia, the high-tech industry, and Silicon Valley. The high-tech industry increasingly requires engineers to be equipped with both hardware and software development knowledge and skills. The program provides in-class theory with hands-on hardware design and software development exercises to give students the skills necessary to create contemporary microelectronic products that are typically embedded computing systems containing both hardware and software. Graduates with an MS in Computer Engineering can expect to find significant opportunities in digital and computer hardware design and verification, system-level software development, and prototyping and testing as well as technical support and marketing.</br>
Class schedules are designed for the convenience of employed engineers who wish to pursue graduate work on a part-time basis.</br>
For more information, visit https://www.sjsu.edu/cmpe/academic/ms-cmpe/.</br>

### Educational Objectives of the Graduate Program
To provide MS CMPE graduates with</br>

- advanced knowledge of the practice of computer engineering, from vision to analysis, design, validation, and deployment.</br>

- the ability to tackle complex engineering problems and tasks, using contemporary engineering principles, methodologies, and tools.</br>

- leadership skills and the ability to participate in teamwork in an environment with people of different disciplines of engineering, science, and business.</br>

- understanding of the ethical, economic, and environmental implications of their work, as appropriate.</br>

- the ability to advance successfully in the engineering profession and sustain a process of life-long learning in engineering or other professional areas.</br>

- the ability to communicate effectively in both oral and written forms.</br>


## Admissions Requirements
Candidates must meet all university admissions requirements . Applicants can be admitted in either classified or conditionally classified standing. If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the conditions will include taking preparatory courses to meet these requirements. These courses will not count as part of the master’s degree program requirements.</br>
For acceptance by the Department of Computer Engineering , the applicant must satisfy the following requirements:</br>

- Academic Background

	An applicant must have a degree equivalent to a four-year U.S. undergraduate baccalaureate degree with a GPA of 3.25 (B+) or higher in a computer-hardware related field, such as computer engineering or electrical engineering. Those with backgrounds and interests in software development should consider the MS in Software Engineering program. They will receive lower priority in admissions into the MS-Computer Engineering program than those with hardware backgrounds and interests.</br>

- Standard Test Scores

	An applicant without a baccalaureate degree from an accredited university in the United States must meet SJSU’s minimum requirements on an English-Language Proficiency Exam (TOEFL or equivalent; please visit the Graduate Program Test Requirements website at GAPE for more information). The GRE is required of any applicant whose bachelor’s degree was from a non-ABET-accredited program or whose bachelor’s degree GPA was beneath 3.0. Under rare circumstances, usually involving a minimum of 5 years of employment in hardware development, applicants are eligible for a waiver of the GRE test requirement.</br>

## Requirements for Advancement to Graduate Candidacy
Students may advance to candidacy  after completing all admission conditions and all prerequisites for the culminating experience (refer to the MS-CMPE Student Handbook) including the Graduation Writing Assessment Requirement (GWAR) . CMPE 294  satisfies the requirement in this program, although ENGR 200W  will also be accepted. If a student qualifies for a university-approved GWAR waiver, they must select an additional elective class to achieve the 33-unit program requirement.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS - Computer Engineering Graduation Requirements
To obtain an MS degree in Computer Engineering, a student must meet the following requirements:</br>

- achieve a classified student status, i.e., a conditionally admitted student must meet the admission conditions specified in the student’s admission letter;</br>

- complete all course requirements leading up to the culminating experience courses, as listed below.</br>

- complete 33 semester units of 200-level courses with a cumulative GPA of 3.0 or better. At least 27 units must be 200-level Computer Engineering courses.

	Undergraduate coursework does not count towards the master’s degree. Students may enhance their degree by adding internships (CMPE 298I ) to their plan of study.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . </br>
This requirement is satisfied by passing CMPE 294  or ENGR 200W .</br>

### Culminating Experience (Plan A or Plan B)
All students must complete one of the following culminating experiences: thesis or project. Theses and projects are completed under the supervision of an advisor.</br>
Plan A (Thesis)</br>
A master’s thesis includes original research on a topic approved by the thesis committee and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It undergoes a thorough review and revision process under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
A master’s project is a research or development effort performed by a student individually on a topic chosen by mutual agreement between an advisor and the student. The choice of project topic is also approved by the Graduate Advisor. The individual student projects could be distinct components of a larger integrated project performed by a team of students. At the end of CMPE 295B , a project report is submitted for department review, and students present their project work in a department project exposition.</br>

## Master’s Requirements (33 units)

### Core (12 units)

- CMPE 200 - Computer Architecture 3 unit(s)</br>

- CMPE 220 - System Software 3 unit(s)</br>

- CMPE 240 - Advanced Computer Design 3 unit(s)</br>


#### GWAR (3 units)
Complete one course (CMPE 294  is recommended):</br>

- CMPE 294 - Computer Engineering Seminar 3 unit(s)</br>

- ENGR 200W - Engineering Reports and Graduate Research 3 unit(s)</br>


### Area of Specialization (6 units)
Complete two courses in one of the specializations:</br>

#### System Software Architecture

- CMPE 213 - Parallel Computing 3 unit(s)</br>

- CMPE 214 - GPU Architecture and Programming 3 unit(s)</br>

- CMPE 249 - Intelligent Autonomous Systems 3 unit(s)</br>

- CMPE 281 - Intelligent Cloud Platform 3 unit(s)</br>

- CMPE 283 - Virtualization Technologies 3 unit(s)</br>


#### Network Systems

- CMPE 206 - Computer Network Design 3 unit(s)</br>

- CMPE 207 - Network Programming and Application 3 unit(s)</br>

- CMPE 208 - Network Architecture and Protocols 3 unit(s)</br>

- CMPE 209 - Network Security and Applications 3 unit(s)</br>

- CMPE 210 - Software-defined Networks and Network Functions Virtualization 3 unit(s)</br>


#### Embedded Systems

- CMPE 242 - Embedded Hardware Design 3 unit(s)</br>

- CMPE 243 - Embedded Systems Applications 3 unit(s)</br>

- CMPE 244 - Embedded Software 3 unit(s)</br>

- CMPE 245 - Embedded Wireless Architecture 3 unit(s)</br>

- CMPE 265 - High Speed Digital System Design 3 unit(s)</br>


#### Cybersecurity

- CMPE 209 - Network Security and Applications 3 unit(s)</br>

- CMPE 211 - Advanced Network Security in IoT 3 unit(s)</br>

- CMPE 219 - Cybersecurity Clinics with HCI 3 unit(s)</br>

- CMPE 279 - Software Security Technologies 3 unit(s)</br>

- CMPE 287 - Intelligent System Quality Validation 3 unit(s)</br>


#### Machine Learning Engineering

- CMPE 252 - Artificial Intelligence and Data Engineering 3 unit(s)</br>

- CMPE 255 - Data Mining 3 unit(s)</br>

- CMPE 256 - Recommender Systems 3 unit(s)</br>

- CMPE 257 - Machine Learning 3 unit(s)</br>

- CMPE 258 - Deep Learning 3 unit(s)</br>

- CMPE 260 - Reinforcement Learning 3 unit(s)</br>


### Approved Electives (9 units)
Complete one course (3 units) of any 200-level CMPE courses in the Area of Specialization except the first-choice specialization.</br>
Complete two courses (6 units) of any 200-level CMPE courses except 295 or 299 culminating experience classes, 298, or 298i. To take graduate courses in other departments, students need to consult with the MS CMPE graduate advisor.</br>
 </br>

### Culminating Experience (6 units)
Complete One Option (Plan A or Plan B)</br>

#### Plan A (Thesis) (6 units)

- CMPE 299A - Master Thesis I 3 unit(s)</br>

- CMPE 299B - Master Thesis II 3 unit(s)</br>


#### Plan B (Project) (6 units)

- CMPE 295A - Master Project I 3 unit(s)</br>

- CMPE 295B - Master Project II 3 unit(s)</br>


## Total Units Required (33 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
If the student qualifies for a university-approved GWAR waiver, they may elect to substitute the CMPE 294  (or ENGR 200W ) requirement with an elective.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>