
# Industrial and Systems Engineering, MS
 </br>

- Admissions</br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The goal of Industrial and Systems Engineering is to ensure that manufacturing or service organization systems are efficient, productive, safe, and well designed against cumulative injury, and that the systems incorporate the right tools and equipment. The Master of Science in Industrial and Systems Engineering curriculum, offered by the Department of Industrial and Systems Engineering , prepares engineers for these activities and helps achieve the goals of ISE in a manufacturing or service organization. It prepares students to bridge the gap between operations and management with courses ranging from operations planning and control, quality assurance and reliability, human factors and ergonomics, human-machine interaction, information engineering, and cost-effectiveness analysis, to organizational development and total quality management. It prepares students to enter the profession immediately or to enter a PhD program.</br>

## Admissions
Applicants must submit a complete graduate application through the CSU Cal State Apply portal and meet all the university admission requirements. See the Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.  </br>
Applicants from countries in which the native language is not English must achieve a minimum English language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE. For TOEFL Requirements, see the English Language Proficiency Requirement  section in this Catalog. </br>
Admissions to the MS ISE program include the following:</br>

- A bachelor’s degree in Industrial or Systems Engineering from an ABET-accredited University; OR</br>

- A bachelor’s degree in Engineering or Mathematical Sciences (including Mathematics, Statistics and  Computer Science) plus ISE courses specified by the Graduate Advisor to prepare for graduate work in the Department; OR</br>

- A bachelor’s degree in Natural Sciences plus ISE and MATH courses specified by the Graduate Advisor to prepare for graduate work in the Department.</br>


## Requirements for Admission to Classified Standing
Applicants must meet all university admission requirements . Applicants who meet the following requirements beyond university requirements will be considered for admission into the ISE Department. Students may be admitted in either classified or conditionally classified standing. Applicants for classified standing will ordinarily be expected to have completed work for the BS degree in industrial engineering (or its equivalent) at San José State University or another university with an accredited curriculum, with a grade point average of 3.0 (“B”) or better in the last 60 units.</br>

## Requirements for Admission to Conditionally Classified Standing
Applicants who do not have a baccalaureate degree in industrial engineering (or equivalent), but who meet university requirements for graduate admission and whose academic records or professional achievements give promise of satisfactory performance in graduate study in industrial engineering, may be admitted to Conditionally Classified standing. Applicants whose baccalaureate degrees are not in industrial engineering will be required to take additional courses (prerequisites), which will not be counted in the graduate degree program for the MS - Industrial and Systems Engineering. The GRE General Test is not required.</br>

## Requirements for Advancement to Candidacy
Students seeking MS degrees in the College of Engineering must meet the general university requirements for candidacy as outlined in the Academic Requirements section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, the candidate must demonstrate an aptitude for advanced professional work in industrial engineering, as measured by instructor appraisals, analysis of previous academic work or other appropriate means. Advancement to candidacy and approval of programs will be handled by a faculty committee and the student’s advisor.</br>

## Requirements for Graduation

### Completing Requirements for the MS - Industrial and Systems Engineering
Students who have been advanced to candidacy for master’s degrees in engineering must thereafter maintain grade-point averages of 3.0 (“B”) or better in all work taken in the graduate program, and in the minimum 30 semester units of approved graduate work. All students are required to complete a thesis, project, or pass a comprehensive examination covering either their graduate course work or major project. The general requirements for the MS - Industrial and Systems Engineering include completion of at least 30 semester hours of approved work. The course requirements consist of three core courses, four courses in a specialty area, one elective, one GWAR elective course and a culminating experience (thesis, project or comprehensive exam). Four specialty areas are offered: Production and Quality Assurance, Human Factors Engineering, Healthcare and Service Systems Engineering, and Supply Chain and Logistics Engineering.</br>

### Culminating Experience
Plan A (Thesis)</br>
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee, which consists of the chair and two other faculty members of the Department, College or University.</br>
Plan B (Project)</br>
The main purpose and hence the main scope of the MS project is to apply knowledge learned in a student’s graduate study to a real-world problem, either identified in a current industrial or business setting as a need for improvement or in an academic setting in anticipation of opportunities for potential improvement. In either case, the amount of work must at least be commensurate with a three-unit graduate lecture course. Although creating new knowledge is not expected in the project, most effective application of the knowledge learned in the student’s entire graduate program is.</br>
The MS project should be an individual project. With special approval by the Graduate Advisor, a project whose scope is too large for one student can be pursued as a set of multiple MS projects. However, the scope of work for each student must be clearly defined and separated with respect to that of the other student(s). At the end of the MS Project, each student must complete and submit an individual project report and must give an individual presentation. The student earns credit (i.e., CR) for the MS Project if and only if the project has been successfully completed and the project report and the project presentation have been satisfactorily delivered. It will be written under the guidance of the candidate’s project committee advisor. with the assistance of the thesis committee, which consists of the chair and another faculty member of the Department, College or University.</br>
Plan B (Comprehensive Exam)</br>
The Comprehensive Exam is a five-hour exam covering three core courses and two elective courses. It is an open-book and open-notes exam. Students in this option take a third elective course (amounting to a total of 9 units of approved electives).</br>

## Master’s Requirements (30 units)

### Graduation Writing Assessment Requirement (GWAR) (3 units)
Successful completion of the following courses satisfies GWAR, which is required for advancement to candidacy.</br>
There are other ways to satisfy GWAR, but they require the addition of an elective selected in consultation with the graduate advisor. For information on Graduation Writing Assessment Requirement (GWAR) .</br>

- ISE 202 - Design and Analysis of Engineering Experiments 3 unit(s) (GWAR)</br>

- ISE 212 - Human Factors Experiments 3 unit(s) (GWAR)</br>

- ISE 251 - Managing the Lean Enterprise Improvement Program 3 unit(s) (GWAR)</br>


### Core ISE Courses (9 units)

- ISE 230 - Advanced Operations Research 3 unit(s)</br>

- ISE 235 - Quality Assurance and Reliability 3 unit(s)</br>

- ISE 240 - Analytics for Systems Engineering 3 unit(s)</br>


### Courses in an ISE Specialty Area (12 units)
Four Courses from one of the following four specialty areas:</br>

- production and quality assurance,</br>

- human factors engineering,</br>

- supply chain and logistics engineering, or</br>

- healthcare and service systems engineering</br>


### Approved Electives (3 units)
Courses selected from other ISE specialty areas or approved by the graduate advisor. The following courses may not be used as electives for the MS ISE: ISE 205 , ISE 233 , and ISE 244 .</br>

### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one option (Plan A Thesis, Plan B Project, or Plan B Comprehensive Exam):</br>

#### Plan A (Thesis)

- ISE 299 - Master’s Thesis 1-4 unit(s) (3 units required)</br>


#### Plan B (Project)

- ISE 298 - Special Problems 1-4 unit(s) (3 units required)</br>


#### Plan B (Comprehensive Exam)

- Five-hour exam covering three core courses and two elective courses. Students in this option take a third elective course (a total of 9 units approved electives)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>