
# Science Education, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MS in Science Education, offered by the Science Education Program , is a flexible program designed for prospective and practicing K-12 science teachers, educators and specialists working in informal or outdoor education, community college science educators, and prospective science education PhD students. The curriculum is designed to augment and broaden the candidate’s knowledge of current advances in science education research, and connect these findings to best classroom practices.</br>
For more information, please visit the Science Education Programs website.</br>
Qualified students who have earned a multiple or single-subject credential at San José State University may apply up to 9 units of approved credential coursework from the College of Education and 3 units of approved credential coursework from the College of Science to the MS Science Education degree. Students who earned their credential elsewhere may transfer up to 9 units of completed post-graduate coursework to the MS Science Education program at the discretion of the Science Education Graduate Coordinator.</br>

## Admissions Requirements
Minimum admission requirements  to the Graduate Division  are outlined in this catalog. In addition, classified standing requires an undergraduate major with a grade point average of 2.75.</br>

- Demonstrated subject-matter competency in science, either through a baccalaureate degree in science or by passing the California Subject Examinations for Teachers (CSET) in General Science (215) and one Specialized Science CSET in either Life Science (217), Chemistry (218), Earth and Space Science (219) or Physics (220).</br>

- Evidence of appropriate goal(s) and commitment to graduate-level study as demonstrated by a personal statement written by the applicant and letters of recommendation from two or more persons qualified to judge the applicant’s potential as a graduate student.</br>

- A minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage, if the applicant is from a country in which the native language is not English.</br>

- Approval of the graduate advisor and/or graduate committee.</br>


## Requirements for Advancement to Graduate Candidacy
The student must satisfy general university requirements for advancement to candidacy  as outlined in detail in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. SCED 220  meets the GWAR requirement and is also a required course in this program, so no additional classes beyond the core courses for the MS Science Education are needed to meet this requirement.</br>

## Requirements for Graduation
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing SCED 220 .</br>

### Culminating Experience
Plan A (with Thesis)</br>
This option requires a thesis in science education approved by a master’s committee of no fewer than three members. The thesis is credited under SCI 299  units. At the end of the program, the candidate must successfully deliver an oral seminar and defense of the thesis, cumulatively known as a culminating experience. The written thesis must be submitted to the master’s advisor and master’s committee for approval before being submitted to the Office of Graduate Studies for university approval. Note: this is an uncommon choice for our graduate students.</br>
Plan B (with Project)</br>
This option requires a project related to science education approved by a master’s committee of no fewer than three members. The project is credited under SCED 298  units. At the end of the program, the candidate must successfully deliver an oral seminar and defense of the project, cumulatively known as a culminating experience. The written report of the project must be submitted to the master’s advisor and master’s committee. Note: the majority of our graduate students choose this path to graduation.</br>

## Master’s Requirements (30 units)

### Core Courses (9 units)

- SCED 273 - Secondary School Science 3 unit(s)</br>

- SCED 205 - Methods of Research 3 unit(s)</br>

- SCED 220 - Theories and Practices in Science Education 3 unit(s) (GWAR)</br>


### Electives (15 units)

- SCED 230 - Science Education Data Analysis 3 unit(s)</br>

- SCED 255 - Advanced Natural Science 1-3 unit(s)</br>

- SCED 285 - Seminar 3 unit(s)</br>

- Other 100- or 200-level courses related to the student’s MS project selected with advisor approval.</br>


#### Approved 200-level Courses Include:
A maximum of 9 units taken through the College of Education may be transferred from the credential program. Additional College of Education units may be selected with advisor approval.</br>

- EDTE 208 - Educational Sociology 3 unit(s)</br>

- EDTE 224 - Seminar in Educational Psychology 3 unit(s)</br>

- EDTE 260 - Critical Perspectives on Schooling for a Pluralist Democracy 3 unit(s)</br>

- EDTE 262 - Classroom Issues in the Language/Literacy Development of L2 Learners 3 unit(s)</br>

- EDTE 282 - Assessment and Evaluation 3 unit(s)</br>

- EDTE 294 - Research/Practices in Health and Special Education 3 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (Thesis)

- SCED 297 - Science Education Research 1-3 unit(s)</br>

- SCI 299 - Master’s Thesis 1-6 unit(s)</br>

- Oral Defense</br>


#### Plan B (Project)

- SCED 297 - Science Education Research 1-3 unit(s)</br>

- SCED 298 - Research 1-6 unit(s)</br>

- Oral Defense</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Coordinator and Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>