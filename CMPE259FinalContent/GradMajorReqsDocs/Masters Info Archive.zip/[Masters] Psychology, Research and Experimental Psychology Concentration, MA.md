
# Psychology, Research and Experimental Psychology Concentration, MA
 </br>

- Admission Requirements</br>

- Degree Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Arts Program in Psychology, offered by the Department of Psychology , affords its candidates an opportunity for advanced study of psychological theory and research techniques with the following objectives in mind:</br>

- To ultimately earn a doctorate in psychology - the course work and experience obtained in the Psychology Program is designed to enhance students’ credentials when applying to highly competitive doctoral programs.</br>

- To succeed in business, industry or a research setting - our program’s emphasis on the mastery of statistical and methodological procedures, research experience, and critical thinking produces graduates that are well suited for many careers in business, government, and/or an array of research settings.</br>


## Admission Requirements
To be eligible for admission into our program, you must:</br>
Meet all of the University’s graduate admission requirements :</br>

- Have the equivalent of a U.S. baccalaureate degree</br>

- Have completed a minimum of 30 semester units in undergraduate psychology</br>

- Have a minimum GPA of 3.0 in the last 60 semester units (90 quarter units) of all college and/or university course work</br>

- Have a minimum GPA of 3.0 in all college and/or university psychology courses taken</br>


## Degree Requirements
General university requirements and procedures for completing the Master of Arts degree are described in the Academic Regulations section of this catalog . In addition to these, the following departmental requirements must be fulfilled.</br>

### General Program Requirements

- The student’s combined total of approved undergraduate and graduate work in psychology must be at least 60 semester units, including 30 units for the MA Degree Program.</br>

- The student must complete at least 30 approved graduate units. At least 27 of these 30 units must be psychology or statistics units; of the 27, at least 24 must be 200-level courses, i.e., up to six units may be from 100-level courses with the program coordinator’s approval.</br>

- The candidate must complete an acceptable thesis. This thesis will be a quantitative investigation of some degree of originality and of publication caliber.</br>

- Satisfactory performance on a final examination is required. This examination may be written, oral or both, as determined by the student’s thesis advisory committee. This is typically satisfied through the oral defense of the student’s thesis research.</br>

- The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . Courses that satisfy the GWAR are listed in the course requirements for the program.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Thesis Requirement
The thesis serves as the culmination of a student’s course work, research experience, and growth as a scholar and scientist. This process is guided closely by a thesis advisor; a tenured or tenure-track faculty member of the Department of Psychology. As the student’s ideas develop into a full thesis proposal, a thesis advisory committee is formed to provide further guidance and expertise. Collection of the thesis data begins once the proposal has been approved by the committee and the proper human subjects approval has been obtained. The introduction, analysis, and interpretations of these data will form the core of the student’s written master’s thesis. These efforts all culminate in an oral presentation and defense before the thesis committee. A detailed statement of thesis policies is available in the Psychology Department Office and on the departmental website.</br>

## Master’s Requirements (30 units)

### Core (12 units)

- PSYC 280 - General Seminar 3 unit(s) (GWAR)</br>

- PSYC 220 - Seminar in Experimental Psychology 3 unit(s)</br>

- STAT 235 - Multivariate Analysis 3 unit(s)</br>

- STAT 245 - Advanced Statistics 3 unit(s)</br>


### Breadth (12 units)
Complete any four courses from:</br>

- PSYC 200 - Seminar in Personality Theory 3 unit(s)</br>

- PSYC 204 - Seminar in Developmental Psychology 3 unit(s)</br>

- PSYC 230 - Seminar in Physiological Psychology 3 unit(s)</br>

- PSYC 235 - Seminar in Cognitive Psychology 3 unit(s)</br>

- PSYC 237 - Psychology of Language 3 unit(s)</br>

- PSYC 254 - Social Psychology Seminar 3 unit(s)</br>

- PSYC 255 - Seminar in Learning 3 unit(s)</br>

- PSYC 256 - Seminar in Perception 3 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- PSYC 299 - Master’s Thesis 1-6 unit(s)</br>

- Elective 3 unit(s)</br>


## Total Units Required (30 units)
 </br>