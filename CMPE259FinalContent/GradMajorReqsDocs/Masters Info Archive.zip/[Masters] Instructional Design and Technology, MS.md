
# Instructional Design and Technology, MS
 </br>

- Requirements for Graduation</br>

- Master’s Requirements (34 units)</br>

- Program Learning Outcomes  </br>

The online Master of Science in Instruction Design and Technology program, offered by the School of Information , will prepare students to work in teaching, training, organizational management, and human performance improvement environments. Students will utilize a wide array of instructional/organizational/data strategies and technologies for training, teaching and learning, assessment and evaluation, and the design and development of informatics/data analytic systems to improve student/individual/organizational performance. Students will also learn how to assess and evaluate the quality of the entire systematic process using advanced analytics as part of a continuously improving performance loop using both formative and summative evaluation.</br>

For more information visit the MS Instructional Design and Technology website.</br>

### Requirements for Admission to Classified Standing
Candidates must meet all university admissions requirements . Applicants who meet the following requirements beyond university requirements will be considered for admission into the School of Information:</br>

- A bachelor’s degree from any regionally accredited institution in any discipline with a GPA of at least 3.0 at the bachelor’s degree institution or in the last 60 semester or 90 quarter units.</br>

- The School requires that all students have computer access from home. See Home Computing Requirements.</br>

- Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>


### Requirements for Admission to Conditional Classified Standing
The School of Information does not admit students on a conditional basis.</br>

### Requirements for Advancement to Graduate Candidacy
In order to achieve candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy for the instructional design and technology degree are detailed in the Graduate Policies and Procedures section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR).</br>
Students must complete and submit the Petition for Advancement to Graduate Candidacy after completion of nine units and by the posted deadlines for the semester in which they plan to graduate.</br>

### Special Session Program Information
Academic Programs offered through Special Session are operated by Professional and Continuing Education. Registration and enrollment in a Special Session course or program are subject to special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements.</br>
Requirements for Graduation</br>

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements section of the Graduate Policies & Procedures. </br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR)  .</br>

### Culminating Experience
Plan B (Project)</br>
For this plan, the student is required to complete 3 units of  IDT 298 - Capstone Applied Project and e-Portfolio .</br>

## Master’s Requirements (34 units)

### Core Courses (13 units)

- IDT 200 - Online Learning: Tools and Strategies for Success  1 unit(s)</br>

- IDT 201 - Introduction: Instructional Systems & Learning Technologies  3 unit(s)</br>

- IDT 202 - Systematic Design: Instruction & Human Performance  3 unit(s)</br>

- IDT 203 - Trends and Issues in Instructional Design and Human Performa  3 unit(s) (GWAR)</br>

- IDT 204 - Theories of Teaching, Learning, and Human Cognition  3 unit(s)</br>


### Electives (18 units)

- IDT 205 - Learning Design and Technologies  3 unit(s)</br>

- IDT 206 - Advanced Instructional Design and Development  3 unit(s)</br>

- IDT 207 - Learning Analytics and Data-Driven Evaluation and Assessment  3 unit(s)</br>

- IDT 208 - Digital Teaching and Learning Environments  3 unit(s)</br>

- IDT 209 - Emerging Technologies  3 unit(s)</br>

- IDT 210 - Multimedia Design and Immersive Extended Realities (XR)  3 unit(s)</br>


## Culminating Experience (3 units)

- IDT 298 - Capstone Applied Project and e-Portfolio  3 unit(s)</br>


## Total Units Required (34 units)
 </br>