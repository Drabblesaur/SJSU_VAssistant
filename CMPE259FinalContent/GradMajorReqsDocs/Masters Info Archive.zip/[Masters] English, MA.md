
# English, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The written word grounds the Master of Arts in English. Its students learn to analyze literature and to write on literary topics at an advanced level. Students complete a rigorous program of courses that introduce them to cutting-edge research while training them to understand a range of theoretical and literary-historical frameworks for understanding literature. Before students earn a Master of Arts in English, they pass a two-part comprehensive exam. They also may choose to write a thesis. Students have the option to engage in graduate study in rhetoric and to train as college-level writing teachers. The program also offers students pathways to prepare for doctoral work.</br>
Additional information is available in the Department of English and Comparative Literature  Office and on the MA program website.</br>

## Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the Master of Arts in English. See the Graduate Admissions website and this Catalog  for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Admission to Classified Standing
In addition to meeting the minimum university admission requirements  for the Graduate Division as outlined in this catalog, applicants must have:</br>

- 3.0 grade point average in English or literature courses.</br>

- a minimum of 24 semester hours of acceptable undergraduate upper-division course work in English or other literary studies.</br>

- Earned 2 semesters (3 quarters) credit in a foreign language course or have the equivalent fluency as attested to by a credible academic source.</br>

- Approval by the department graduate committee.</br>

In addition to the university application requirements, applicants to the English MA must submit a writing sample directly to the MA advisor.</br>

### Admission to Conditionally Classified Standing
Applicants who do not qualify for classified standing but who do meet university requirements for graduate admission and whose past performance gives promise of satisfactory completion of requirements for graduate admission to classified standing may, with approval of the department graduate committee, be admitted as conditionally classified in the English MA program. Generally, this category is used if the applicant has not yet earned the equivalent fluency of 2 semesters/3 quarters of credit in a foreign language course OR an applicant has not yet completed 24 units of upper-division coursework in literature but otherwise shows promise as a graduate student.</br>

## Requirements for Advancement to Graduate Candidacy
Candidacy denotes that the student is fully qualified to complete the final stages of the MA, English. In order to achieve candidacy, students must meet the university requirements. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) . MA, English students must complete ENGL 201 , the program GWAR course, before they can apply for candidacy. Application for advancement to candidacy should be done by the middle of the semester before students intend to graduate.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MA - English Graduation Requirements
Students must complete an approved 30-unit program with a grade point average of 3.0 or better. At least 21 of these units must be graduate-level (i.e., 200-numbered) courses. Any undergraduate coursework to be applied to the MA program must be approved in advance by the graduate advisor.</br>
Included in these 30 units, are the ENGL 201  and ENGL 297 . The ENGL 297  requirement will be waived if a student completes a thesis (which requires 6 units of ENGL 299  in lieu of ENGL 297  and one 4-unit graduate-level course).</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students choose Plan A (Thesis) or Plan B (Comprehensive Examinations) as their program culminating experience.</br>
Plan A (Thesis)</br>
To receive credit for ENGL 299  units, students must submit a thesis proposal to the department graduate committee by the deadline in the semester prior to the one in which the student plans to take the 299 units and complete the thesis.</br>
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee (made up of three readers arranged by the student and approved by the department graduate committee).</br>
Students choosing the Plan A (Thesis) option must also pass the two-part MA, English comprehensive examinations but are not required to enroll in ENGL 297 .</br>
Plan B (Comprehensive Examinations)</br>
Students choosing this option must enroll in ENGL 297  and pass the two-part MA comprehensive examinations. They are also required to take an additional 4-unit elective.</br>

## Master’s Requirements (30 units)

### Core Courses (4 units)

- ENGL 201 - Materials and Methods of Literary Research 4 unit(s) (GWAR)</br>


### Electives (20 units)
Five additional graduate-level courses chosen with MA advisor’s approval</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A Thesis Plus Comp Exam or Plan B Comp Exam Only):</br>

#### Plan A (Thesis, plus Comprehensive Exam)

- ENGL 299 - University Thesis 1-6 unit(s) (6 units required)</br>

- Comprehensive Exam</br>


#### Plan B (Comprehensive Exam)

- ENGL 297 - MA Comprehensive Exam Preparation 2 unit(s)</br>

- Comprehensive Exam</br>

- One additional graduate-level course chosen with MA advisor’s approval</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the English MA Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 6.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>