
# Biotechnology, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (36 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Biotechnology program, offered by the Department of Biological Sciences , integrates advanced, hands-on training in biotechnology and medical product development courses with MBA-level business courses from the College of Business. The core courses introduce aspects of the biotechnology and medical product industry including drug and medical device development, marketing, finance, and intellectual property. The required internship experience allows the students to apply what they have learned in real-world settings.</br>
Through elective choices, students supplement the core program with additional hands-on science or MBA courses in support of their career goals. MS in Biotechnology program graduates are highly trained individuals who have had direct exposure to the biotechnology and medical device real world and are ready to make immediate contributions to the biotechnology/ medical device, nonprofit, or government organizations. Graduates work in a variety of positions in research, product development, marketing, regulatory affairs, clinical affairs, project management, quality, and others.</br>
For more information visit the SJSU Master of Science Biotechnology website​.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system at calstate.edu/apply and meet all the university admission requirements. Applicants must submit additional supporting documents including a resume separately to the department to obtain admission into the MS in Biotechnology degree program. See the graduate admissions requirements website and this Catalog for general information about graduate admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Admission to the Program
Applicants must submit an official transcript (for international WES evaluated transcript), English-language proficiency test (if applicable), statement of purpose, resume, GRE or waiver, and 2 letters of recommendation to the university. Potential candidates will be interviewed during the spring semester. Admission is based on the acceptance to the university and the outcome of the interview.</br>

## Requirements for Advancement to Candidacy
All students will submit their Advancement to Candidacy petitions during the fall of their second year, after having fulfilled all University requirements for advancement to candidacy , as detailed in the Graduate Policies and Procedures  section. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which is satisfied in this degree by the completion of BIOL 202TA  or BIOL 202TB , and  SMPD 281A  for MPDM Concentration with grades of “B” or higher.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Requirements
The Master of Science in Biotechnology program consists of 36 semester units of approved work. It includes a 2-unit internship in the biotechnology or medical product  industry.</br>
Special Session Program Information</br>
Academic Programs offered through Special Session  are operated by Professional and Continuing Education (PaCE). Registration and enrollment in a Special Session course or program must use the special session application form and will follow the special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Biotechnology website for more information.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing BIOL 202TA  and BIOL 202TB . It is satisfied by passing SMPD 281A  for MPDM Concentration. </br>

### Culminating Experience
Plan B (Project)</br>
The culminating experience is the Biotechnology Colloquium (BIOL 285T ). </br>

## Master’s Requirements (36 units)

### Core Courses (29 units)

- BIOL 202TA - Biotech Seminar: Biotech Products 3 unit(s) (GWAR)</br>

- BIOL 202TB - Biotech Seminar: Drug Development Process 3 unit(s) (GWAR)</br>

- BIOL 202TC - Biotech Seminar: Biotech Business I 2 unit(s)</br>

- BIOL 202TD - Biotech Seminar: Biotech Business II 2 unit(s)</br>

- BIOL 205T - Advanced Molecular Techniques for Biotechnology 4 unit(s)</br>

- BIOL 280T - Internship in the Biotechnology and Medical Product Industry 2 unit(s)</br>

- BIOL 282C - Biotechnology and Medical Product Company Management 3 unit(s)</br>

- BUS 282A - Essentials of Management and Organizational Behavior 3 unit(s)</br>

- BUS 282B - Essentials of Operations Management 3 unit(s)</br>


#### Complete One Course From:

- BIOL 221T - Advanced Bioinformatics 4 unit(s)</br>

- BIOL 255T - Introduction to Stem Cell Techniques 4 unit(s)</br>


### Electives (6 units)
Students must take any two of the following 200-level science and/or business courses:</br>

#### Science Electives

- BIOL 233T - Immunological Techniques for Biotechnology 3 unit(s)</br>

- BIOL 281T - Individual Studies in Biotechnology/ Medical Product Development 1-4 unit(s)</br>

- SMPD 283A - Regulatory Affairs I for Pharmaceuticals and Biologics 3 unit(s)</br>


#### Business Electives

- 200-level MBA for Professional course chosen in consultation with the Program Director</br>


### Culminating Experience (Plan B) (1 unit)

- BIOL 285T - Colloquium in Biotechnology/ Medical Product Development 1 unit(s)</br>


## Total Units Required (36 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>