
# Linguistics, MA (Not Accepting Students)
 </br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Admission to Classified Standing</br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

Linguistics, the scientific study of human language, explores what language is, how it works, and which properties human languages have in common. Our curriculum focuses on understanding how different aspects of language work and on how the languages of the world work and on how this understanding can be applied to support our culturally diverse society. Students in the Department of Linguistics and Language Development  (LLD) are part of an ethnically and linguistically diverse student body, taught by nationally and internationally recognized faculty. Our research infrastructure includes a state-of-the-art computer lab, a phonology lab, and access to computerized language data. Approximately 25% of our students come from other countries and contribute greatly to our programs.</br>
The MA Linguistics program provides students with an interdisciplinary education in the scientific study of language. Courses in general linguistics develop the ability to analyze data, to propose and refine theories about how language works. Elective courses in computational linguistics serve students interested in speech technology and natural language processing. Other electives in sociolinguistics, multilingualism, and applied linguistics emphasize the role of language in society, including in education, and language variation and change. Graduates in linguistics offer a set of highly specialized skills to IT companies and to organizations whose work places a premium on communication with linguistically diverse audiences. Many graduates pursue careers with companies specializing in these areas. Other graduates pursue teaching careers in language and linguistics in domestic and overseas institutions. A smaller but significant number of linguistics graduates enter PhD programs for more advanced study.</br>
Requirements for the MA Linguistics include those established by the department. For information concerning university requirements, see the  Academic Requirements  section. </br>

## Requirements for Admission to Conditionally Classified Standing
Students holding an accredited baccalaureate degree and who otherwise satisfy the graduate level admissions requirements of San José State University (in the case of students with baccalaureate degrees from a university where English is not the principal language of instruction the minimum score of 577, computer score of 233, or Internet-based score of 90 on the TOEFL or 7.0 on IELTS) are eligible for admission as conditionally classified students. Students must have a grade point average of at least 3.0 in the last 60 semester (90 quarter) units.</br>

## Requirements for Admission to Classified Standing
In addition to the above requirements for conditionally classified standing, students in the MA Linguistics program are eligible for admission as classified graduate students if they have completed at least twelve-semester units of linguistics courses equivalent to San José State University’s LING 101 , LING 111 , LING 112 , and LING 114  with a grade of “B” or better in each of these classes. </br>
Students admitted as conditionally classified may complete the requirements for classified standing after admission to the program; however, a “B” grade must be achieved in all prerequisite courses. Additionally, the granting of classified standing is subject to the coordinator’s review of the conditionally classified student’s work.</br>

## Advancement to Candidacy
The requirements for advancement to candidacy  for the MA Linguistics are those established by the university and the department. For information see the Graduate Policies and Procedures  section of this catalog.</br>

## Graduation Requirements

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR). In the MA Linguistics, this is satisfied with the core course LLD 250W . For more information on the GWAR, please see Graduation Writing Assessment Requirement (GWAR)  section.</br>

### Culminating Experience
Students have the option of completing the MA - Linguistics under one of two plans:</br>
Plan A (Thesis)</br>
Completion of 30 units; approved thesis proposal and thesis. The thesis option allows a student to pursue research in an area of common interest to the student and a faculty member. A thesis proposal may grow out of a course or be developed in LING 298 , and must be approved by the student’s advisor and thesis committee members. For more information, visit the Thesis and Dissertation Information website.</br>
Plan B (Comprehensive Exam)</br>
Completion of 30 units; passing of a comprehensive examination.</br>

## Master’s Requirements (30 units)

### Core Courses (18 units)

- LING 113 - Introduction to Phonology 3 unit(s)</br>

- LING 201 - Phonology: Theory and Applications 3 unit(s)</br>

- LING 202A - Syntactic Theory 3 unit(s)</br>

- LING 203 - Semantic Structures 3 unit(s)</br>

- LING 213 - Linguistic Field Methods 3 unit(s)</br>

- LLD 250W - Becoming a Professional in Linguistics/TESOL 3 unit(s) (GWAR)</br>


### Culminating Experience (12 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B)</br>

#### Plan A (Thesis) (12 units)

- LING 299 - Master’s Thesis 1-6 unit(s) (1-3 units required)</br>

- Two Electives 6 unit(s)</br>


#### Plan B (Comprehensive Exam) (12 units)

- Four electives 12 unit(s)</br>

- Comprehensive Exam 0 unit(s)</br>


### Elective Courses (6-12 units)
Elective courses must be planned in consultation with the Graduate Advisor. At least 3 elective units must be at the 200-level.</br>
Complete two electives (6 units) if completing Culminating Experience Plan A and four electives (12 units) if completing Culminating Experience Plan B:</br>

- LING 115 - Corpus Linguistics 3 unit(s)</br>

- LING 124 - Introduction to Speech Technology 3 unit(s)</br>

- LING 125 - Introduction to Historical and Comparative Linguistics 3 unit(s)</br>

- LING 161 - Psycholinguistics 3 unit(s)</br>

- LING 162 - Introduction to Morphology 3 unit(s)</br>

- LING 165 - Introduction to Natural Language Processing 3 unit(s)</br>

- LING 166 - Sociolinguistics 3 unit(s)</br>

- LING 167 - Multilingualism and Language Contact 3 unit(s)</br>

- LING 298 - Individual Study 1-4 unit(s)</br>

- LING 299 - Master’s Thesis 1-6 unit(s)</br>

- LLD 270 - Second Language Acquisition 3 unit(s)</br>

- LLD 271 - Intercultural Communication and Second Language Acquisition 3 unit(s)</br>


## Total Units Required (30 units)
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>