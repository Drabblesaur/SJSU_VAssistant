
# Financial Analytics, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Financial Analytics (MSFA) program, offered by the Lucas College and Graduate School of Business , is STEM-designated and fully accredited by the Association to Advance Collegiate Schools of Business (AACSB). The program emphasizes the knowledge necessary to succeed in corporate finance roles. The course work is structured to combine accounting and finance knowledge, as well as provide experience with the relevant technology and prepare well rounded professionals for careers in corporate finance roles. In addition to technical and analytical skills, the program emphasizes the development of communication skills, professional development, and career readiness.</br>
The MSFA program is open to candidates who graduated with business or nonbusiness majors. The program accommodates professionals with demanding life and work schedules. Classes are taught using a hybrid delivery format combining online and in-person sessions. Classes meet evenings and Saturdays in eight-week sessions year-round. In-person class sessions are held on the SJSU campus. The 33-unit program can be completed within 12 months on a full-time basis or within 21 months on a part-time basis.</br>

## Admissions Requirements
MSFA candidates must meet all of the university admission requirements.</br>
To be fully accepted into classified standing, the following conditions must be met:</br>

- A bachelor’s degree from an accredited university in the U.S. or the equivalent of a U.S. bachelor’s degree earned from a recognized institution if the degree was earned outside of the U.S.</br>

- A preferred GPA of 3.2 on a 4.0 scale.</br>

- An English language proficiency examination if the previously earned degree was from an institution in which the principal language of instruction was not English. The university’s minimum entrance score for the TOEFL is 213 (computer-based) or 80 (internet-based). The minimum score required on the IELTS is 6.5, and the minimum PTE score is 53.</br>

- A personal statement of one to two pages explaining how an MSF would help to achieve the applicant’s career objectives.</br>

- A resume detailing the candidate’s professional and academic experiences.</br>

- (Optional) Two letters of recommendation.</br>

- The GMAT or GRE are not required but strongly recommended for applicants with GPAs less than 3.2 on a 4.0 scale. Scores at the 50th percentile in both the quantitative and verbal sections of either exam are considered competitive.</br>


### Prerequisites for Clear Admission
Students must complete the following SJSU courses or their equivalents:</br>

- BUS1 170 - Fundamentals of Finance  </br>

- BUS2 90 - Business Statistics  </br>


## Requirements for Advancement to Candidacy
A student must maintain an overall grade point average (GPA) of 3.0 at all times, otherwise she or he will be placed on academic probation and required to raise the overall GPA above the 3.0 minimum during the subsequent semester (failing to do so will result in disqualification from the program).</br>
The student must complete with a grade of C or better at least 9 units towards the degree, and meet all other university requirements, including GWAR, before being advanced to candidacy.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement . This requirement is satisfied by taking BUS 270D  . </br>

### Culminating Experience
The culminating experience will take place in the capstone course BUS 270D - Case Studies in Corporate Finance . The course focuses on the study of corporate finance problems integrating finance theory and business practice. Topics include assessing financial condition; valuation, cash flow and capital budgeting analysis; and decision-making pertaining to working capital, capital expenditures, capital allocation, capital structure, payout policy, IPOs, mergers, acquisitions, divestitures and corporate governance. The students are assigned a complex case study based on publicly available data which integrate accounting & financial knowledge, technology, and corporate strategical considerations. Students may propose themselves a case study based on actual private or publicly available data, conditional on the approval of the course instructor and program director. Students work on the case study and write a report in a professional format summarizing their analysis and findings. An oral presentation is also required.</br>

## Master’s Requirements (30 units)

### Core Courses (21 units)

- BUS 200F - Leadership Communication for Finance Professionals 2 unit(s)</br>

- BUS 220 - Financial Accounting 3 unit(s)</br>

- BUS 220A - Financial Statement Analysis 3 unit(s)</br>

- BUS 265F - Silicon Valley Experience for Finance Professionals 1 unit(s)</br>

- BUS 270 - Financial Management 3 unit(s)</br>

- BUS 270A - Financial Planning and Analysis 3 unit(s)</br>

- BUS 270C - Financial Modeling and Data Visualization 3 unit(s)</br>

- BUS 270E - Advanced Corporate Finance 3 unit(s)</br>


### Elective Courses (6 units)
Complete 2 courses. Students may include up to two BUS elective courses in the MBA or MSAA programs subject to approval by program directors.</br>

- BUS 270F - Corporate Finance Analytics 3 unit(s)</br>

- BUS 222 - Profit Planning and Control 3 unit(s)</br>

- BUS 270B - Financial Derivatives for Corporate Finance 3 unit(s)</br>

- BUS 273 - Business Valuation 3 unit(s)</br>


### Culminating Experience (3 units)

- BUS 270D - Case Studies in Corporate Finance 3 unit(s) (GWAR)</br>


## Total Units Required (30 units)
 </br>