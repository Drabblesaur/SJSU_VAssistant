
# Geographic Information Science (GISc), MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Program Learning Outcomes   </br>

The Master of Science in Geographic Information Science (MS GISc) is a one-year graduate degree offered by the School of Planning, Policy and Environmental Studies . With a streamlined program of study, students will learn theory and applications of spatial thinking/reasoning and use of GIS to support problem solving and decision making. The program will harness a wide array of courses in GISci, statistics, computer science, geography, urban and regional planning and their intersection through 8 upper division courses. With these courses, students will use the geospatial competency model to be increasingly challenged in face to face, project-based courses to prepare them for a rapidly expanding 21st Century technology intensive profession. Key outcomes of the program of study include understanding of theory and scholarship, ability to perform spatial data collection and analysis, accurate and ethical use of geospatial tools and techniques, and the ability to communicate technical information visually, orally, and in written forms.</br>
MS GISc graduates are eligible for the Optional Practical Training (OPT) 24-month extension for STEM students.</br>
Geography/GIS graduate advisor: Dr. Ahoura Zandiatashbar</br>

## Admission Requirements
Candidates must meet all of the university admission requirements. The MS GISC application materials include:</br>

- Letters of Recommendation: Applicants are required to submit 2 letters of recommendation commenting on their ability for potential graduate studies and research in MS GISC graduate program.</br>

- Transcripts: Official transcripts from all higher educational institutions attended (even those where you did not get a degree) to be submitted to the Graduate Admissions Office.</br>

- Resume (CV): Current Resume or CV</br>

- Essay: A short essay (maximum 2 pages) that briefly describes applicant’s education and career background, past research experience, anticipated master project and topic, and reasoning for pursuing a Master’s in Geographic Information Systems. It is important to note that the anticipated master’s project or topic will not influence the admission decision.</br>

- Bachelor’s Degree: Applicants must have completed a Bachelor’s Degree with some focus on geography or spatial analysis from an accredited institution. If there is no geography or spatial analysis, applicants may be asked to enroll in related undergraduate courses</br>

Basic requirements for admission to the Graduate Division are outlined in the Admissions  section. In addition, the department requires the following for admission to classified standing:</br>

- Undergraduate GPA Requirement: Applicants must have completed a Bachelor’s Degree program with a minimum cumulative GPA of 3.0 (4.0 scale).</br>

- Writing Sample: Academic/professional writing samples</br>

- GRE (OPTIONAL): The GRE General Test score can be optionally submitted along with the packet to compare and rank applicants or for potential financial aid or funded positions. There is no minimum requirement, but the GRE score could be used to compare and rank applicants or to be considered for potential financial aid or funded positions.</br>

- TOEFL: Applicants from countries in which the native language is not English must have:

	
TOEFL iBT (Internet-based) 80
TOEFL paper-based 550
Academic International English Language Testing System (IELTS) 6.5
Academic Pearson Test of English (PTE) 53

</br>

- TOEFL iBT (Internet-based) 80</br>

- TOEFL paper-based 550</br>

- Academic International English Language Testing System (IELTS) 6.5</br>

- Academic Pearson Test of English (PTE) 53</br>

- International Students: International students are advised to closely follow guidelines for submitting transcripts and any other supporting documents, including demonstrating competence in English, available on the Graduate Admissions & Program Evaluation website.</br>

- Prerequisites for non-GIS applicants:

	
GISC171 - Vector GIS analysis/modeling refresher (1 unit)
GISC182 - Raster GIS analysis/modeling refresher (1 unit)

</br>

- GISC171 - Vector GIS analysis/modeling refresher (1 unit)</br>

- GISC182 - Raster GIS analysis/modeling refresher (1 unit)</br>


## ​Requirements for Advancement to Candidacy
The student may be advanced to candidacy  by complying with requirements of the university as outlined in the Master’s Requirements  section of this catalog. The University requires that all graduate students complete the   Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

## ​Requirements for Graduation
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Culminating Experience
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
GISC 298A and GISC 298B represent the culmination of the MS in Geographic Information Science program. Through these courses, under faculty guidance students undertake a comprehensive project focusing on real-world geospatial challenges, integrating advanced GIS techniques and emerging technologies.</br>
GISC 298A - Master Report 1: Final Project Research Design  (3 units): Students initiate their projects by identifying a relevant geospatial issue and developing a project proposal under faculty guidance. They leverage GIS tools to analyze data and formulate insights, laying the foundation for innovative solutions.</br>
GISC 298B Master Report 2 - Final Project Development   (3 units): In the final phase, students refine their projects, creating user-friendly interfaces and communicating findings effectively. Through presentations and deliverables, they showcase the practical application and impact of their GISc solutions. </br>
Innovative Outcomes: The MS GISc Culminating Experience encourages diverse outputs, including comprehensive reports, web-tools, mobile applications, and GeoAI-based products. Students are encouraged to explore innovative solutions tailored to real-world needs, with opportunities for external applications in collaboration with potential user companies.</br>
Upon completion, students emerge as adept geospatial professionals, equipped to address complex spatial challenges in diverse fields. Their projects serve as tangible contributions to the field of GISc, demonstrating their ability to innovate and lead in a rapidly evolving landscape. The Culminating Experience in MS GISc through GISC 298A and GISC 298B exemplifies the program’s commitment to hands-on learning and practical application. As students embark on their post-graduate endeavors, they carry with them the skills, knowledge, and passion to make meaningful contributions to the field of Geographic Information Science. </br>

## Master’s Requirements (30 units)

### Fall Semester (15 units)

- GISC 205 - Spatial Data Literacy and Ethics 4 unit(s) (GWAR)</br>

- GISC 210 - Spatial Data Science Through Open-Source GIS Technologies 4 unit(s)</br>

- GISC 220 - Spatial Statistics, Analysis, & Modeling 4 unit(s)</br>

- GISC 298A - Master Report 1: Final Project Research Design 3 unit(s)</br>


### Spring Semester (15 units)

- GISC 230 - Web GIS/Geo Visualization 4 unit(s)</br>

- GISC 279 - Python Programming for Advanced GIS 4 unit(s)</br>

- GISC 282 - Advanced Remote Sensing & Image Processing 4 unit(s)</br>

-  

Culminating Experience (3 units): 
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.
 </br>
 </br>
Culminating Experience (3 units): </br>
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
 </br>

- GISC 298B - Master Report 2 - Final Project Development 3 unit(s)</br>


## Total Units Required (30 units)
 </br>