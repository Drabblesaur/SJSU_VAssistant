
# Biological Sciences, Stem Cell Biology Concentration, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (32 units)</br>

- Program Learning Outcomes  </br>

The Master of Science program in Biological Sciences with a concentration in Stem Cell Biology, offered by the Department of Biological Sciences , offers students training in the pursuit of rigorous scientific investigation with an emphasis on discovering the molecular mechanisms critical for maintenance of stem cells, cellular differentiation, and clinical applications in regenerative medicine. Students complete a rigorous curriculum in stem cell biology including intensive laboratory coursework and completion of an original research project. In addition, students in our concentration will have gained experience in critical thinking, problem-solving, research methodology (e.g., experimental design, sampling techniques, and analysis), and both written and oral communication. Our alumni are successful applicants for doctoral degree programs and generally attain high level academic and non-academic positions in both the private and public sectors. </br>
For more information visit https://www.sjsu.edu/scill/index.php</br>

## Admissions Requirements
Candidates must meet all the university admission requirements. In addition, applicants must submit to the SCILL Program Director an explanation of why the student wants to enroll in the SCILL program, their long term goals and how the degree will help facilitate those goals, and two letters of recommendation. </br>
Students can be admitted in either classified or conditionally classified standing. Conditional acceptance  means that the candidate must fulfill specific requirements in order to be eligible to apply for advancement to candidacy. These conditions will be stipulated as part of the acceptance agreement between the faculty adviser and the applicant. Failure to fulfill these requirements will result in disqualification from the program. </br>
Applicants from countries in which the native language is not English must achieve a minimum English language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE.</br>

## Requirements for Advancement to Graduate Candidacy
Each semester, students should consult with the SCILL Program Director to develop a schedule of courses. Students admitted as conditionally classified must satisfy the requirements listed in their acceptance  agreement before advancing to candidacy. Students who have achieved classified standing in the master’s degree curriculum must next advance to candidacy for the degree. A student may advance to candidacy after completing a minimum of 9 units of letter-graded work as a graduate student in 100- or 200-level courses acceptable to the department as well as fulfilling the other university requirements for advancement to candidacy , as detailed in the Graduate Policies and Procedures section. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which is satisfied in this degree by the completion of BIOL 202  with a grade of “B” or better.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . </br>

### MS Biological Sciences, Stem Cell Biology Concentration, Graduation Requirements
As shown below, the program consists of 32 semester units of approved work. The student consults with his or her advisor to select a thesis or project topic. </br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
A grade of “B” or  better in  BIOL 202  will satisfy the graduate competency in writing requirement.</br>

### Culminating Experience Requirements
Plan B (Project) </br>
Written Project: The written project must be a manuscript describing the student’s research project, written following a professional journal’s format for submission. It will be written under the guidance of the candidate’s graduate committee chair with the assistance of their graduate committee. The manuscript must be approved by the student’s graduate committee. Typically, the committee will provide the candidate feedback during the Project Defense and may request changes to the manuscript before final approval. </br>
Oral Project Defense: All MS candidates are required to present a public seminar based on their research project. </br>

## Master’s Requirements (32 units)

### Core Courses (15 units)

- BIOL 201 - Graduate Seminar in Biological Sciences 1 unit(s)</br>

- BIOL 202 - Graduate Studies in Biology 3 unit(s)</br>

- BIOL 220 - Science Communication 3 unit(s)</br>

- BIOL 297 - Graduate Research 1-4 unit(s) (Students take a total of 8 core units of this class.)</br>


### Concentration Courses (14 units)

- BIOL 205 - Advanced Molecular Techniques 4 unit(s)</br>

- BIOL 235 - Bench to Bedside in Regenerative Medicine 1 unit(s)</br>

- BIOL 236 - Community Outreach 1 unit(s)</br>

- BIOL 237 - Patient Interactions 1 unit(s)</br>

- BIOL 238 - Stem Cell Biology and Regenerative Medicine 3 unit(s)</br>

- BIOL 239 - Stem Cell Biology Laboratory 4 unit(s)</br>


### Electives (2 units)

- BIOL 255MMP - Advanced Topics:Molecular, Microbial, and Physiological Biol 1-4 unit(s)</br>

- Other 100- or 200-level courses chosen with advisor consent</br>


### Culminating Experience (1 unit)

- BIOL 298 - MS Project Culminating Experience 1 unit(s)</br>


## Total Units Required (32 units)
Elective courses must be planned in consultation with the SCILL Porgram Director. </br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s  degree is 15. </br>
At least 60% of the units applying toward the degree must be letter-graded coursework. A public seminar on the thesis or project must be given. </br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and  SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>