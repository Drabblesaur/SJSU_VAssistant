
# Public Health, MPH
 </br>

- Graduate Admission</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (42 units)</br>

- Program Learning Outcomes  </br>

San José State University’s Department of Public Health  offers a Master of Public Health (MPH) degree with a specialization in Community Health Education in two formats; Campus (regular session) and Hybrid (through the College of Professional and Global Engagement). Both campus and Hybrid students engage in the same rigorous course of study. The MPH degree on campus offers students the flexibility to complete their degree in two years or more, depending on personal circumstances. The MPH Hybrid option is offered through special sessions and is a fast-paced, 24-month program of study. Courses in the Hybrid option are conducted synchronously on Tuesday nights (PST) in Zoom. Hybrid students are required to come to the SJSU campus for 3-4 days in August, depending on their year, for orientation and advising, tutorials, preparatory course sessions, and to take the comprehensive examination (also offered online in December). </br>
The MPH Program was founded in 1970 to prepare community health education practitioners and has been continuously accredited by the Council on Education for Public Health (CEPH) since 1974. CEPH is the independent agency officially recognized to accredit graduate programs in public health. As stated in its mission statement, CEPH assures quality in public health education and training to achieve excellence in practice, research, and service, through collaboration with organizational and community partners. The SJSU MPH Program is well-known for its practice-oriented, community-based training. The program’s essential mission is:</br>
To provide a professional education that prepares students to be innovative thinkers, critically engaged practitioners, and transformative leaders who can apply the conceptual frameworks, health education and public health competencies, in order to develop programs, build community capacity, advocate policy for health equity, and contribute to evidence-based public health practice.</br>
The MPH program’s mission is achieved through an integrated program of instruction, scholarship, and internships in partnership with a diverse network of community programs and practitioners. The ultimate goal is public health and social justice through planned, organized, and empowering community efforts.</br>
Additional information is available on the Master of Public Health website.</br>

## Graduate Admission

### University Admission
Candidates must complete two applications: the CSU admissions portal, Cal State Apply, and the MPH program application from the MPH website (sjsu.edu/mph). Applicants must meet all university graduate admission requirements .</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Program Admission
New students are admitted once a year, and begin course work during the fall semester in both online/hybrid and campus formats. A detailed Admissions Information Packet is available at www.sjsu.edu/hsr/academicprograms/mph.</br>
Applications for the Campus and Special Session Online/hybrid formats are accepted between October 1 and June 1 for fall admission. Applications after June 1 will be considered on a space-available basis. Applications received after July 1 will not be eligible for review and will require resubmission for consideration for the next application cycle. Applying to the MPH program, both campus and online/hybrid, requires two parallel, but separate, application processes. All MPH applicants must:</br>

- Submit a complete university application through Cal State Apply. Successful applicants must be admitted to the university by the SJSU Graduate Admissions and Program Evaluations.</br>

- Submit a complete application to the MPH program, which includes:

	
At least two letters of recommendation on official letterhead, signed, and include contact information for author
Resume/CV
Statement of Purpose (1-2 pages)

</br>

- At least two letters of recommendation on official letterhead, signed, and include contact information for author</br>

- Resume/CV</br>

- Statement of Purpose (1-2 pages)</br>

Additional information and the Application Packet are available on the MPH Admissions website.</br>

### Program Requirements for Admission to Classified Standing
Students can be admitted in either classified or conditionally classified standing. To be admitted to the Master of Public Health Program in Classified status, an applicant must possess a baccalaureate degree with an overall minimum GPA of 3.0 in the last 60 semester or quarter units, demonstrated multicultural experience, and a clear commitment to public health as evidenced through ongoing work or volunteer experiences.</br>

### Program Requirements for Admission to Conditionally Classified Standing
Admission with Conditionally Classified standing is available to Campus format applicants only. If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the applicant may be admitted with conditions that will include taking longer than two years to complete the program and taking writing and/or computation preparation courses. The program admissions letter will explain terms and requirements.</br>

## Requirements for Advancement to Candidacy
Matriculated graduate students must submit a Petition for Advancement to Graduate Candidacy a minimum of one semester prior to graduating. General university requirements for advancement to candidacy  for the MPH degree are detailed in the Graduate Policies and Procedures  section.</br>
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Course Requirements
To meet the requirements for the MPH, a student must complete 42 units (and satisfy the program GWAR requirement) with a cumulative GPA of 3.0 or better.  Campus-format students opting to complete an independent project (Plan B - Project) as their culminating experience must take an additional 3-6 units above the 42 unit requirement.</br>
In consultation with the department graduate coordinator, the candidate will develop and pursue a plan of study. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approval Program. The MPH program requires grades of B- or better to pass courses.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
The student must complete one of two culminating experience options:  Plan B (Project) or the courses-only Plan B (Comprehensive Examination). Master’s graduate projects may only be undertaken by regular session MPH Campus students upon departmental approval and will require additional units.  The Plan B (Project) option requires a minimum of 3 additional units of coursework.</br>
Plan B (Project)</br>
Campus students opting to complete a master’s project will take the PH 298 - Graduate Project  for an additional 3-6 units over program requirements.</br>
Plan B (Comprehensive Exam)</br>
All Online/hybrid students and Campus students opting for the courses-only option must pass the Comprehensive Exam (given once a semester) to earn the MPH degree. The Comprehensive Exam is the student’s opportunity to demonstrate mastery and integration of the knowledge and skills of the MPH curriculum. The comprehensive exam is a written exam that is administered on campus in May and August, and online in December.</br>
Special Session Program Information</br>
Academic Programs offered through Special Session are operated by the Professional and Global Engagement. Registration and enrollment in a Special Session course or program must use the special session application form and will follow special session fee and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Professional and Global Engagement website for more information.</br>

## Master’s Requirements (42-48 units)

### Required Courses (37 units)

- PH 200 - Contemporary Practice in Public Health 2 unit(s)</br>

- PH 201 - Groups and Training: Theory and Practice 2 unit(s)</br>

- PH 205A - Quantitative Methods for Public Health Practice I 3 unit(s)</br>

- PH 205B - Quantitative Methods in Public Health 3 unit(s)</br>

- PH 215 - Qualitative Methods for Public Health Practice 3 unit(s)</br>

- PH 225 - Evaluation Methods for Public Health Practice 3 unit(s)</br>

- PH 262 - Health Policy and Organization 3 unit(s)</br>

- PH 265 - Environmental Health 3 unit(s)</br>

- PH 271 - Theoretical Foundations of Public Health 3 unit(s)</br>

- PH 272 - Health Promotion Planning and Evaluation 3 unit(s) (GWAR)</br>

- PH 276 - Community Organization and Health Promotion 3 unit(s)</br>

- PH 277 - Multicultural Communication for Health Professionals 3 unit(s)</br>

- PH 293 - Public Health Leadership 3 unit(s)</br>


### Required Practicum (5 units)

- PH 291A - Fieldwork Seminar 1 unit(s)</br>

- PH 291B - Fieldwork Practicum 1-2 unit(s) (Students take 2 units of PH 291B )</br>

- PH 291C - Professional Skills for Public Health Practice 1 unit(s)</br>

- PH 291P - Professional Development 1 unit(s)</br>


### Culminating Experience (0-6 units)
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Students in the online/hybrid MPH program complete a Plan B (Comprehensive Exam).</br>
Campus MPH students can choose Plan B (Project) instead of the Comprehensive Exam. The project option requires additional coursework.</br>

#### Plan B (Graduate Project) (3-6 units)
The Plan B (Graduate Project) option requires an additional 3-6 units of coursework.</br>

#### Plan B (Comprehensive Exam) (0 units)
Taking the Comprehensive Exam requires no additional courses/units.</br>

## Total Units Required (42-48 units)
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>