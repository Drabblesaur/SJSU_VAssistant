
# Biological Sciences, Molecular, Microbial, and Physiological Biology Concentration, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science program in Biological Sciences with a concentration in Molecular, Microbial, and Physiological Biology, offered by the Department of Biological Sciences , offers students training in the pursuit of rigorous scientific investigation with an emphasis on discovering the molecular mechanisms that underlie biological processes and the integrative nature of physiology across levels of organization from molecule to cell to organism. During their research experience, students acquire the skills necessary to successfully address a variety of research questions under the guidance of faculty.</br>
In addition, students with our degree will have gained experience in critical thinking, problem-solving, research methodology (e.g., experimental design, sampling techniques, and analysis), and both written and oral communication. Our alumni are successful applicants for doctoral degree programs and generally attain high level academic and non-academic positions in both the private and public sectors.</br>
For more information visit the SJSU Biological Sciences website.</br>

## Admissions Requirements
Candidates must meet all the university admission requirements. In addition, applicants must upload a personal statement, resume, and two letters of recommendation in the Cal State Apply admissions portal. Applicants must also be accepted by a tenured or tenure-track faculty member in the Department of Biological Sciences prior to acceptance by the program. It is the student’s responsibility to contact any potential faculty advisors. For complete details on the student approval process, please visit the Biological Sciences Graduate Programs.</br>
Students can be admitted in either classified or conditionally classified standing. Conditional acceptance means that the candidate must fulfill specific requirements in order to be eligible to apply for advancement to candidacy. These conditions will be stipulated as part of the acceptance agreement between the faculty advisor and the applicant. Failure to fulfill these requirements will result in disqualification from the program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

## Requirements for Advancement to Graduate Candidacy
Each semester, students should consult with their graduate advisor to develop a schedule of courses. Students admitted as conditionally classified must satisfy the requirements listed in their acceptance agreement before advancing to candidacy. Students who have achieved classified standing in the master’s degree curriculum must next advance to candidacy for the degree. A student may advance to candidacy after completing a minimum of 9 units of letter-graded work as a graduate student in 100- or 200-level courses acceptable to the department as well as fulfilling the other university requirements for advancement to candidacy , as detailed in the Graduate Policies and Procedures  section. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which is satisfied in this degree by the completion of BIOL 202  with a grade of “B” or better.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS Biological Sciences, Concentration in Molecular, Microbial, and Physiological Biology, Graduation Requirements
As shown below, the program consists of 30 semester units of approved work. The student consults with his or her advisor to select a thesis or project topic.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
A grade of “B” or better in BIOL 202  will satisfy the graduate competency in writing requirement.</br>

### Culminating Experience Requirements
Plan A (Thesis)</br>
Thesis: The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. The MS thesis document must be approved by the student’s thesis research committee before submission. Typically, the thesis committee will provide the candidate feedback during the Thesis Defense and may request changes to the thesis before final approval.</br>
Oral Thesis Defense: All MS candidates are required to present a public seminar based on their research project.</br>
Plan B (Project)</br>
Written Project: The written project must be a manuscript describing the student’s research project, written following a professional journal’s format for submission. It will be written under the guidance of the candidate’s graduate committee chair with the assistance of their graduate committee. The manuscript must be approved by the student’s graduate committee. Typically, the committee will provide the candidate feedback during the Project Defense and may request changes to the manuscript before final approval.</br>
Oral Project Defense: All MS candidates are required to present a public seminar based on their research project.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- BIOL 201 - Graduate Seminar in Biological Sciences 1 unit(s)</br>

- BIOL 202 - Graduate Studies in Biology 3 unit(s) (GWAR)</br>

- BIOL 220 - Science Communication 3 unit(s)</br>

- BIOL 297 - Graduate Research 1-4 unit(s) (Students take a total of 8 core units of this class.)</br>


### Concentration Courses (9 units)

- BIOL 215 - Seminar in Advanced Genetics 3 unit(s)</br>

- BIOL 255MMP - Advanced Topics:Molecular, Microbial, and Physiological Biol 1-4 unit(s) (Students take at least 3 units of this class)</br>

- Complete 3 Units in Advanced Techniques:</br>

Complete 3 Units in Advanced Techniques:</br>

- BIOL 205 - Advanced Molecular Techniques 4 unit(s)</br>

- BIOL 227 - Advanced Physiological Techniques 3 unit(s)</br>

- *If BIOL 205 is chosen, 1 unit will apply toward elective units.</br>

*If BIOL 205 is chosen, 1 unit will apply toward elective units.</br>

### Electives (5 units)
Elective courses must be planned in consultation with the Graduate Advisor</br>

- BIOL 201 - Graduate Seminar in Biological Sciences 1 unit(s) (Up to 3 units can count as electives; repeatable up to 4 units)</br>

- BIOL 230 - Comparative Animal Physiology 3 unit(s)</br>

- BIOL 255MMP - Advanced Topics:Molecular, Microbial, and Physiological Biol 1-4 unit(s)</br>

- BIOL 297 - Graduate Research 1-4 unit(s) (Up to 2 units can count as electives; repeatable up to 10 units)</br>

- Other 100- or 200-level courses chosen with advisor consent</br>


### Culminating Experience (1 unit)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (Thesis)

- BIOL 299 - Master’s Thesis 1-4 unit(s) (1 unit required)</br>

- Seminar- Thesis Defense</br>


#### Plan B (Project)

- BIOL 298 - MS Project Culminating Experience 1 unit(s)</br>

- Seminar- Project Defense</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
At least 60% of the units applying toward the degree must be letter-graded coursework.</br>
A public seminar on the thesis or project must be given.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>