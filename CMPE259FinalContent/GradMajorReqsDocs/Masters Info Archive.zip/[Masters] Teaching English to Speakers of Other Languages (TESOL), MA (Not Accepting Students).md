
# Teaching English to Speakers of Other Languages (TESOL), MA (Not Accepting Students)
 </br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Admission to Classified Standing</br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MA TESOL prepares students to assess and systematically build the listening, speaking, reading and writing skills of students from other language backgrounds who wish to learn English or to improve their skills in English. The Department of Linguistics and Language Development  (LLD) strikes a balance between theory and practice. Students in the department are part of an ethnically and linguistically diverse student body, taught by nationally and internationally recognized faculty. Graduates from the MA TESOL program staff many of the area’s English as a Second Language programs at the university, community college, adult school, and private program level. In addition, a number of TESOL graduates have chosen careers in international settings, teaching English as a Foreign Language in universities, schools, and companies in Asia, Latin America, Europe, and other regions. MA TESOL graduates are also eligible to teach abroad through the U.S. government-sponsored Fulbright and English Language Fellow programs. Any undergraduate major is appropriate preparation for this degree. (Note that the department does not have a credentialing program.)</br>
Requirements for the MA TESOL include those established by the department. For information concerning university requirements, see the Academic Requirements section of this catalog.</br>

## Requirements for Admission to Conditionally Classified Standing
Students holding an accredited baccalaureate degree and who otherwise satisfy the graduate level admissions requirements  of San José State University (in the case of students with baccalaureate degrees from a university where English is not the principal language of instruction the minimum score of 577, computer score of 233, or Internet-based score of 90 on the TOEFL or 7.0 on IELTS) are eligible for admission as conditionally classified students. Students must have a grade point average of at least 3.0 in the last 60 semester (90 quarter) units.</br>

## Requirements for Admission to Classified Standing
In addition to the above requirements for conditionally classified standing, students in the MA TESOL program are eligible for admission as classified graduate students if they have completed two prerequisites, equivalent to LING 101 - Introduction to Linguistics  and LING 107 - Patterns of English , which must each be completed with a grade of “B” or better.</br>
Students admitted as conditionally classified may complete the requirements for classified standing after admission to the program; however, a “B” grade must be achieved in all prerequisite courses. Additionally, the granting of classified standing is subject to the coordinator’s review of the conditionally classified student’s work.</br>

## Advancement to Candidacy
The requirements for advancement to candidacy for the MA TESOL are those established by the university and the department. For information see the Graduate Policies and Procedures  section of this catalog.</br>

## Graduation Requirements

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . In the MA TESOL, this is satisfied with the core course LLD 250W - Becoming a Professional in Linguistics/TESOL .</br>

### Culminating Experience
Plan A (with Thesis)</br>
Completion of 30 units; approved thesis proposal and thesis. The thesis option allows a student to pursue research in an area of common interest to the student and a faculty member. A thesis proposal may grow out of a course or be developed in LLD 298 - Individual Study , and must be approved by the student’s advisor and thesis committee members. For more information, visit the Thesis and Dissertation Information website.</br>
Plan B (without Thesis)</br>
Students are required to complete a total of 30 units (27 required; 3 electives); in addition, students must pass a comprehensive examination. </br>

## Master’s Requirements (30 units)

### Core Courses (27 units)

- LLD 250W - Becoming a Professional in Linguistics/TESOL 3 unit(s) (GWAR)</br>

- LLD 260 - English Structures for Teaching I 3 unit(s)</br>

- LLD 261 - English Structures for Teaching II 3 unit(s)</br>

- LLD 270 - Second Language Acquisition 3 unit(s)</br>

- LLD 271 - Intercultural Communication and Second Language Acquisition 3 unit(s)</br>

- LLD 280 - Methods and Materials for Teaching English to Speakers of Other Languages 3 unit(s)</br>

- LLD 282 - Practicum in Teaching English to Speakers of Other Languages 3 unit(s)</br>

- LLD 283 - Curriculum and Assessment in TESOL 3 unit(s)</br>

- LLD 293 - Teaching College-level Reading and Writing 3 unit(s)</br>


### Additional Courses (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan A (with Thesis) (3 units)

- LLD 299 - Master’s Thesis 1-6 unit(s) (3 units required)</br>


#### Plan B (without Thesis) (3 units)

- One Elective 3 unit(s)</br>

- Comprehensive Exam 0 unit(s)</br>


### Elective Course (0-3 units)

- LING 111 - Introduction to Linguistic Phonetics 3 unit(s)</br>

- LING 112 - Introduction to Syntax 3 unit(s)</br>

- LING 113 - Introduction to Phonology 3 unit(s)</br>

- LING 114 - Introduction to Semantics and Discourse 3 unit(s)</br>

- LING 125 - Introduction to Historical and Comparative Linguistics 3 unit(s)</br>

- LING 161 - Psycholinguistics 3 unit(s)</br>

- LING 162 - Introduction to Morphology 3 unit(s)</br>

- LING 166 - Sociolinguistics 3 unit(s)</br>

- LING 201 - Phonology: Theory and Applications 3 unit(s)</br>

- LING 202A - Syntactic Theory 3 unit(s)</br>

- LING 203 - Semantic Structures 3 unit(s)</br>

- LING 213 - Linguistic Field Methods 3 unit(s)</br>

- Courses from other departments may be used as electives, with graduate advisor approval.</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>