
# Electrical Engineering, MS
 </br>

- Admissions Requirements</br>

- Requirements for Graduation</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Electrical Engineering, offered by the Department of Electrical Engineering , is designed to prepare our graduates for the dynamic global society. Our programs have made us a leading provider of engineering talent to Silicon Valley’s high-tech industry. The curriculum is continually updated to keep abreast of advances in the engineering profession and industry. Along with the traditional emphasis on fundamental scientific knowledge, current engineering practice using computer design tools is integrated into the curriculum. Information about the MSEE program can be found at https://www.sjsu.edu/ee/.</br>

## Admissions Requirements
Candidates for admission apply through the CSU admissions portal, calstate.edu/apply. Applicants must meet all admission requirements.</br>
Follow the link for general information about the university admission requirements  and process. Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirement webpage at GAPE.</br>

### Requirements for Admission to Classified Standing
To be admitted to classified standing, an applicant must possess a baccalaureate degree with a major in Electrical or Computer Engineering or its equivalent and a grade point average of 3.0 or better on a 4.0 scale from a U.S. university with an ABET-accredited Electrical or Computer Engineering program.</br>

### Requirements for Admission to Conditionally Classified Standing
Some applicants who do not qualify for classified standing may be admitted as conditionally classified graduate students. They must petition for a change to classified status after completing the common core graduate courses with grades of “B” or better. A maximum of 15 units earned before the student attains the classified status may be counted towards the MSEE degree requirements.</br>

#### Applicants with a BSEE Degree from an Accredited University in the U.S.
An applicant with a BS degree in Electrical or Computer Engineering from an accredited university within the United States, whose GPA is 3.0 or above on a 4.0 scale, will be admitted to classified standing (GRE is not required). An applicant with a GPA lower than 3.0 but higher than 2.75 on a 4.0 scale is required to submit their general GRE scores with the application. If accepted, the applicant will be admitted as a conditionally classified graduate student. Such a student may petition for a change to classified standing after successfully completing two of the following four courses: EE 210 , EE 221 , EE 250 , or EE 275  with a “B” or better grade in each course. Information about GRE score requirements can be found at Graduate Program Test Requirement.</br>

#### Applicants with a BS Degree in Another Branch of Engineering or Science from an Accredited University in the U.S.
An applicant who possesses a baccalaureate degree in another branch of Engineering or in Physics or Mathematics with a minimum GPA of 3.0 on a 4.0 scale is required to submit his/her general GRE scores with the application. If accepted, the applicant will be admitted as a conditionally classified graduate student. Such an applicant may be required to complete four undergraduate courses at the beginning of the graduate program. The four undergraduate courses are selected from EE 110 , EE 112 , EE 118 , EE 120 , EE 122 , EE 124 , and EE 140 . Following the completion of the undergraduate courses, the student must successfully complete two of the four graduate core courses, EE 210 , EE 221 , EE 250 , or EE 275  with a “B” or better grade in each course. He or she may not enroll in more than two other graduate courses before completing these requirements. Units for the undergraduate courses are not counted toward the MSEE degree unit requirement. Information about GRE score requirements can be found at Graduate Program Test Requirement.</br>

#### Applicants with Undergraduate Degrees from Foreign Universities
An applicant with a baccalaureate degree in Electrical, Electronic, Telecommunications, Computer Engineering, or other similar majors with a minimum GPA of 3.0 on a 4.0 scale is eligible to apply. Applicants are required to take an English-proficiency test (TOEFL or equivalent) and the general Graduate Record Exam (GRE). Information about minimum score requirements for English-proficiency tests and GRE can be found at Graduate Program Test Requirement. In general, there are no hard cut-offs on the GRE scores but the scores will be used with applicants’ degree and GPA to rank the candidates for admission.</br>
Applicants satisfying these requirements may be admitted as conditionally classified graduate students with the condition that they complete two of the four core graduate courses, EE 210 , EE 221 , EE 250 , or EE 275  with a “B” or better grade in each course before enrolling in any other graduate course. However, a student with a high GPA and GRE may be admitted into classified standing.</br>

#### Applicants from Other Graduate Programs within the University
A graduate student who has been admitted to another department in San José State University must complete at least one semester of work in that department before being able to transfer to the Electrical Engineering Department. A minimum GPA of 3.0 and general GRE are required. The scores will be used with applicants’ degree and GPA to compare the candidate with those seeking first-time admission.</br>
A “Change of Major Form” must first be approved by the GAPE office and the request transferred to the Electrical Engineering Department before the student may be considered for transfer into the Electrical Engineering program.</br>

### Requirements for Advancement to Graduate Candidacy
Matriculated graduate students must submit a Petition for Advancement to Graduate Candidacy a minimum of one semester prior to graduating. See the link for information about this requirement.</br>
Students also must fulfill the Graduation Writing Assessment Requirement (GWAR)  before advancing to candidacy. See the link for information about the GWAR.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Course Requirements
To meet the requirements for the MS - Electrical Engineering degree, a student must complete 33 units including GWAR with a cumulative GPA of 3.0 or better. The program provides two plans: MS thesis (Plan A) or MS Project (Plan B).</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan A (Thesis)</br>
Students choosing this option must complete the MSEE Thesis Proposal course (EE 299A ) or MSEE Project Proposal course (EE 297A ) and MSEE Thesis course (EE 299B ). The student is responsible for securing the commitment of three university faculty members, two of whom must be full-time EE faculty members, to serve as the student’s thesis committee, with one full-time EE faculty member agreeing to serve as thesis committee chair. The student must write a thesis or project proposal and have it approved by the thesis committee chair or project advisor and pass the MSEE Thesis or Project Proposal course (EE 299A  or EE 297A ) before enrolling in EE 299B . The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. The candidate for the MSEE degree must successfully pass a final oral defense of the thesis.</br>
Plan B (Project)</br>
The student must complete the MSEE Project Proposal course (EE 297A ) or MSEE Thesis Proposal course (EE 299A ) and MSEE Project course (EE 297B ). The student is responsible for securing the commitment of a full-time EE faculty member to serve as MSEE Project Advisor. The student must write a project or thesis proposal and have it approved by the project advisor or thesis committee chair and pass the MSEE Project or Thesis Proposal course (EE 297A  or EE 299A ) before enrolling in the final MSEE Project course (EE 297B ). The candidate for the MSEE degree must successfully pass a final defense of the project.</br>

## Master’s Requirements (33 units)

### Core Courses (9 units)

- EE 295 - Technical Writing - Engineering Ethics 3 unit(s) (GWAR) (Students with GWAR waivers take an additional 3 units of electives)</br>


#### Complete Two Courses From:

- EE 210 - Linear System Theory 3 unit(s)</br>

- EE 221 - Semiconductor Devices I 3 unit(s)</br>

- EE 250 - Probabilities, Random Variables and Stochastic Processes 3 unit(s)</br>

- EE 275 - Advanced Computer Architectures 3 unit(s)</br>


### Area of Specialization (9 units)
Students desiring to pursue an area of specialization not listed should consult graduate advisor.</br>

- Device Physics, Micro and Nano Electronics</br>

- Analog Electronics, Integrated Circuits</br>

- Power Electronics, Energy Systems</br>

- Communications, Signal Processing, Remote Sensing</br>

- Control, Robotics, Autonomous Systems</br>

- Digital Systems, Microprocessors and Computers, Embedded Systems</br>

- Network, Network Security, Mobile Network, loT</br>

- Quantum Computer, Quantum Information</br>

- Artificial Intelligence, Machine Learning, Deep Learning</br>


### Advisor Approved Electives (9 units)

### Culminating Experience (6 units)

#### Plan A (Thesis) (6 units)

- EE 299A - MSEE Thesis Proposal 3 unit(s)</br>

- or EE 297A - MSEE Project Proposal </br>

or EE 297A - MSEE Project Proposal </br>

- EE 299B - MSEE Thesis 3 unit(s)</br>


#### Plan B (Project) (6 units)

- EE 297A - MSEE Project Proposal 3 unit(s)</br>

- or EE 299A - MSEE Thesis Proposal </br>

or EE 299A - MSEE Thesis Proposal </br>

- EE 297B - MSEE Project 3 unit(s)</br>


## Total Units Required (33 units)
In special circumstances, a maximum of 3 units of approved courses taken outside the Electrical Engineering Department may be applied toward the MS - Electrical Engineering degree. Students who wish to take courses outside the Electrical Engineering Department must have pre-approval by the Graduate Advisor/Coordinator. In addition to the above requirements, students must satisfy all university requirements and procedures as stated in this catalog.</br>
 </br>