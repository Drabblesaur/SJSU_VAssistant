
# Environmental Studies, MS
 </br>

- Admissions Requirements</br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Environmental Studies program, offered by the School of Planning, Policy and Environmental Studies , is designed to prepare students for careers as environmental professionals or to pursue further academic training in Ph.D. and other advanced degree programs. Global and local perspectives are integrated in the coursework and the faculty and students embrace a diversity of perspectives. Faculty members work closely with graduate students within the above areas of specialization to execute a program of study. For additional information, review the list of faculty thesis advisors and contact those with focus areas of interest to you. See the department website for more information: www.sjsu.edu/envs/graduate.</br>
Our interdisciplinary curriculum embraces both quantitative and qualitative research, and some of the topics that it focuses on include:</br>

- California Wild (Protected) Lands</br>

- Forest Ecology and Conservation</br>

- Climate Impacts Research</br>

- Human Ecology</br>

- Coastal Environments</br>

- Agroecology</br>

- Insect Conservation</br>

- Corporate Sustainability</br>

- Marine Environments</br>

- Energy</br>

- Nature and Conservation Photography</br>

- Environmental Education</br>

- Political Ecology</br>

- Environmental Impact Assessment</br>

- Pro-environmental Behavior</br>

- Environmental Justice</br>

- Sustainable Food Systems</br>

- Environmental Policy</br>

- Water Resources Management</br>

- Environmental Restoration</br>

- Wetlands Ecology, Restoration, and Management</br>

- Wildlife Conservation and Management</br>


## Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system at calstate.edu/apply and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the Environmental Studies Program. See the GAPE Graduate Admissions website and this Catalog for general information about admission requirements  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE. For TOEFL Requirements, see the Policies and Procedures  section, Graduate and Post-Baccalaureate Information .</br>

## Requirements for Admission to Classified Standing
The Department of Environmental Studies admits students to the Master of Science programs in Classified or Conditional Standing. Contact the department or see our admissions materials for specific application deadlines. For admission to classified standing the department requires the following:</br>

- An undergraduate degree in Environmental Studies or related field from an accredited institution.</br>

- An overall grade point average of 3.0 (“B”) or better for the last 60 semester units of academic study.</br>

- The capability, in the opinion of the graduate committee, of successfully completing degree requirements.</br>

- The removal of deficiencies if preparation differs markedly from the BS - Environmental Studies at San José State University. (BA students may be required to complete a general science background.) Courses used to remove such deficiencies cannot be used to fulfill MS requirements. For further information, see the graduate coordinator.</br>

- Two letters of recommendation from university faculty members or professionals in the field.</br>

- A personal statement of purpose that describes your background and objectives for seeking the MS - Environmental Studies at SJSU. This letter should also convey a sense of focus and direction for thesis research and potential faculty thesis advisers in the department.</br>

- Applicants from countries in which the native language is not English must achieve a minimum score of 580 (Paper Based), 237 (Computer Based), or 92 (Internet Based) on the TOEFL exam for foreign students.</br>


## Requirements for Admission to Conditionally Classified Standing
If not accepted into classified standing, the applicant may qualify for conditionally classified status for which the following will be required: the ability, in the opinion of the departmental graduate committee, to remove deficiencies in a period not to exceed the equivalent of one full-time semester of coursework. The individual admission letter will explain the required terms and conditions for attaining Classified standing.</br>

## Requirements for Advancement to Candidacy
Once a student has completed all required courses, with the exception of ENVS 299  and has submitted a completed and signed thesis proposal to the Graduate Coordinator, a Petition to Advance to Candidacy must be submitted to the Graduate Coordinator and GAPE office. The application to candidacy should be submitted a year prior to the expected graduation date. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, students must secure a commitment of three faculty members of the university, two of whom must be members of the permanent faculty, to serve as members of the student’s Plan A (thesis) or Plan B (Project) committee, with one permanent faculty member agreeing to serve as chair. The committee must approve the student’s thesis or project proposal for the master’s degree no later than one month prior to the end of the semester preceding the one in which enrollment in the final project or thesis course(s) is planned.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
In consultation with the department graduate coordinator, the candidate will develop and pursue a program of study. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approval Program.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . </br>

### Culminating Experience
Students choose a Plan A (Thesis) or Plan B (Project) option as their program culminating experience. Each student must secure the commitment of three faculty members of the university, two of whom must be members of the permanent faculty, to serve as members of the student’s Plan A (thesis) or Plan B (Project) committee, with one permanent faculty member agreeing to serve as chair. The committee must approve the student’s thesis or project proposal for the master’s degree no later than one month prior to the end of the semester preceding the one in which enrollment in the final project or thesis course(s) is planned.</br>
Plan A (Thesis)</br>
The thesis will include original research on a topic approved by the thesis committee and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will undergo a thorough review and revision process under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. In addition, the candidate for the MS degree must successfully pass a final oral defense of the thesis.</br>
Plan B (Project)</br>
Under rare circumstances, a very strong project of appropriate scope and depth for master’s level work might be approved in lieu of the thesis. This option requires the written consent of at least three graduate advisors, the graduate coordinator, and the department chair. In addition to the required coursework, Plan B students will take comprehensive examinations on three topics to be arranged by the student’s project committee.</br>

## Master’s Requirements (30 units)

### Seminars (9 units)

- ENVS 200 - Seminar: Environmental Methods 3 unit(s)</br>

- ENVS 250 - Seminar: Environmental Thought and Philosophy 3 unit(s)</br>

- ENVS 297 - Research and Proposal Development 3 unit(s) (GWAR)</br>


### Application Science (9 units)
9 units of 100- or 200-level field analysis, laboratory work, or other form of application science selected with advisor’s approval.</br>

### Electives (6 units)

- 100- or 200-level courses in Environmental Studies or related fields selected with advisor’s approval. The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (Thesis) (6 units)

- ENVS 299 - Master’s Thesis 1-6 unit(s)</br>


#### Plan B (Project) (6 units)

- ENVS 298 - Special Study 1-4 unit(s) (3 units required)</br>

- Additional 3 units of electives selected with advisor’s approval 3 unit(s)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>