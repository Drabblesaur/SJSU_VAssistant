
# Multilingual and Multicultural Literacy Education, MA
 </br>

- Admissions Requirements</br>

- Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes    </br>

The Multilingual and Multicultural Literacy Education (MMLE) master’s degree program, offered by the Department of Teacher Education , prepares educators to center the experiences of marginalized youth at the heart of literacy teaching and learning. With a focus on teaching PK-12 multilingual youth and students who have not been traditionally well served by public schools, this 30-unit program meets the requirements of California’s Reading and Literacy Leadership Credential. The culminating project is an online portfolio showcasing each student’s work. The MMLE program is fully online.</br>

## Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply and meet all the university admissions requirements. Required documents include:</br>

- Transcripts.</br>

- Applicants must have earned a Bachelor’s degree from a regionally accredited institution.</br>

- Two letters of recommendation are required.</br>

- A resume or CV. </br>

- Applicants  who are interested in earning the California Reading Specialist Added Authorization or the Reading and Literacy Leadership Credential must hold a current preliminary teaching credential.</br>

- Applicants should have the ability to work in a PK-12 classroom.</br>

- Applicants from countries in which the native language is not English must submit TOEFL scores. Minimum TOEFL scores acceptable for admission are 600 (Paper-based), 250 (Computer-based), or 100 (Internet-based).</br>


## Advancement to Candidacy
Students must maintain an overall grade point average (GPA) of 3.0 at all times; otherwise they will be placed on academic probation and required to raise the overall GPA above the 3.0 minimum during the subsequent semester. Failing to do so will result in disqualification from the program.</br>

## Requirements for Graduation
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements section of the Graduate Policies and Procedures . Completion of the degree also requires a minimum grade of “C” in all courses taken and a minimum overall GPA of 3.0.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . The GWAR is satisfied in this degree with EDTE 290C .</br>

### Culminating Experience
Portfolio</br>
The culminating project for the MMLE program is an online portfolio that evidences candidates mastery of the PLOs and California Commission on Teacher Credentialing program standards. The portfolio is a significant undertaking that evidences originality and independent thinking, appropriate form and organization, and a rationale. It is described and summarized in a website that includes the portfolio’s significance, objectives, methodology, and conclusion.</br>
The portfolio is cumulative over the course of the 30-unit program. The final two courses (EDTE 212 - Critical Literacy Leadership Practicum  and EDTE 242R - Critical Literacy Student Practicum ) ensure completion and finalization, including ensuring that all PLOs and standards are met. EDTE 212 addresses aspects of literacy leadership, and EDTE 242R addresses candidates’ literacy teaching. The portfolio also serves as a tool that candidates can use for providing ongoing professional learning for their peers, as it contains examples of assessments and instruction that can be shown to colleagues in professional learning settings. A tertiary purpose for the portfolio is for participants to use it to advance their professional opportunities, such as providing evidence of their accomplishments to future employers. </br>

## Master’s Requirements (30 units)

### Core Courses (20 units)

- EDTE 216 - Culturally Responsive Assessment for Instruction 4 unit(s)</br>

- EDTE 215 - Culturally and Linguistically Sustaining Literacy Instruction 4 unit(s)</br>

- EDTE 220 - Advanced Critical Literacy Instruction 3 unit(s)</br>

- EDTE 223 - Politics, Theory and Practice of Critical Literacy 3 unit(s)</br>

- EDTE 245 - Assessment and Instruction for Culturally Sustaining Literacy Leadership 3 unit(s)</br>

- EDTE 290C - Critical Literacy Research Methods 3 unit(s) (GWAR)</br>


### Practicums (4 units)

- EDTE 217A - Practicum Culturally Responsive Assess to Instruct 2 unit(s)</br>

- EDTE 217B - Practicum: Culturally Sustaining Literacy Instruct 2 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when the Culminating Experience has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- EDTE 212 - Critical Literacy Leadership Practicum 3 unit(s)</br>

- EDTE 242R - Critical Literacy Student Practicum 3 unit(s)</br>


## Total Units Required (30 units)
 </br>