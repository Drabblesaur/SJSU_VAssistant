
# Bioinformatics, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (34 units)</br>

- Program Learning Outcomes  </br>

The MS Bioinformatics, offered by the Department of Computer Science , features an interdisciplinary curriculum in bioinformatics, biology, computer science, and mathematics. Questions in many areas of biology, including genomics, molecular biology, neuroscience, physiology, microbiology, ecology, and evolution, must now be answered using mathematical and computational methods. New techniques allow the acquisition of many thousands or millions of biological measurements, and the field of bioinformatics has developed to address this need. The MS Bioinformatics program will provide students with an understanding of biological questions, a background in mathematics, and the computational skills necessary to address complex problems in the biological sciences. Students will also gain experience utilizing these skills to answer biological questions, including those with biomedical applications. The goal of the MS in Bioinformatics program is to prepare students for careers in the growing field of bioinformatics both in academia and in the biotechnology industry.</br>
For more information, please visit the MS Bioinformatics website.</br>

## Admissions Requirements

### University Admission
Candidates must apply through the CSU admissions portal, Cal State Apply, and meet all university admissions requirements. Applicants from countries in which the native language is not English or from countries with multiple native languages including English, must submit TOEFL scores. Minimum TOEFL scores acceptable for admission are 250 (Computer Based), 100 (Internet Based). Additional information about the TOEFL is on the Graduate Program Test Requirement webpage.</br>

### Admission to the Program
Candidates must meet all the university admission requirements . Students can be admitted in either classified or conditionally classified standing. To be admitted to classified standing, applicants must have a Bachelor’s degree from an accredited college or university in the biological or computational sciences or in engineering, a minimum GPA of 3.0 on a 4.0 scale, and completion of all program prerequisites listed on the admission requirements webpage. Two letters of recommendation from academic instructors or advisors are also required. Currently, GRE exam results are not required.</br>
Students who meet the minimum university admission requirements can be conditionally classified if there is sufficient space in the program to accommodate them. Conditionally classified students will be required to complete undergraduate coursework and prerequisite coursework (listed in “Requirements for Admission to Classified Standing”), as directed by the graduate coordinators.</br>

#### Requirements for Admission to Classified Standing
To enter this program with classified standing, a student must have a minimum 3.0 GPA in the last 60 units of required degree coursework and have completed each of the following courses with a grade of “C” or better:</br>

- BIOL 30 - Principles of Biology I  (4 units)</br>

- BIOL 31 - Principles of Biology II  (4 units)</br>

- BIOL 115 - General Genetics  (4 units)</br>

- CS 22A - Python for Everyone  (3 units)</br>

- CS 22B - Python Programming for Data Analysis  (3 units)</br>

- MATH 30 - Calculus I  (3 units)</br>

- MATH 31 - Calculus II  (4 units)</br>

- MATH 161A - Applied Probability and Statistics I  (3 units)</br>


## Requirements for Advancement to Candidacy
To be advanced to candidacy for the MS degree, a student must meet the university requirements for advancement to candidacy  for the master’s degree as outlined in the Graduate Policies and Procedures  section. University requirements include completion of 9 letter-graded units with a GPA of at least 3.0 and satisfaction of the Graduation Writing Assessment Requirement (GWAR) . The GWAR is met in this program by a “B” grade in CS 200W .</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . This requirement is satisfied by taking CS 200W . </br>

### Culminating Experience
Under the direction of a Project Advisor, students will complete a culminating written project or thesis describing original bioinformatics research and formatted for publication in a professional journal, and will give an oral defense of their research to a committee. Students can choose one of three tracks for this project: Biological Sciences, Computer Science, and Mathematics. The Project Advisor must be a full-time tenured or tenure-track faculty member in the department of the chosen track. The committee, which will evaluate the written project or thesis and the defense, will consist of the Project Advisor and two other members, one of whom must be a full-time tenured or tenure-track faculty member at SJSU. The research topic and the committee must be approved by the Bioinformatics Graduate Coordinator. Students will conduct their research while enrolled in at least 2 consecutive Culminating Experience courses in the department of their chosen track, with their Project Advisor as the instructor. Students in the Biological Sciences track will enroll in BIOL 297  while working on the research project and enroll in BIOL 298  the semester they complete the project. Students in the Computer Science track will take CS 297  followed by either CS 298  or CS 299 . Students in the Mathematics track will take MATH 297A  followed by MATH 298  or MATH 299 . </br>

## Master’s Requirements (34 units)

### Core Courses (19 units)

- CS 123A  OR  BIOL 123A - Bioinformatics I 3 unit(s)</br>

- CS 123B  OR  BIOL 123B - Bioinformatics II 3 unit(s)</br>

- BIOL 205 - Advanced Molecular Techniques 4 unit(s)</br>

- CS 200W - Graduate Technical Writing 3 unit(s) (GWAR)</br>

- CS 223 - Advanced Bioinformatics 3 unit(s)</br>

- MATH 162 - Statistics for Bioinformatics 3 unit(s)</br>


### Electives (9 units)
At least 6 units must be graduate level.</br>

- BIOL 135A - Eukaryotic Cell and Molecular Biology I 3 unit(s)</br>

- BIOL 135B - Eukaryotic Cell and Molecular Biology II 3 unit(s) (GE UD Area 2/5 / Formerly Area R)</br>

- BIOL 215 - Seminar in Advanced Genetics 3 unit(s)</br>

- BIOL 256 - Advanced Experimental Design and Analysis 3 unit(s)</br>

- CHE 293 - Applied Bioinformatics 3 unit(s)</br>

- CS 122 - Advanced Programming with Python 3 unit(s)</br>

- CS 131 - Processing Big Data - Tools and Techniques 3 unit(s)</br>

- CS 133 - Introduction to Data Visualization 3 unit(s)</br>

- CS 218 - Topics in Cloud Computing 3 unit(s)</br>

- CS 224 - Next Generation Sequencing & Genome Assembly 3 unit(s)</br>

- CS 225 - Topics in Sequence-based Machine Learning for Bioinformatics 3 unit(s)</br>

- CS 255 - Design and Analysis of Algorithms 3 unit(s)</br>

- CS 256 - Topics in Artificial Intelligence 3 unit(s)</br>

- CS 257 - Database System Principles 3 unit(s)</br>

- CS 267 - Topics in Database Systems 3 unit(s)</br>

- CS 271 - Topics in Machine Learning 3 unit(s)</br>

- CS 280 - Graduate Individual Studies 1-3 unit(s)</br>

- Other 100- or 200-level courses may be accepted only with prior program coordinator consent.</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Select one of the following tracks in consultation with the Graduate Advisor:</br>

#### Biological Sciences Track (6 units)

- Select one of the following in consultation with the Graduate Advisor:  BIOL 297 - Graduate Research  1-5 unit(s) CS 297 - Preparation for Writing Project or Thesis  3 unit(s) MATH 297A - Preparation for Writing Project, Research Project or Thesis  3 unit(s) Additional Electives with advisor consent  </br>

- BIOL 297 - Graduate Research  1-5 unit(s)</br>

- CS 297 - Preparation for Writing Project or Thesis  3 unit(s)</br>

- MATH 297A - Preparation for Writing Project, Research Project or Thesis  3 unit(s)</br>

- Additional Electives with advisor consent</br>

- BIOL 298 - MS Project Culminating Experience  1 unit(s)</br>


#### Computer Science Track (6 units)

- CS 297 - Preparation for Writing Project or Thesis 3 unit(s)</br>

- CS 298 - Master’s Writing Project 3 unit(s)</br>

- or CS 299 - Master’s Thesis  3 unit(s)</br>

or CS 299 - Master’s Thesis  3 unit(s)</br>

#### Mathematics Track (6 units)

- MATH 297A - Preparation for Writing Project, Research Project or Thesis 3 unit(s)</br>

- MATH 298 - Special Study 1-4 unit(s)</br>

- or MATH 299 - Master’s Thesis  3 unit(s)</br>

or MATH 299 - Master’s Thesis  3 unit(s)</br>

## Total Units Required (34 units)
Elective courses must be planned in consultation with one of the Graduate Coordinators.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 12.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of at least 3.0 in order to graduate.</br>
 </br>