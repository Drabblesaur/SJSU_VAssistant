
# Chemistry, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MA Chemistry degree is designed for persons who seek to augment and enhance their knowledge of chemistry beyond the bachelor’s level. It is intended for (1) those who are interested in teaching chemistry at community colleges, (2) high school teachers who are currently certified and have teaching experience, (3) those who are interested in chemical sales, technical librarianship, and scientific writing, or (4) those who already have a significant amount of research experience. The MA degree is not recommended to those who wish to conduct or direct chemical research and have no previous research experience in the private sector.</br>
For more information visit the Chemistry Department’s Graduate Programs webpage.</br>

## Admissions Requirements
The applicant must apply to and be admitted by both San José State University and the Department of Chemistry . Check the SJSU graduate admissions requirements website and the Chemistry Department website for the most up-to-date instructions.</br>

### Admission to the University
Applicants are admitted to the program by the Chemistry Department Graduate Advisor after they have been admitted to the graduate school by the university. University admission requirements  include a bachelor’s degree (or equivalent), a minimum 2.5 GPA, and good standing at the last college or university attended. Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Admission to the Chemistry Department
The Chemistry Department requires that the bachelor’s degree be in chemistry or intimately related science (e.g., chemical physics, biochemistry, materials science). In all cases, however, incoming students must have had the equivalent of 40 semester units of undergraduate chemistry including at least 10 units of general chemistry, 10 units of organic chemistry, 4 units of analytical chemistry, and 4 units of physical chemistry. A grade point average of 3.0 or higher for the chemistry coursework is preferred. In addition, admission to the Chemistry MA program requires at least two, but preferably three, letters of recommendation.</br>

### Admissions Status
Admission may be with graduate classified standing, which means that the student is deemed qualified to enroll in the graduate curriculum. In some cases, students are admitted with conditionally classified standing, which means that they must complete specified prerequisite work and/or graduate work with acceptable grades before they can be moved to classified status. Students with conditionally classified status should complete the conditions of their acceptance as early as possible. Such students may take graduate courses at the same time they are fulfilling the conditions. Prerequisite work is assigned for one or more of the following reasons: (1) low chemistry course GPA in undergraduate work, (2) insufficient number of undergraduate units in chemistry, or (3) lack of coursework in particular areas of study. In order to change from conditionally classified to classified standing, a student must (1) fulfill the conditions, and (2) obtain the Graduate Advisor’s signature on the Change of Classification in Graduate Program form. Only students in classified standing may petition for advancement to candidacy, a requirement for graduation.</br>

## Requirements for Advancement to Graduate Candidacy
After approximately two semesters of coursework and completion of a preliminary seminar based on a proposed, faculty-guided research project, students may apply for advancement to graduate candidacy for the MA degree. In addition, the student must have graduate classified status and must have completed CHEM 100W  for the Graduation Writing Assessment Requirement (GWAR) . The Preliminary Seminar Guidelines and Evaluation form may be found on the Chemistry Department Forms webpage. The 30-unit Proposed Graduate Degree Program is written by the Graduate Advisor in consultation with the student and entered on the Advancement to Graduate Candidacy form, which must be approved and signed by the Graduate Advisor. Students cannot enroll in their written culminating experience course (CHEM 299  (Plan A) or CHEM 298  (Plan B)) or apply for graduation until they are official candidates for a degree. See the Graduate Policies and Procedures  section for further details regarding university requirements for advancement to candidacy  for the master’s degree.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Program Graduation Requirements
Note that the coursework requirements for the MA degree differ from the requirements for the MS degree in Chemistry. In addition to completing the 30 units of coursework listed on the approved candidacy form, an MA degree candidate in Chemistry must complete the following activities as part of their culminating experience:</br>

#### Final Seminar
All MA candidates are required to present a departmental seminar based on their research project. The seminar is scheduled through the faculty instructor for CHEM 285  and, therefore, must take place during the fall or spring semester.</br>

#### Final Oral Examination
All MA candidates are required to pass a Final Oral Examination based on the research project as detailed in the thesis or research report. The Final Oral Examination is administered by the master’s committee, and the candidate must provide the committee with a copy of the thesis or research report for review at least two weeks prior to the exam date. The Final Oral Examination may be scheduled on the same date as the Final Seminar if the two-week thesis/ research report delivery requirement is met.</br>

#### Written Culminating Experience
 All MA candidates must complete a final written culminating experience on their research either as a thesis (Plan A) or research report (Plan B).</br>
The MA thesis document must be approved by the student’s thesis research committee before submission. Typically, the master’s committee will provide the candidate feedback during the Final Oral Examination and may request changes to the thesis before final approval. See the most current version of the SJSU Master’s Thesis and Doctoral Dissertation Guidelines and the submission deadlines set by the College of Graduate Studies.</br>
OR </br>
The MA research report must be a manuscript describing the student’s research project, written following a professional journal’s format for submission. The report must be approved by the student’s master’s committee before submission. Typically, the committee will provide the candidate feedback during the Final Oral Examination and may request changes to the research report before final approval.</br>

## Master’s Requirements (30 units)

### Graduation Writing Assessment Requirement
Students must pass the Graduation Writing Assessment Requirement (GWAR) . This requirement is satisfied in the core courses.</br>

### Core Courses (21 units)

- CHEM 100W - Writing Workshop: Chemical Communications 3 unit(s) (GWAR)</br>

- If CHEM 100W  was completed for an undergraduate degree, three additional units of electives must be substituted</br>

If CHEM 100W  was completed for an undergraduate degree, three additional units of electives must be substituted</br>

- CHEM 120S - Chemical Safety Seminar 1 unit(s)</br>

- CHEM 285 - Seminar 1 unit(s) (2 units required - complete course 2 times)</br>

- CHEM 297 - Graduate Research 1-6 unit(s) (3 units required)</br>

- Preliminary Seminar Presentation</br>

- CHEM 200-Level Courses 12 unit(s)</br>


### Electives (7 units)
Any 200-level CHEM course or any 100-level CHEM Chemistry course from the following list with graduate advisor consent; one of the electives must be an advanced chemistry laboratory course</br>

- CHEM 105 - Computational Data Analysis in Chemistry 3 unit(s)</br>

- CHEM 114 - Advanced Organic Chemistry Lab 3 unit(s)</br>

- CHEM 121S - Radiation Safety 1-2 unit(s)</br>

- CHEM 126 - Introduction to Nuclear Science 3 unit(s)</br>

- CHEM 127 - Nuclear Science Lab 3 unit(s)</br>

- CHEM 130A - Biochemistry 4 unit(s)</br>

- CHEM 130B - Biochemistry 4 unit(s)</br>

- CHEM 130C - Biochemistry 3 unit(s)</br>

- CHEM 131A - Biochemistry Lab 2 unit(s)</br>

- CHEM 135 - General Biochemistry 4 unit(s)</br>

- CHEM 145 - Inorganic Chemistry 3 unit(s)</br>

- CHEM 146 - Physical-Inorganic Techniques 3 unit(s)</br>

- CHEM 155 - Instrumental Analysis 4 unit(s)</br>

- CHEM 170A - Macromolecular, Supramolecular & Nanoscale Systems 1 unit(s)</br>


### Culminating Experience (2 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one option (Plan A or Plan B):</br>

#### Plan A (Master’s Thesis)

- CHEM 299 Master’s Thesis   (2 units required)</br>

- Department Seminar Presentation</br>

- Oral Examination</br>


#### Plan B (Master’s Research Report)

- CHEM 298 Research  (2 units required)</br>

- Department Seminar Presentation</br>

- Oral Examination</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>