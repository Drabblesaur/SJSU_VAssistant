
# Packaging, MS
 </br>

- Requirements for Admission to Classified Standing</br>

- Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy for the MA - Philosophy</br>

- Completing Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Packaging program, offered by the Department of Nutrition, Food Science and Packaging , is designed to meet the needs of the student who has a baccalaureate degree and seeks advanced preparation in packaging and packaging related fields. Meanwhile, a wide variety of types of companies employ graduates with advanced degrees. The Master of Science in Packaging program will help to educate packaging professionals and create innovative solutions that enhance or maintain product quality, increase packing efficiency and reduce waste. Students will gain experience in applying mathematics, science, and technology to packaging-related problems, assessing the suitability of packaging materials and designs for specific applications, and in critically evaluating new knowledge presented in the scientific literature. Graduates with advanced graduate degrees are less likely to go into production positions and more likely to go into education, research, or management positions than those with bachelor’s degrees.</br>

### Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. See the Graduate Admissions website and Graduate Admissions for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see English Language Proficiency Requirement.</br>

### Requirements for Admission to Classified Standing
Candidates must meet all the university admission requirements. Students can be admitted to the MS, Packaging program in either classified or conditionally classified standing. All prospective students submit one application to obtain approval for university-level admission and department-level admission into the M.S. in Packaging program. A departmental selection committee will rank applicants for admission to classified standing on the basis of information provided in the application. Criteria include:</br>

- BS degree in Packaging or related field.</br>

- Grade point average of B.S. upper division coursework</br>

- GRE scores</br>

- Letter of intent</br>

- Three letters of recommendation</br>

- Research and professional experience</br>


### Requirements for Admission to Conditionally Classified Standing
Students seeking an MS, Packaging degree who meet requirements for admission to the Graduate Division, but do not have a B.S. degree in Packaging or equivalent, may apply for conditionally classified standing in the department. The decision to accept the student for study in this program will be made by a departmental selection committee. Criteria include:</br>

- BA or BS degree</br>

- Grade point average of B.S. or B.A. upper division coursework</br>

- GRE scores</br>

- Letter of intent</br>

- Three letters of recommendations</br>

- Research and professional experience</br>


### Requirements for Advancement to Candidacy for the MS - Packaging
Prior to registering for the first time (or upon re-entering), a student should consult with the Graduate Coordinator to develop a schedule of courses. Advancement to candidacy for the Master’s degree in Packaging requires favorable action of the Graduate Committee of the Department of Nutrition, Food Science and Packaging and of the university’s Office of Graduate Admissions & Program Evaluations (GAPE). In general, students will be recommended for candidacy when they:</br>

- Fulfill all university requirements for advancement to candidacy.</br>

- Attain classified graduate standing</br>

- Complete a minimum of 9 units of letter-graded approved courses.</br>

- Earn a minimum 3.0 grade point average for the combined coursework listed on the candidacy form.</br>

- Successfully complete NUFS/PKG 217 with at least a “C” to meet the Graduation Writing Assessment Requirement (GWAR).</br>

- Select a graduate advisor and thesis or project topic or opt for the comprehensive exam.</br>


## Requirements for Graduation

### University Requirements for Graduation
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements section of the Graduate Policies & Procedures. </br>

### MS - Packaging Graduation Requirements
Completion of 30 units of approved coursework including the core courses. Maintenance of a 3.0 GPA is necessary. Completion of the culminating experience of such scope and manner as determined by the student’s graduate committee or graduate advisor. The program consists of 30 semester units of approved work, including 6 units of Plan A (Thesis) or 3 units of Plan B (Project) or 3 units of Plan B (Comprehensive exam).</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan A (Thesis)</br>
For this plan, the student is required to complete 6 units of PKG 299 - Master’s Thesis. The student is required to complete a research project under advisement of a Nutrition, Food Science and Packaging faculty. The research must result in the generation of a thesis that meets the University Master’s Thesis and Doctoral Dissertation Guidelines. The student must pass an oral examination defending the research to a departmental faculty committee. The student must prepare an oral presentation or poster presentation for the public.</br>
Plan B (Project)</br>
For this plan, the student is required to complete 3 units of PKG 298 - Special Studies in Nutrition, Food Science and Packaging. The student is required to complete a project under advisement of a Nutrition, Food Science and Packaging faculty. The student is required to submit a written project in publication format, pass an oral examination defending the project to a departmental faculty committee, and prepare an oral presentation or poster presentation for the public.</br>
Plan B (Comprehensive Exam)</br>
All graduate students opting for the courses-only option must pass the Comprehensive Exam (given once a semester) to earn the MS in Packaging degree. The Comprehensive Exam is the student’s opportunity to demonstrate mastery and integration of the knowledge and skills of the MS in Packaging curriculum. The comprehensive exam is a written exam that is administered on campus in the Packaging computer lab.</br>

## Master’s Requirements (30 units)

### Core Courses (21 units)

- NUFS 201 /PKG 201 - Colloquium in Nutrition, Food Science and Packaging  3 unit(s)</br>

- NUFS 217 /PKG 217 - Issues in Nutrition, Food and Packaging  3 unit(s) (GWAR)</br>

- NUFS 257 - Biostatistics in Research  3 unit(s)</br>

- NUFS 295A /PKG 295A - Research Methodology  3 unit(s)</br>


#### Complete three courses:

- PKG 270 - Package Design for End Use  3 unit(s) </br>

- PKG 268 - Advanced Laboratory Testing and Analysis  3 unit(s)</br>

- PKG 170 - Packaging Development and Management  3 unit(s)</br>

- PKG 272- Advanced Materials and Testing 3 unit(s) (Currently being developed)</br>


### Graduate Electives (3-6 units)
3-6 units electives selected in consultation with the graduate advisor.</br>

### Culminating Experience (3-6 units)
Complete Plan A (Thesis) OR Plan B (Project)</br>

- Plan A (Thesis) (6 units)  PKG 299 - Master’s Thesis  1-6 unit(s)</br>

- Plan B (Project) (3 units) PKG 298 - Special Studies in Packaging  (3 units required)</br>

- Plan B Comprehensive Exam PKG 298 - Special Studies in Packaging  (3 units required)</br>


## Total Units Required (30 units)

- Elective courses must be planned in consultation with the Graduate Advisor. Choose from: PKG 121 , PKG 158 , and PKG 160 .</br>

- The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>

- Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>

 </br>