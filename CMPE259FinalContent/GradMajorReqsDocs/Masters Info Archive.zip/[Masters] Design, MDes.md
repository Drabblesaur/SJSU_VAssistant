
# Design, MDes
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Master’s Requirements (60 units)</br>

- Program Learning Outcomes  </br>

The Master of Design (MDes) graduate program at SJSU offers advanced and rigorous studies in design with unique specializations in experience design and animation. Strategically located in California’s Silicon Valley, at the center of a globally renowned technology and innovation hub, the MDes program at SJSU sits at the intersection of technology, industry and academia. With a focus on current professional practices, the MDes is an incubator for new ideas and methods. The MDes degree is comparable to an MFA and considered a terminal degree in fields where a PhD is not offered. Additional information is available on the Department of Design website.</br>

#### Master of Design (MDes) with a Specialization in Animation
With a strong focus on both content creation and digital technology, our Master of Design with a Specialization in Animation is the perfect incubator for your creative ideas and animation career. The program is project based and tailored to nurture the creativity and vision of each student by providing opportunities for individual accomplishment. Ours is a creative community that will help promote the expression of unique and exceptional work. </br>
This rigorous program pairs content creation with a strong technical component that goes hand in hand with its artistic aspects. Technical courses include CG animation, lighting, rendering, and building interactivity in animation and games.</br>

#### Master of Design (MDes) with a Specialization in Experience Design
The experience design specialization is a two-year program built on multidisciplinary collaboration, design practice, new technology, research, and scholarship that seeks to push the boundaries of design for experience. Our aim is to develop new generations of creative leadership that can design for emerging complex challenges in the field of design and the world at large.</br>
All courses are offered in Silicon Valley near tech companies, world-class museums, start-up companies and groundbreaking design firms. With easy access to San Francisco, Oakland and the surrounding Bay Area students can complete their degree while also pursuing internships and/or continuing their careers.</br>

## Admissions Requirements
Prospective students should have a demonstrable academic and/or professional background in the following areas. For the Experience Design Specialization: graphic design, industrial design, product design, user-experience design, user-interface design, interaction design, data visualization, information design and/or other related disciplines. For the Animation Specialization: storyboarding, animation, digital media, illustration, game development or fine arts. A strong portfolio and/or animation reel is required in order to be accepted into the program.</br>
See the MDes program website for more information.</br>

## Requirements for Advancement to Graduate Candidacy
General university requirements for advancement to candidacy  for the MDes degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the  Graduation Writing Assessment Requirement (GWAR) . Application for advancement to candidacy should be done by the middle of the semester before students intend to graduate.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) . </br>

### Culminating Experience
All students must complete a culminating experience in the form of a creative (master’s) project under Plan B (degree without thesis plan) of the university’s guidelines for master’s degrees. This will consist of a public exhibition, oral presentation and a written element documenting research, process and exhibition. The master’s project undergoes a thorough review and revision process under the guidance of the committee chair and with the assistance of the committee advisors.</br>
Each student will form a master’s project committee consisting of at least three members. Committee membership will consist of (1) a committee chair and (2) two to four committee advisors. The committee chair must be an SJSU tenured/tenure-track faculty member from the department of design. The committee advisors can come from academia or industry but must be approved by the committee chair. The selection of the committee chair will be finalized by the end of the fall semester of the first year. The selection of the committee advisors will be finalized by the end of the spring semester of the first year. The committee is responsible for reviewing and advising the students development of a master’s project and its documentation.</br>
Satisfactory progress towards degree is determined by the following criteria: (1) committee chair must approve final pre-proposal presentation given in DSGN 291 , (2) master’s project committee must approve final proposal presentation given in DSGN 292 , (3) master’s project committee must endorse the outcome of the master’s project as completed in DSGN 298 . Unsatisfactory performance in any of these areas may result in the student being placed on administrative academic probation.</br>

## Master’s Requirements (60 units)

### Core Curriculum (36 units)

- DSGN 200W - Professional Writing in Design 4 unit(s) (GWAR)</br>

- DSGN 201 - Graduate Seminar in Design 4 unit(s) Students complete this course twice.</br>

- DSGN 203 - Contextual Studies 4 unit(s)</br>

- DSGN 291 - Pre-Proposal 4 unit(s)</br>

- DSGN 292 - Proposal 4 unit(s)</br>

- DSGN 293 - Special Study 4 unit(s) Students complete this course three times.</br>


### Animation or Experience Design Specialization (20 units)

#### Animation Specialization Courses

- ANI 240 - Visual Narratives 2 unit(s)</br>

- ANI 250 - Intellectual Property 2 unit(s)</br>

- ANI 255 - Sound Landscapes 2 unit(s)</br>

- ANI 257 - New Technologies Studio 4 unit(s)</br>

- ANI 258 - Interactive Studio 2 unit(s)</br>

- ANI 259 - Post Production Techniques 2 unit(s)</br>

- ANI 260 - The Synthetic Image 2 unit(s)</br>

- ANI 265 - Visual Styles for Animation 2 unit(s)</br>

- ANI 270 - The Synthetic Movement 2 unit(s)</br>


#### Experience Design (XD) Specialization Courses

- DSGN 210 - Graduate Studio: Experience Design 4 unit(s) Students complete this course twice.</br>

- Complete three courses from:</br>

Complete three courses from:</br>

- DSGN 211 - Design Research Methodologies 4 unit(s)</br>

- DSGN 212 - Human Dimensions in Experience Design 4 unit(s)</br>

- DSGN 213 - Designing with Data & Emergent Technology 4 unit(s)</br>

- DSGN 280 - Professional Practices 4 unit(s)</br>


### Culminating Experience (4 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- DSGN 298 - Master’s Project 4 unit(s)</br>


## Total Units Required (60 units)
 </br>