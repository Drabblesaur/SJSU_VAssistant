
# Counseling and Guidance, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (48 units)</br>

- Program Learning Outcomes  </br>

The Counseling and Guidance MA degree program prepares individuals to apply evidence-based counseling principles and practices to support individuals’ academic, educational, vocational/career, and personal and social development. For candidates focused on K-12 school counseling, it also provides preparation in providing comprehensive school counseling services within elementary, middle, and secondary educational institutions. The program includes instruction in sociological and psychological counseling foundations, legal and professional mandates, and transformative and equity-minded social justice practices that lead to the development of justice-oriented multiculturally-skilled counselors. The program also provides students with opportunities to participate in short Faculty-Led Program (FLP) experiences abroad (ex: Costa Rica) to expand their global perspectives and cross-cultural experiences.</br>
Additional information is available on the Department of Counselor Education  website at www.sjsu.edu/counselored/. </br>

## Admissions Requirements
Applicants must submit all application materials, including the department’s supplemental application materials (i.e., Autobiographical and Professional Goals Statement and resume) through the CSU’s Cal State Apply system and meet the university’s minimum admissions requirements to be considered for admissions to the MA program in Counseling and Guidance. See the Graduate Admissions website and this Catalog for general information about Graduate Admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE. For TOEFL Requirements, see the Policies and Procedures  section, English Language Proficiency Requirement .</br>

### Requirements for Admission to Classified Standing
Applicants may be fully admitted if they meet the admissions requirements for the Graduate Division and the department’s requirements. The minimum requirements for the program are a bachelor’s degree from a regionally accredited college or university in any major/discipline with a preferred GPA of 3.0 or higher. Experience serving individuals from diverse backgrounds within K-12, postsecondary education, and/or community settings and a strong commitment to equity, diversity, and social justice is also highly preferred. Candidates who do not meet the 3.0 GPA requirement may still be considered if they demonstrate considerable experience in the education and/or counseling field working with individuals from diverse backgrounds.</br>

- Candidates must meet all university admission requirements .</br>

- Department application materials include the items listed below and should be uploaded directly on the Cal State Apply portal. For more information about the Counselor Education Department’s application materials and process, visit the department’s website.

	
Autobiographical and Professional Goals Statement (three pages typed and double-spaced maximum) that includes the applicant’s: a) educational background, b) experiences that demonstrate concern and capacity to work with individuals from diverse backgrounds in addition to any paid or volunteer work experience directly related to the education and/or counseling fields, c) professional goals related to pursuing the master’s degree with or without a  PPS K-12 School Counseling Credential (include areas of interest in counseling), d) specific interest in being a graduate student in SJSU’s Counselor Education Department, and e) any additional information relevant to pursuing a master’s degree with or without a PPS K-12 School Counseling Credential through SJSU’s Counselor Education Department.
Resume (three pages maximum) that includes degree(s) earned or in progress, employment, volunteer work, research experience, and honors/awards, if any.
Three (3) recommendations from current or former professors who can attest to the applicant’s ability to successfully pursue an advanced academic degree and/or from employers or supervisors who can address the applicant’s experience within the proposed field of study. PPS School Counseling Credential-only applicants are only required to submit two recommendations. The Recommendation Form can be found on the department’s website.

</br>

- Autobiographical and Professional Goals Statement (three pages typed and double-spaced maximum) that includes the applicant’s: a) educational background, b) experiences that demonstrate concern and capacity to work with individuals from diverse backgrounds in addition to any paid or volunteer work experience directly related to the education and/or counseling fields, c) professional goals related to pursuing the master’s degree with or without a  PPS K-12 School Counseling Credential (include areas of interest in counseling), d) specific interest in being a graduate student in SJSU’s Counselor Education Department, and e) any additional information relevant to pursuing a master’s degree with or without a PPS K-12 School Counseling Credential through SJSU’s Counselor Education Department.</br>

- Resume (three pages maximum) that includes degree(s) earned or in progress, employment, volunteer work, research experience, and honors/awards, if any.</br>

- Three (3) recommendations from current or former professors who can attest to the applicant’s ability to successfully pursue an advanced academic degree and/or from employers or supervisors who can address the applicant’s experience within the proposed field of study. PPS School Counseling Credential-only applicants are only required to submit two recommendations. The Recommendation Form can be found on the department’s website.</br>

- Official transcripts from each college/university attended can be sent electronically to etranscript@sjsu.edu or official and sealed copies can be mailed to the SJSU Graduate Admissions office at:


	Graduate Admissions and Program Evaluations
	San José State University
	One Washington Square, SH 404
	San Jose CA 95192-0073</br>

### Admission to Conditionally Classified Standing
Applicants may be conditionally admitted (admitted with conditions) if they meet the admission requirements for the Graduate Division but do not fully meet departmental admissions requirements (e.g., GPA is below 3.0). The admission notification will explain the required terms and conditions for attaining Classified standing.</br>

## Requirements for Advancement to Candidacy
Candidacy denotes that a student is fully qualified to complete the final stages of the Master of Arts degree. General university requirements for advancement to candidacy  are detailed in the Graduate Policies and Procedures  section of this catalog. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>

### Department Requirements

- Complete foundational core courses [EDCO 215 , EDCO 218 , EDCO 232 , and EDCO 244 , (and EDCO 294  for PPS School Counseling Credential candidates)].</br>

- Complete a minimum of 9 units of advanced courses with a “C” or better. These courses can include practicum and fieldwork experience courses.</br>

- Complete the Graduate Writing Assessment Requirement (GWAR) by completing EDCO 215  with a “B” or higher.</br>

- Maintain an overall graduate GPA of 3.0 or higher.</br>

- Meet with your advisor to complete the Petition for Advancement to Graduate Candidacy form (typically completed while enrolled in EDCO 221).</br>


## Requirements for Graduation

### University Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . Completion of the degree also requires a minimum grade of “C” in all courses taken and a minimum overall GPA of 3.0.</br>

### Department Requirements

- Successfully complete “Requirements for Advancement to Candidacy.”</br>

- Complete 6 fieldwork units or 3 practicum and 3 fieldwork units.</br>

- Complete 12 units of advanced elective courses selected in consultation with the student’s department advisor.</br>

- Complete 3 units (EDCO 221 ) to develop a project proposal (Plan B) or a thesis proposal (Plan A).</br>

- Apply for graduation via MySJSU.</br>

- Complete 6 units of advanced courses (EDCO 288  and EDCO 289 ).</br>

- Successfully complete either the project (Plan B, EDCO 298 ) or thesis (Plan A, EDCO 299 ).</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing EDCO 215  with a grade of B or higher.</br>

### Culminating Experience
Students choose a Plan A (Thesis) or Plan B (Project) option as their program culminating experience.</br>
Plan A (Thesis)</br>
Students selecting the Plan A option will write a master’s thesis. The thesis will include original research on a topic approved by the thesis committee and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. Thesis proposals must be approved by the student’s thesis committee, which is typically composed of two department faculty and a third faculty member from outside the department. Students enroll in EDCO 299  (3 units).</br>
Plan B (Project)</br>
Students selecting the Plan B option will complete a master’s degree project or research paper. These students enroll in EDCO 298  (3 units).</br>

## Master’s Requirements (48 units)

### Foundational Core Courses (12 units)
To be completed in the order listed below:</br>

- EDCO 215 - Introduction to Counseling and Guidance 3 unit(s) (GWAR)</br>

- EDCO 218 - Counseling Process & Techniques 3 unit(s)</br>

- EDCO 232 - Law & Ethics in Counseling 3 unit(s)</br>

- EDCO 248 - Dynamics of Behavior and Development 3 unit(s)</br>


### Additional Foundational Courses (15 units)
To be completed in the order listed below:</br>

- EDCO 244 - Cultural Perspectives in Counseling 3 unit(s) or EDCO 280 Multicultural Counseling  </br>

- EDCO 268 - Lifespan Development 3 unit(s)</br>

- EDCO 282 - Assessment for Counselors 3 unit(s)</br>

- EDCO 279 - Advanced Group Process Theory and Practice 3 unit(s)</br>

- EDCO 285 - Trauma Counseling & Crisis Intervention 3 unit(s)</br>


### Research (3 units)

- EDCO 221 - Research in Counselor Education 3 unit(s)</br>


### Advanced Professional Development Courses - Required (9 units)

- EDCO 266 - Education and Career Planning 3 unit(s)</br>

- EDCO 288 - Seminar in Counseling Theory and Practice 3 unit(s) (GWAR)</br>

- EDCO 289 - Seminar in Professional Counseling 3 unit(s)</br>


### Practicum and Fieldwork (6 units)

- EDCO 292 - Supervised Experience in Counseling  (3 units required)</br>

Complete one of the following:</br>

- EDCO 267 - Practicum in Lifespan and Career Development 1-3 unit(s)</br>

- EDCO 292 - Supervised Experience in Counseling 3-6 unit(s)</br>

- EDCO 280 - Multicultural Counseling 3 unit(s)</br>

- EDCO 293 - Practicum in Child and Substance Abuse 3 unit(s)</br>

- EDCO 294 - Practicum in Self-Development 3 unit(s)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (Thesis)

- EDCO 299 - Master’s Thesis 3 unit(s)</br>


#### Plan B (Project)

- EDCO 298 - Special Studies in Counselor Education 3 unit(s)</br>


## Total Units Required (48 units)
Elective courses must be planned in consultation with the student’s department advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy in order to graduate.</br>
Students pursuing the Master of Arts in Counseling and Guidance can choose to complete additional coursework and clinical counseling fieldwork experience to be eligible to pursue the Associate Professional Clinical Counselor (APCC) and Licensed Professional Clinical Counselor (LPCC) licensure through the California Board of Behavioral Sciences (BBS, see: https://www.bbs.ca.gov/applicants/lpcc.html). For more information about this option, students should refer to the LPCC Preparation website for specific requirements.</br>
Note: Students may substitute any course requirement in the major (unless precluded by accreditor or other requirements) with EDCO 290 (Independent Study) by department approval. Email counselor-ed@sjsu.edu for information.</br>
 </br>