
# Applied Data Intelligence, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Applied Data Intelligence, offered by the Department of Applied Data Science , is developed in partnership with industry experts targeting students from diverse academic and professional backgrounds. Students receive the advanced education necessary to apply analytics to solve real-world problems by immersing them in the full data analytics process lifecycle.</br>
Students learn how to build portfolios of data analytics projects by leveraging the interrelationship between domain data knowledge and emerging information technologies. Students advance their knowledge and skills through the integration of: </br>

- 

Identifying domain-specific problems, defining requirements, and establishing measurable organizational objectives. 
</br>
Identifying domain-specific problems, defining requirements, and establishing measurable organizational objectives. </br>

- 

Performing data exploration, preparation, visualization, and governance. 
</br>
Performing data exploration, preparation, visualization, and governance. </br>

- 

Applying programming, statistics, database, data mining, and machine learning technologies to build models for descriptive, diagnostic, predictive, and prescriptive data analytics. 
</br>
Applying programming, statistics, database, data mining, and machine learning technologies to build models for descriptive, diagnostic, predictive, and prescriptive data analytics. </br>

- 

Engaging in the development, validation, and monitoring of data analytics systems to meet requirements and objectives.
</br>
Engaging in the development, validation, and monitoring of data analytics systems to meet requirements and objectives.</br>
Today most organizations treat analytics as a strategic asset, and analytics is central to many functional roles and skills. This program prepares students for a career in data analytics in almost all industry domains. Potential career roles for graduates include data analyst, data administrator, business intelligence analyst, and information research scientist.</br>
The program is offered in both regular and special sessions. For more information, visit the MS Applied Data Intelligence program website. </br>

## Admissions Requirement

### Admission to University
Candidates must apply through the CSU admissions portal, Cal State Apply, and meet all university admission requirements .</br>
In addition to holding a bachelor’s degree, international applicants (or applicants who earned their degrees in a country where the primary language is not English) must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Admission to Program
Applicants must meet all university admissions requirements . An applicant can be admitted in either classified or conditionally classified standing.</br>
An applicant can be admitted to classified standing if the applicant has a bachelor’s degree from an accredited institution with a grade point average of 3.0 or better. In addition, this applicant’s preparation for advanced graduate work in mathematics and computer programming must be considered adequate to meet the course prerequisites and other departmental requirements. </br>

### Admission to Conditionally Classified Standing
An applicant might be conditionally admitted to the program with a marginal deficiency in the above requirements. The admission letter will explain the required coursework, terms, and conditions for removing deficiencies and attaining classified standing.</br>

## Requirements for Advancement to Candidacy
The university requirements for advancement to candidacy  for the master’s degree are outlined in the Graduate Policies and Procedures  section. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , MSADI program course requirements and the links to specialization course requirements are listed at sjsu.edu/applied-data-science/.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS - Applied Data Intelligence Graduation Requirements
The program consists of 30 semester units of 200-level courses with a cumulative GPA of 3.0 or better. The program has developed two specializations: Specialization in Analytics Technologies and Specialization in Data Engineering. These specializations will be offered according to industry trends, student demands, and resource availability. For more information, visit the MS in Applied Data Intelligence program website.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience (Plan A or Plan B)
All students must complete one of the following culminating experience options as part of their 30-unit program requirement.</br>
Plan A (Thesis)</br>
Students opting to complete a master’s thesis will take the DATA 299A  and DATA 299B  as a two-course sequence. The student is responsible for securing the commitment of a full-time tenured or tenure-track faculty member of the Applied Data Science Department who agrees to serve as the thesis committee chair. The student must also secure the commitments of two additional university faculty members, one of whom must be a full-time tenured or tenure-track faculty member of the Applied Data Science Department, to serve as the student’s thesis committee. The student must write a thesis proposal and have it approved by the thesis committee and pass the DATA 299A  course before enrolling in DATA 299B . The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
The graduate project is a research or development effort performed by a team of students on a topic chosen by mutual agreement between an advisor and the team. The choice of project topic must also be approved by the instructor of DATA 298A . DATA 298A  is the first part of the master’s project in which students develop a comprehensive plan and preliminary design of a data analytics project. DATA 298B  is the second part of the master’s project course in which each student completes an in-depth written project to achieve the program outcomes and satisfy the program’s culminating experience requirement.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- DATA 220 - Advanced Mathematical Methods for Data Intelligence 3 unit(s)</br>

- DATA 228 - Big Data Technologies and Applications for Data Intelligence 3 unit(s)</br>

- DATA 230 - Data Intelligence and Visualization 3 unit(s)</br>

- DATA 245 - Machine Learning Technologies 3 unit(s) (GWAR)</br>

- DATA 255 - Deep Learning Technologies 3 unit(s)</br>


### Electives (9 units)
Complete three courses from one specialization:</br>

#### Analytics Technologies

- DATA 225 - Database Systems and Management for Data Intelligence 3 unit(s)</br>

- DATA 240 - Data Mining Techniques and Applications for Data Intelligence 3 unit(s)</br>

- DATA 265 - Large Language Models Applications 3 unit(s)</br>


#### Data Engineering

- DATA 226 - Data Warehousing and Pipeline Development 3 unit(s)</br>

- DATA 236 - Distributed Systems for Data Engineering 3 unit(s)</br>

- DATA 266 - Generative Models Applications 3 unit(s)</br>


### Culminating Experience (6 units)
Complete One Plan:</br>

#### Plan A (Thesis) (6 units)

- DATA 299A - Master of Science in Applied Data Intelligence Thesis I 3 unit(s)</br>

- DATA 299B - Master of Science in Applied Data Intelligence Thesis II 3 unit(s)</br>


#### Plan B (Project) (6 units)

- DATA 298A - Master of Science in Applied Data Intelligence Project I 3 unit(s)</br>

- DATA 298B - Master of Science in Applied Data Intelligence Project II 3 unit(s)</br>


## Total Units Required (30 units)
 </br>