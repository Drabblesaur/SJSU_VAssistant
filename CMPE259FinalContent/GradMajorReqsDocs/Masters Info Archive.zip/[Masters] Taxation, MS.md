
# Taxation, MS
 </br>

- Admissions Requirements</br>

- Program of Study Requirements for the Master of Science in Taxation</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Taxation (MST) Program is a 30-unit program designed to provide individuals with the conceptual understanding and sound technical knowledge necessary to compete successfully in the ever-changing tax world. It is appropriate for individuals already working in public accounting, a corporate tax department, a law practice or government service. College graduates with an accounting degree who wish to pursue a career in taxation and/or meet the 150 unit requirement to become a CPA will also benefit from the program. (State fee schedule does not apply.)</br>
More information can be found on the Lucas Graduate School of Business  Website: sjsu.edu/lucasgsb/prospective-students/mst.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements . Applicants apply separately to the department to obtain admission into the MST program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE.</br>

### Requirements for Admission to Classified Standing

- Completed the following undergraduate courses (or equivalent) prior to admission.

	
BUS1 20 - Financial Accounting  
BUS1 21 - Managerial Accounting  
BUS1 121A - Intermediate Accounting I  
BUS1 121B - Intermediate Accounting II  
BUS1 123A - Taxation of Businesses and Investments  

		These requirements may be fulfilled at any U.S. university or community college. If your undergraduate degree is in Accounting from a U.S. university, you have satisfied the course prerequisites.

</br>

- BUS1 20 - Financial Accounting  </br>

- BUS1 21 - Managerial Accounting  </br>

- BUS1 121A - Intermediate Accounting I  </br>

- BUS1 121B - Intermediate Accounting II  </br>

- BUS1 123A - Taxation of Businesses and Investments  


		These requirements may be fulfilled at any U.S. university or community college. If your undergraduate degree is in Accounting from a U.S. university, you have satisfied the course prerequisites.</br>

- A four-year bachelor’s degree from an accredited college or university in the United States or from a recognized institution if the degree was earned outside of the United States.</br>

- A GPA of 3.0 or better (on a 4.0 scale) in your last 60 semester units or 90 quarter units of course work (Professional Development and Certificate Program course work cannot be included in this calculation).</br>

- Unless one of several GMAT waivers is met (see list below), a Graduate Management Admission Test (GMAT) or the Graduate Record Examination (GRE) exam. Scores at the 50th percentile in both the quantitative and verbal sections of the exam are considered competitive. The GMAT/GRE requirement may be waived if the applicant meets one of the following criteria:

	
SJSU student or alumni.
Accounting degree (or equivalent) from any California State University (CSU) or University of California (UC).
Passed all parts of the CPA exam (in the United States).
Passed the Enrolled Agent exam administered by the IRS.
Scored 145 or higher in the LSAT exam.
Has a GPA of at least 3.2 from an accredited U.S. university AND completed at least three years of full-time work experience in taxation. An interview with the MST Director and/or a letter from the supervisor attesting to type of work responsibilities may be required.
Has a GPA of at least 3.75 from an accredited U.S. university. An interview with the MST Director may be required. 
Earned a Master’s degree or Ph.D. from an accredited institution in the U.S.

</br>

- SJSU student or alumni.</br>

- Accounting degree (or equivalent) from any California State University (CSU) or University of California (UC).</br>

- Passed all parts of the CPA exam (in the United States).</br>

- Passed the Enrolled Agent exam administered by the IRS.</br>

- Scored 145 or higher in the LSAT exam.</br>

- Has a GPA of at least 3.2 from an accredited U.S. university AND completed at least three years of full-time work experience in taxation. An interview with the MST Director and/or a letter from the supervisor attesting to type of work responsibilities may be required.</br>

- Has a GPA of at least 3.75 from an accredited U.S. university. An interview with the MST Director may be required. </br>

- Earned a Master’s degree or Ph.D. from an accredited institution in the U.S.</br>


## Program of Study Requirements for the Master of Science in Taxation

### Core Taxation Courses
Six core taxation courses (18 units) are required of all students. Of the core courses, two must be selected from a list of designated topic areas (business entities and multijurisdictional taxation); see below for details.</br>

### Elective Courses
Students complete a minimum of 12 units of taxation elective courses.</br>

### Graduation Writing Assessment Requirement
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. For the MST Program, the required writing course is BUS 223A .</br>

### Culminating Experience
The culminating experience is a comprehensive individual written project incorporated into the capstone course, BUS 223H - Tax Policy Capstone . An oral examination may be included.</br>

### Maintenance of 3.0 GPA
Students must maintain a grade point average of 3.0 or better on all graduate-level course work. Students who receive grades of “C-“, “D”, “F”, or “U” in any business graduate course must repeat that course to achieve a grade of “C” or better.</br>

### Transfer Credit
Subject to the approval of the MST Program Director, students may transfer a maximum of nine semester units of business graduate course work from another accredited institution to be applied to advanced level course work requirements. Grades in the transfer courses must be “B” or better. MST courses taken via “Open University” are treated as transferred into the MST Program (and thus count toward the maximum of nine semester units of transferable course work).</br>

### Other University Requirements
Students must comply with all other graduate requirements contained in this catalog.</br>

## Requirements for Advancement to Graduate Candidacy
Students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MST degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>

### Special Session Program Information
Academic Programs offered through Special Session are operated by Professional & Global Engagement. Registration and enrollment in a Special Session course or program will follow the special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Professional Education website for more information. </br>

### Program Delivery
The Master of Science in Taxation (MST) Program is offered both on-campus and online. </br>

## Master’s Requirements (30 units)

### Required Core (15 units)

- BUS 223A - Tax Research and Decision Making 3 unit(s) (GWAR)</br>

- BUS 223F - Tax Accounting Methods/Periods 3 unit(s)</br>

- BUS 223G - Taxation of Business Entities 3 unit(s)</br>


#### Business Entities Elective (3 units)
Choose one of the following courses in consultation with graduate advisor:</br>

- BUS 223B - Taxation of Partnerships 3 unit(s)</br>

- BUS 225B - Taxation of Corporate Reorganizations 3 unit(s)</br>

- BUS 225G - Taxation of S Corporations 3 unit(s)</br>

- BUS 225S - Consolidated Returns 3 unit(s)</br>


#### Multijurisdictional Taxation Elective (3 units)
Choose one of the following courses in consultation with graduate advisor:</br>

- BUS 225C - International Tax - US Corporations with Foreign Activities 3 unit(s)</br>

- BUS 225F - State Taxation Fundamentals 3 unit(s)</br>

- BUS 225U - Fundamentals of Transfer Pricing 3 unit(s)</br>

- BUS 225W - Introduction to International Taxation 3 unit(s)</br>


### Electives (12 units)
Complete 12 units from:</br>

- BUS 223B - Taxation of Partnerships 3 unit(s)</br>

- BUS 225A - Taxation of Estates and Trusts 3 unit(s)</br>

- BUS 225B - Taxation of Corporate Reorganizations 3 unit(s)</br>

- BUS 225C - International Tax - US Corporations with Foreign Activities 3 unit(s)</br>

- BUS 225E - Data Analytics and Security 3 unit(s)</br>

- BUS 225F - State Taxation Fundamentals 3 unit(s)</br>

- BUS 225G - Taxation of S Corporations 3 unit(s)</br>

- BUS 225H - Taxation of Property Transactions 3 unit(s)</br>

- BUS 225I - Tax Practices, Penalties and Procedures 3 unit(s)</br>

- BUS 225K - Advanced Individual Taxes 3 unit(s)</br>

- BUS 225L - Accounting for Income Taxes 3 unit(s)</br>

- BUS 225Q - Tax Practicum 3 unit(s)</br>

- BUS 225S - Consolidated Returns 3 unit(s)</br>

- BUS 225U - Fundamentals of Transfer Pricing 3 unit(s)</br>

- BUS 225V - Tax Considerations for High Tech Companies 3 unit(s)</br>

- BUS 225W - Introduction to International Taxation 3 unit(s)</br>

- BUS 227A - Individual Tax Compliance 1 unit(s)</br>

- BUS 227B - Ethics for Tax Practitioners 1 unit(s) (Note:  Course  counts towards the required ethics courses to become a CPA in California)</br>

- BUS 227C - Tax Symposium 1 unit(s) (Note: Topic changes each time offered; may be taken more than once.)</br>

- BUS 227D - Employment Taxation and the Modern Workforce 1 unit(s)</br>

- BUS 227E - Foundation for Understanding Taxation 1 unit(s)</br>

- BUS 280IS - Independent Study 1-6 unit(s)</br>


### Culminating Experience (3 units)

#### Plan B (Project)

- BUS 223H - Tax Policy Capstone 3 unit(s)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the graduate advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>