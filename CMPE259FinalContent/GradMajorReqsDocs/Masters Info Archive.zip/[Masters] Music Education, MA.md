
# Music Education, MA
 </br>

- Special Session Program Information</br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

Advisor: Diana Hollinger</br>
The Master of Arts in Music Education, offered by the School of Music , is designed for the student with a career goal in music education. It provides a broad foundation in educational philosophy, theory, and history in research and practice for a solid grounding for continuing work in K-12 education, community music, and other pursuits, and as preparation for further advanced study. The MA in Music Education is a two-year, 30-unit program focusing on a one-on-one study with an advisor, courses, and practicums in education theory, issues and research in conjunction with seminars in music research and writing, music history, and music theory. The degree culminates with the Written Culminating Exams (WCE), and the completion of a music education thesis (Plan A) or project (Plan B).</br>

## Special Session Program Information
Academic Programs offered through Special Session are operated by the Professional and Continuing Education (PaCE). Registration and enrollment in a Special Session course or program will follow the special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the PaCE website for more information.</br>
Additional information is available in the School of Music Office and at the program website.</br>

## Admissions Requirements
You will need to apply separately to the university to obtain approval for graduate admissions  and to the department to obtain admission into the Master of Arts - Music Education. The School of Music graduate program requires applicants to have a bachelor’s degree in Music from a regionally accredited institution and to be in good academic standing at the last college or university attended. In rare circumstances, students with degrees in non-music areas who demonstrate artistic potential for graduate study in Music may be admitted to the program. The School of Music requires a minimum GPA of 3.00 in the last 60 units of undergraduate coursework. All required transcripts and supporting documents should be sent directly to the university.</br>
Students from a country where the official language was not English are required to submit a TOEFL (Test of English as a Foreign Language), PTE (Pearson Test of English), or International English Language Testing System (IELTS) score. The minimum entrance score for the TOEFL is 96 (iBT, iBT Home & Paper Edition), with a score of 5 in the Writing Section. The minimum score for the PTE is 68; for the IELTS, the minimum score is 7.0. All test scores must be less than 2 years old. Test scores must be sent directly from the Educational Testing Service office (institution code 4687), Pearson Office, or IELTS office directly to SJSU. </br>
Please see “Graduate Program Test Requirements” for more information. The School of Music does not require the GRE (Graduate Record Exam).</br>

### Portfolio and Letters of Recommendation
The submission of a portfolio of work is required including a curriculum vitae, video recording of a teaching episode, statement of teaching philosophy, and a sample undergraduate term paper on an education topic. An interview is also required. Please see the School of Music website for specific portfolio requirements.</br>
The School of Music requires three letters of recommendation addressing the applicant’s potential for graduate-level work in music to be sent to the Music Education area advisor.</br>

### Admission to Classified Standing
Graduate students admitted to the School of Music are usually admitted in “conditionally classified” status. This status is normal for all entering graduate students, who must demonstrate a bachelor’s level competence in music history and music theory by passing the Graduate Entrance Evaluations given during Pre-Instruction before the start of the fall semester. Students who pass their Entrance Evaluations may then become “graduate classified” and are eligible to take all 200-level graduate seminars after completing MUSC 200 . Students who fail portions of the Evaluation will remain conditionally classified and will be required to remediate with the appropriate coursework before taking graduate seminars beyond MUSC 200 . Coursework taken as remediation is not applied to the Master’s degree requirement units.</br>
Students who fail the entire Entrance Evaluation will not be admitted into the program.</br>

## Requirements for Advancement to Candidacy
Candidacy denotes that the student is fully qualified to complete the final stages of the MA. In order to achieve candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies and Procedures  section. Advancement to candidacy requires that the student be in good standing with a 3.0 GPA or better in a minimum of 9 units of letter-graded coursework as a graduate student in 100- or 200-level courses in the degree program as indicated by all courses on the Petition for Advancement to Graduate Candidacy. These courses must conform to university and departmental requirements, and the area and graduate advisors must approve the proposed program. The proposed program must list a total of 30 semester units, including the appropriate number of “core” courses, area of specialization courses, required ensembles, and supervised graduate study.</br>
The student must be “graduate classified” and have met and cleared their conditions for admission to the program indicated by their results in the Graduate Entrance Evaluation in music history and music systems/theory. Candidacy also includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which in the School of Music is MUSC 200 .</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MA - Music Education
Thesis: In Plan A, six units are devoted to the preparation and writing of a thesis guided by the candidate’s major professor and approved by a committee. After final approval by the advisor and thesis committee, the thesis is submitted to Graduate Studies for review. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. The successfully reviewed thesis is then submitted for publication.</br>
Project: In Plan B, six units are devoted to the preparation and production of a written project.</br>
Written Culminating Exams (WCE): At the end of their studies, students demonstrate their thorough grasp of music history, music systems/theory, and their field of specialization through the Written Culminating Exams (WCE). Students must pass all sections of the examination to be awarded their master’s degree</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- MUSC 200 - Methods of Music Research & Writing 3 unit(s) (GWAR)</br>

- MUSC 201 - Seminar in Music History 3 unit(s)</br>

- MUSC 202 - Seminar in Music Systems & Theory 3 unit(s)</br>


#### Complete Two Courses From:

- MUED 221 - Foundations of Music Education 3 unit(s)</br>

- MUED 228 - Research in Music Education 3 unit(s)</br>

- MUED 232 - Directions and Issues in Music Education 3 unit(s)</br>


### Area of Specialization (9 units)

- Nine units of 200-level graduate and approved 100-level elective courses in area of specialization 9 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- Written Culminating Exam 0 unit(s)</br>


#### Choose One Plan From:

- MUSC 299 - Master’s Thesis 1-3 unit(s) (6 units required)</br>

- MUSC 224 - Supervised Graduate Study 1-2 unit(s) (6 units required)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the area coordinator and the School of Music Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>