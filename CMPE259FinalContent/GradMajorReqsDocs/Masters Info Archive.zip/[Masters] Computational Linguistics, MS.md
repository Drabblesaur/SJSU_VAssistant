
# Computational Linguistics, MS
 </br>

- Admission Requirements</br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MS Computational Linguistics program, jointly offered by the Department of Linguistics and Language Development  and the Department of Computer Science , prepares students with advanced knowledge and skills for Computational Linguistics careers. It features a computing-based curriculum and instructs students in the theory and practice of language, linguistics and applied linguistics, and computer science to prepare students for job careers in automated text analysis, machine translation, grammar checking, speech synthesis & recognition, artificial intelligence, machine learning, web search, information retrieval, big data analytics, and more. The program also prepares students for entry into doctoral programs in a wide variety of interdisciplinary fields such as computational linguistics, natural language processing, computer science, artificial intelligence, information research, media studies, and human-computer interaction. Its integrated coursework provides students with strong computing, analytical, and linguistics skills to understand and solve problems for business and research, with strong societal and cultural implications.</br>

## Admission Requirements
Candidates must meet all of the university admission requirements . Students can be admitted in either classified or conditionally classified standing. While the expectation is that (at least at first) most students will enter the MS in Computational Linguistics after finishing the BS Computer Science and Linguistics , some may come from other backgrounds and therefore need prerequisites.</br>
To be admitted to classified standing, applicants must have earned a Bachelor’s degree in linguistics, science, or engineering (e.g., applied math, statistics, computer science, and software engineering) from a regionally accredited institution with a minimum GPA of 3.0 (based on a 4.0 scale), and have completed all program prerequisites listed below. Two to three letters of recommendation are also required. </br>
To enter this program with classified standing, a student must have passed the following prerequisites courses (with the listed required grades in some cases): </br>

- A two-semester series of calculus courses covering integration and partial derivation (e.g. MATH 30  and MATH 31  at SJSU), with a grade of B or better</br>

- A linear algebra course (e.g., MATH 39  at SJSU), with a grade of B or better</br>

- A discrete mathematics course (e.g. MATH 42  at SJSU) with a grade of B or better</br>

- A statistics and probability theory course (e.g. MATH 161A  at SJSU) </br>

- A course on Python programming (e.g. CS 22A  at SJSU)</br>

- A course on object-oriented programming (e.g. CS 46A  at SJSU)</br>

- An introductory data structures course (e.g. CS 46B  at SJSU)</br>

- An introductory linguistics course (e.g. LING 101  at SJSU)</br>

- A Natural Language Processing or computational linguistics course (e.g. LING 165  at SJSU)</br>

Applicants from countries in which the native language is not English must submit TOEFL scores. Minimum TOEFL scores acceptable for admission are 600 (paper-based), 250 (computer-based), or 100 (internet-based).</br>

## Advancement to Candidacy
The student must obtain a grade of B or better in each of LING 220  and LING 221 , complete at least 15 units towards the degree with at least a 3.0 GPA, and meet all other university requirements, including the Graduation Writing Assessment Requirement (GWAR), before being advanced to candidacy. </br>
Students must maintain an overall grade point average (GPA) of 3.0 at all times, otherwise they will be placed on academic notice and required to raise the overall GPA above the 3.0 minimum during the subsequent semester (failing to do so will result in disqualification from the program). </br>

## Graduation Requirements

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .This requirement is satisfied by taking CS 200W  or LLD 250W  in the MS Computational Linguistics program.</br>

### Culminating Experience
MS Computational Linguistics students must complete one of the following two options: </br>

- Plan A (thesis): LING 298  and LING 299  OR CS 297  and CS 299  </br>

- Plan B (project): LING 298  and LING 298P  OR CS 297  and CS 298  </br>

Both plans require two semesters of enrollment in 6-unit coursework. The student is responsible for securing the commitment of a full-time tenured or tenure-track (T/TT) faculty member in either Department of Linguistics and Language Development or Department of Computer Science who agrees to serve as their primary advisor, whose home department determines whether the student takes the LING or CS courses for the culminating experience. The student must also secure the commitments of two additional members, one of whom must also be a T/TT faculty member in LLD or CS. Either plan requires writing a manuscript in a formal format describing original computational linguistics research, which is submitted for review by the student’s committee.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- LING 220 - Computational Linguistics I 3 unit(s)</br>

- LING 221 - Computational Linguistics II 3 unit(s)</br>

- LING 230 - Seminar in Linguistics 3 unit(s) (6 units required)</br>

- or LING 230  and CS 273 Topics in Natural Language Processing  </br>

or LING 230  and CS 273 Topics in Natural Language Processing  </br>

#### Graduation Writing Assessment Requirement
Complete one course:</br>

- CS 200W - Graduate Technical Writing 3 unit(s) (GWAR)</br>

- LLD 250W - Becoming a Professional in Linguistics/TESOL 3 unit(s) (GWAR)</br>


### Electives (9 units)
Complete three courses with consultation and approval from the program coordinator:</br>

- CS 146 - Data Structures and Algorithms 3 unit(s)</br>

- CS 153 - Concepts of Compiler Design 3 unit(s)</br>

- CS 154 - Formal Languages and Computability 3 unit(s)</br>

- CS 156 - Introduction to Artificial Intelligence 3 unit(s)</br>

- CS 171 - Introduction to Machine Learning 3 unit(s)</br>

- CS 256 - Topics in Artificial Intelligence 3 unit(s)</br>

- CS 271 - Topics in Machine Learning 3 unit(s)</br>

- CS 272 - Reinforcement Learning and Sequential Decision Making 3 unit(s)</br>

- CS 274 - Topics in Web Intelligence 3 unit(s)</br>

- LING 111 - Introduction to Linguistic Phonetics 3 unit(s)</br>

- LING 112 - Introduction to Syntax 3 unit(s)</br>

- LING 113 - Introduction to Phonology 3 unit(s)</br>

- LING 114 - Introduction to Semantics and Discourse 3 unit(s)</br>

- LING 125 - Introduction to Historical and Comparative Linguistics 3 unit(s)</br>

- LING 161 - Psycholinguistics 3 unit(s)</br>

- LING 162 - Introduction to Morphology 3 unit(s)</br>

- LING 166 - Sociolinguistics 3 unit(s)</br>

- LING 167 - Multilingualism and Language Contact 3 unit(s)</br>

- LING 201 - Phonology: Theory and Applications 3 unit(s)</br>

- LING 202A - Syntactic Theory 3 unit(s)</br>

- LING 203 - Semantic Structures 3 unit(s)</br>

- LING 213 - Linguistic Field Methods 3 unit(s)</br>

- MATH 161A - Applied Probability and Statistics I 3 unit(s)</br>

- MATH 161B - Applied Probability and Statistics II 3 unit(s)</br>

- MATH 163 - Probability Theory 3 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one option (Plan A or Plan B). Complete one of the following 4 options. Students should enroll in project/thesis courses matching the home department of their research advisor.</br>

#### Plan A (Thesis)

- LING 298 - Individual Study  1-4 unit(s)</br>

- LING 299 - Master’s Thesis  1-6 unit(s)</br>

- CS 297 - Preparation for Writing Project or Thesis  3 unit(s)</br>

- CS 299 - Master’s Thesis  3 unit(s)</br>


#### Plan B (Project)

- LING 298 - Individual Study  1-4 unit(s)</br>

- LING 298P - Master’s Project  1-6 unit(s)</br>

- CS 297 - Preparation for Writing Project or Thesis  3 unit(s)</br>

- CS 298 - Master’s Writing Project  3 unit(s)</br>


## Total Units Required (30 units)
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>