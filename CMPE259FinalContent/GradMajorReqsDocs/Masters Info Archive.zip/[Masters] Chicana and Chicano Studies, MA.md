
# Chicana and Chicano Studies, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The CCS Graduate program at SJSU trains students to become leaders in a number of professional fields, including: teaching, social services, government ad policy, health care, and community service. We also prepare students for doctoral study in Chicana/o Studies, Ethnic Studies, and other academic fields.</br>
The MA degree offers three areas of expertise: Education, Policy, and Comparative Ethnic Studies.</br>

### MA - Chicana and Chicano Studies, Specialization in Comparative Ethnic Studies
The Comparative Ethnic Studies specialization is designed to prepare students for doctoral study in Chicana/o Studies, Ethnic Studies, and other academic fields. In addition to courses in Chicana and Chicano Studies, students may take courses from other areas of Ethnic Studies, such as African American Studies and Asian American Studies, so as to develop strengths in several areas of Ethnic Studies.</br>

### MA - Chicana and Chicano Studies, Specialization in Education
The Education specialization is intended to prepare students for effective work in a number of fields requiring expertise in issues relevant to Chicanx and Latinx education. Among the most critical areas within this emphasis are the analysis of the K-12 educational system and the development of methods for training competent professionals to work with these communities.</br>

### MA - Chicana and Chicano Studies, Specialization in Policy Studies
The Policy Studies specialization is designed to provide students with a strong background in policy analysis and development as they relate to the Chicanx and Latinx community. The intent of this specialization is to prepare students to apply a Chicanx and Latinx perspective to the development and implementation of contemporary policies that address the needs of this and other communities.</br>
Information about the program and important dates can be obtained at the Department of Chicana and Chicano Studies website.</br>

## Admissions Requirements
Candidates must meet all the university admission requirements . In addition to the regular application for admission to the university, each applicant must submit directly to the graduate advisor of the Chicana and Chicano Studies MA Program two letters of recommendation (faculty letters are preferred), a statement of purpose, and a writing sample (6 to 10 pages). Those students who do not meet the standards for classified status may be admitted with specific conditions as conditionally classified; the conditions must be fulfilled before the student will be advanced to candidacy for the master’s degree in Chicana and Chicano Studies. If the conditions are not fulfilled, the program reserves the right to dismiss the student from the program by notifying the Associate Dean of Graduate Studies.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

## Requirements for Advancement to Graduate Candidacy
Students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies & Procedures  section. Candidacy includes the successful completion of the  Graduation Writing Assessment Requirement (GWAR) . Students pursuing the Plan A (Thesis) option must meet additional departmental requirements for candidacy by securing the commitment of three faculty members of the university, two of whom must be members of the program permanent faculty, to serve as members of the student’s Plan A (Thesis) committee, with one permanent faculty member agreeing to serve as chair. The committee must approve the student’s thesis proposal no later than one month prior to the end of the semester preceding the one in which enrollment in the final thesis course (CCS 299 ) is planned.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Department Graduation Requirements
At an appropriate time, and with the assistance of the graduate advisor, students will select a specialization and a culminating experience (Plan A or Plan B Project) as outlined below:</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan A (Thesis)</br>
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. The candidate for the MA - Chicana and Chicano Studies degree must successfully pass a final oral defense of the thesis. This requirement is fulfilled by enrolling in CCS 299  for up to 6 units. CCS 297 , special studies, is an optional pathway for thesis students to satisfy units toward their degree completion and preparation for their theses (CCS 299 ). The course fits in the CCS 299  thesis sequencing, providing an option for thesis students prior to taking CCS 299  for thesis completion.</br>
Plan B (Project)</br>
Students are expected to develop a project describing research results and offer critical analyses (interpretations.) Students should work with their project advisor and CCS graduate studies advisor on the course of study, research culmination, and to follow appropriate formatting guidelines. It is advised that students take CCS 240  prior to CCS 298 , or enroll in CCS 240  with their first CCS 298 . 
CCS 298  can be taken up to 6 units.</br>

## Master’s Requirements (30 units)

### Core Courses (18 units)

- CCS 200 - Ideology and the Chicana/o Experience 3 unit(s) (GWAR)</br>

- CCS 205 - Chicana/o History 3 unit(s)</br>

- CCS 210 - Foundations in Chicana/o Studies 3 unit(s)</br>

- CCS 225 - The Impact of American Institutions on the Chicana/o Community 3 unit(s)</br>

- CCS 240 - Applied Chicana/o Studies Seminar 3 unit(s)</br>

- CCS 275 - Research Methods 3 unit(s)</br>


### Area of Specialization (12 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Area of Specialization</br>

#### Specialization in Comparative Ethnic Studies
Complete One Option (Plan A and Plan B Project)</br>

- CCS 252 - Comparative Ethnic Studies 3 unit(s)</br>

- CCS 297 - Special Studies 1-5 unit(s)</br>

- CCS 299 - Master’s Thesis 1-6 unit(s)</br>

- CCS 215 - Chicanas/os and Education 3 unit(s)</br>

- CCS 230 - Policy Analysis and the Chicana/o Community 3 unit(s)</br>

- CCS 215 - Chicanas/os and Education 3 unit(s)</br>

- CCS 230 - Policy Analysis and the Chicana/o Community 3 unit(s)</br>

- CCS 252 - Comparative Ethnic Studies 3 unit(s)</br>

- CCS 298 - Project 1-6 unit(s)</br>


#### Specialization in Education
Complete One Option (Plan A and Plan B Project)</br>

- CCS 215 - Chicanas/os and Education 3 unit(s)</br>

- CCS 297 - Special Studies 1-5 unit(s)</br>

- CCS 299 - Master’s Thesis 1-6 unit(s)</br>

- CCS 230 - Policy Analysis and the Chicana/o Community 3 unit(s)</br>

- CCS 252 - Comparative Ethnic Studies 3 unit(s)</br>

- CCS 215 - Chicanas/os and Education 3 unit(s)</br>

- CCS 230 - Policy Analysis and the Chicana/o Community 3 unit(s)</br>

- CCS 252 - Comparative Ethnic Studies 3 unit(s)</br>

- CCS 298 - Project 1-6 unit(s)</br>


#### Specialization in Policy Studies
Complete One Option (Plan A and Plan B Project)</br>

- CCS 230 - Policy Analysis and the Chicana/o Community 3 unit(s)</br>

- CCS 297 - Special Studies 1-5 unit(s)</br>

- CCS 299 - Master’s Thesis 1-6 unit(s)</br>

- CCS 215 - Chicanas/os and Education 3 unit(s)</br>

- CCS 252 - Comparative Ethnic Studies 3 unit(s)</br>

- CCS 215 - Chicanas/os and Education 3 unit(s)</br>

- CCS 230 - Policy Analysis and the Chicana/o Community 3 unit(s)</br>

- CCS 252 - Comparative Ethnic Studies 3 unit(s)</br>

- CCS 298 - Project 1-6 unit(s)</br>


## Total Units Required (30 units)
Pathway courses must be planned in consultation with the Graduate Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>