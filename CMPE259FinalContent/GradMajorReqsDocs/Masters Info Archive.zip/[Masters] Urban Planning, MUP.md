
# Urban Planning, MUP
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (48 units)</br>

- Program Learning Outcomes  </br>

The Master in Urban Planning (MUP) program trains skilled professionals who graduate with a strong education in general planning practice and theory as well as specialized training in planning subfields. The program allows students to develop professional skills in an area of specialization such as Affordable Housing and Community Development Finance, Applications of Technology in Planning, Community Design and Development, Environmental Planning, Real Estate Development, or Transportation and Land Use Planning.</br>
Graduates leave the program prepared with practical skills and theoretical knowledge that they can employ in jobs working to improve the quality of life and economic opportunity for all residents of urban regions as well as improving the quality of the natural environment.</br>
A special mission of the program is to provide planning education opportunities for a diverse student population, including working students who prefer to attend the program on a part-time basis.</br>
The MUP is an accredited professional degree program nationally recognized by the Planning Accreditation Board.</br>
Information about the program and important dates can be obtained at the School of Planning, Policy and Environmental Studies  website.</br>

## Admissions Requirements
Candidates must meet all the university admission requirements . To complete your application, you must submit materials through Cal State Apply. Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>
Materials to be submitted through Cal State Apply:</br>

- Fill out the online application form in Cal State Apply. The Master of Urban Planning (MUP) program at SJSU is listed on the online application form under Urban Planning.</br>

- Domestic Students - Submit one set of official transcripts from all higher educational institutions attended (even those where you did not get a degree) to the Graduate Admissions  & Program Evaluation (GAPE) Office. Do not send transcripts to the Department of Urban & Regional Planning.</br>

- International Students - International students are advised to closely follow guidelines for submitting transcripts and any other supporting documents, including demonstrating competence in English, available on the Graduate Program Test Requirement webpage.</br>

- A Statement of Purpose (approximately 1.5 single-spaced typed pages) that indicates how a graduate degree will help you to achieve your career objectives and what motivates you to pursue graduate education in urban planning or geography. This can be the same statement as included in your online application.  This statement should indicate which semester you are applying for and your current contact information, including mailing address, phone number, and e-mail address. If you have previously applied to the program and are re-applying, please indicate for which semester you previously applied. A well-written, clearly structured, spell-checked, grammar-checked and carefully proofread Statement of Purpose will make a favorable impression on our Admissions Committee members who read them very carefully. As well, please submit your CV/résumé with your statement.</br>

- Two original signed letters of recommendation from university instructors who taught you or supervisors who managed you in paid or volunteer work. It is highly recommended that at least one letter come from a university instructor. If this is not possible, ask your letter writers to include an evaluation of your writing and analysis skills.</br>


## Requirements for Advancement to Candidacy
Students must complete all university requirements for advancement to candidacy  for the master’s degree as outlined in the Graduate Policies and Procedures  in this catalog. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) . </br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . </br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
URBP 298A  and URBP 298B  are graded on a Credit/No credit (CR/NC) basis. Receiving an NC in URBP 298A or URBP 298B has the following implications:</br>

- An “NC” is the equivalent of failing the class. The “NC” will remain permanently on the student’s record, although the student’s GPA is not affected by the “NC.”</br>

- Students who receive an “NC” in URBP 298A or URBP 298B can enroll again in the class only if there is space available, with the department giving enrollment priority to students who meet the prerequisites and have not previously taken the class.</br>

- Students who receive an “NC” in URBP 298A or URBP 298B will be placed on administrative-academic probation. To return to good standing, a student must re-enroll in the class and receive a grade of “CR.”</br>

- Students who receive a second “NC” in URBP 298A or URBP 298B will be disqualified from the MUP program.</br>


## Master’s Requirements (48 units)

### Core Courses (25 units)

- URBP 200 - Seminar on Urban and Regional Planning 4 unit(s) (GWAR)</br>

- URBP 204 - Quantitative Methods 4 unit(s)</br>

- URBP 225 - Land Use Planning and Law 4 unit(s)</br>

- URBP 236 - Urban and Regional Planning Policy Analysis: Tools and Methods 4 unit(s) (GWAR)</br>

- URBP 241 - Planning Sustainable Cities 2 unit(s)</br>

- URBP 275G - Geographic Information Systems Overview: Urban Planning Applications 1 unit(s)</br>

- URBP 295 - Capstone Studio: Community Planning 6 unit(s)</br>


### Electives (17 units)
Seventeen units of coursework chosen from Urban and Regional Planning courses. Students are strongly encouraged to take at least 12 units from within a single MUP specialization. Electives from outside the Urban & Regional Planning Department (either upper-division undergraduate or graduate courses) may be taken, but must first be approved by the Graduate Advisor.</br>

- URBP 103 - Local Government and Politics 4 unit(s)</br>

- URBP 125 - Urban Anthropology 3 unit(s)</br>

- URBP 145 - Race, Policy, and Urban Cities 4 unit(s)</br>

- URBP 163 - Twentieth Century Urban Design 3 unit(s)</br>

- URBP 185 - Environmental Impact Analysis 4 unit(s)</br>

- URBP 190 - Advanced Environmental Impact Assessment 4 unit(s)</br>

- URBP 205 - Private Development and Urban Planning 3 unit(s)</br>

- URBP 206 - Market Analysis, Appraisal, & Finance of Real Estate Development 3 unit(s)</br>

- URBP 208 - Urban Real Estate Development Studio 3 unit(s)</br>

- URBP 223 - Housing Economics and Policy 4 unit(s)</br>

- URBP 226 - Regional Transportation Planning 4 unit(s)</br>

- URBP 231 - Urban Design in Planning 4 unit(s)</br>

- URBP 232 - Urban Design Studio 4 unit(s)</br>

- URBP 233 - Social Issues in Planning 4 unit(s)</br>

- URBP 240 - Environmental Planning 4 unit(s)</br>

- URBP 248 - Spatial Visualization Tech in Urb Plan 1-4 unit(s)</br>

- URBP 250 - Urban Planning Public Finance 4 unit(s)</br>

- URBP 255 - Urban and Regional Growth Management 4 unit(s)</br>

- URBP 256 - Sustainable Transportation Planning 4 unit(s)</br>

- URBP 260 - Environmental Planning Topics 4 unit(s)</br>

- URBP 278 - Introduction to GIS for Urban Planning 4 unit(s)</br>

- URBP 279 - Advanced GIS for Urban Planning 4 unit(s)</br>

- URBP 280 - Planning Research Topics 1-4 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- URBP 298A - Special Study: Planning Report 3 unit(s)</br>

- URBP 298B - Special Study: Planning Report Completion 3 unit(s)</br>


## Total Units Required (48 units)
All electives must be 100-level or 200-level courses as arranged and approved in conference with the Graduate Advisor advisor. Electives to be taken will depend on the student’s background and interests.</br>
Students must earn a “B” or better grade in 100-level classes in order for the department to give credit for those classes towards the MUP degree.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>