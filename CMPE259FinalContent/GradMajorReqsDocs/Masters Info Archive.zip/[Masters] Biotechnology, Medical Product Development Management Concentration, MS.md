
# Biotechnology, Medical Product Development Management Concentration, MS
 </br>

- Admission Requirements </br>

- Advancement to Candidacy</br>

- Master’s Preparation</br>

- Master’s Requirements (36 units)</br>

- Program Learning Outcomes (Graduate)  </br>

The MS in Biotechnology program, offered by the Department of Biological Sciences , integrates advanced, hands-on training in biotechnology and medical product development management courses with MBA-level business courses from the College of Business. The core courses provide an introduction to aspects of the biotechnology and medical product industry including drug and medical device development, marketing, finance, and intellectual property. The required internship experience allows the students to apply what they have learned in real-world settings.</br>
Through elective choices, students supplement the core program with additional hands-on science or MBA courses in support of their career goals. MS in Biotechnology program graduates are highly trained individuals who have had direct exposure to the biotechnology and medical device real world and are ready to make immediate contributions to the biotechnology/ medical device, nonprofit, or government organizations. Graduates work in a variety of positions in research, product development, marketing, regulatory affairs, clinical affairs, project management, quality, and others.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system at calstate.edu/apply and meet all the university admission requirements. Applicants must submit additional supporting documents including a resume separately to the department to obtain admission into the Master in Biotechnology degree program. See the graduate admissions requirements website and this Catalog for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Admission to the Program
Applicants must submit an official transcript (for international WES evaluated transcript), English-language proficiency test (if applicable), statement of purpose, resume, GRE or waiver, and 2 letters of recommendation to the university. Potential candidates will be interviewed during the spring semester. Admission is based on the acceptance to the university and the outcome of the interview.</br>

## Requirements for Advancement to Candidacy
All students will submit their Advancement to Candidacy petitions during the fall of their second year, after having fulfilled all University requirements for advancement to candidacy, as detailed in the Graduate Policies and Procedures section. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR), which is satisfied in this degree by the completion of BIOL 202TA and BIOL 202TB with grades of “B” or higher.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements section of the Graduate Policies and Procedures.</br>

### Graduation Requirements
The Master of Science in Biotechnology program consists of 36 semester units of approved work. It includes a 2-unit internship in the biotechnology industry.</br>
Special Session Program Information</br>
Academic Programs offered through Special Session are operated by Professional and Continuing Education (PaCE). Registration and enrollment in a Special Session course or program must use the special session application form and will follow the special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Biotechnology website for more information.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR).</br>
This requirement is satisfied by passing SMPD 281A .</br>

### Culminating Experience
Plan B (Project)</br>
The culminating experience is the Biotechnology Colloquium (BIOL 285T  , which includes the preparation of a business plan for a biotechnology startup company.</br>

## Master’s Requirements (36 units)

### Major Core Courses (18 units)

- BIOL 202TB - Biotech Seminar: Drug Development Process 3 unit(s)</br>

- BIOL 221T - Advanced Bioinformatics 4 unit(s)</br>

- BUS 282A - Essentials of Management and Organizational Behavior 3 unit(s)</br>

- BIOL 280T - Internship in the Biotechnology and Medical Product Industry 2 unit(s)</br>

- BUS 282B - Essentials of Operations Management 3 unit(s)</br>

- BIOL 282C - Biotechnology and Medical Product Company Management 3 unit(s)</br>


### Major Elective Courses (6 units)
 Students must take any 2 of the following 200-level science and/or business courses.</br>

#### Science Electives

- BIOL 281T - Individual Studies in Biotechnology/ Medical Product Development  3 unit(s)</br>

- SMPD 283A - Regulatory Affairs I for Pharmaceuticals and Biologics  3 unit(s)</br>


#### Business Electives
200-level MBA for Professional course chosen in consultation with the Program Director.</br>

### Concentration Required Courses (11 units)

- SMPD 281A - Clinical Development Seminar I 3 unit(s) (GWAR)</br>

- SMPD 281B - Clinical Development Seminar II 3 unit(s)</br>

- SMPD 289A - Special Topics in Clinical Trials Management I 2 unit(s)</br>

- SMPD 283B - Regulatory Affairs II for Medical Devices 3 unit(s)</br>


### Culminating Experience (1 unit)

- BIOL 285T - Colloquium in Biotechnology/ Medical Product Development 1 unit(s)</br>


## Total Units Required (36 units)
 </br>