
# Software Engineering, MS
 </br>

- Educational Objectives of the Graduate Program</br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

The MSSE program, offered by the Department of Computer Engineering , provides students with an educational experience that builds on traditional computer science and engineering and takes an integrative approach to software engineering. The program integrates the forces shaping software development, including emerging technologies, with the understanding of rapidly changing technologies and architectures and their influence on software engineering processes, where large-scale design is pre-eminent, service and component integration is the standard mode of development, and there is increased globalization of the software development workforce.</br>
The program offers specializations in Enterprise Software Technologies, Cloud Computing and Virtualization, Software Systems Engineering, Data Science, Cybersecurity and Networking Software.</br>
Class schedules are designed for the convenience of employed engineers who wish to pursue graduate work on a part-time basis.</br>
The MSSE Program welcomes students with undergraduate degrees in other engineering or science disciplines that have strong programming skills.</br>
Program Website: https://www.sjsu.edu/cmpe/academic/ms-software-engineering/​.</br>

## Educational Objectives of the Graduate Program
To provide MSSE graduates with the ability to:</br>

- Acquire advanced knowledge of the practice of software engineering, from vision to analysis, design, validation, and deployment.</br>

- Tackle complex engineering problems and tasks, using contemporary engineering principles, methodologies, and tools.</br>

- Demonstrate leadership and the ability to participate in teamwork in an environment with different disciplines of engineering, science, and business.</br>

- Understand the ethical, economic, and environmental implications of their work, as appropriate.</br>

- Advance successfully in the engineering profession and sustain a process of life-long learning in engineering or other professional areas.</br>

- Communicate effectively in both oral and written forms.</br>


## Admissions Requirements
Candidates must meet all university admissions requirements . Applicants can be admitted in either classified or conditionally classified standing. If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the conditions will include taking preparatory courses to meet these requirements. Such courses will not count as part of the master’s degree program requirements.</br>
Applicants may be considered for admission with conditionally classified standing if they have a BS degree in any engineering or science discipline from an accredited institution. Students with conditionally classified standing will take a series of core programming courses based on their evaluation by the MSSE Graduate Advisor.</br>
For admission with classified standing, an applicant must possess a BSSE or BSCS degree from an accredited institution with a grade point average of 3.0 or better.</br>
The admission letter will explain required coursework, terms and conditions for removing deficiencies and attaining classified standing.</br>
GRE scores must be submitted if an applicant’s bachelor’s degree is not from an ABET-accredited U.S. university degree program. Under some circumstances, a waiver of the GRE test requirement will be granted. Descriptions of the minimum GRE scores acceptable for admission and the conditions for a waiver are listed on the admissions requirements  webpage. In addition, applicants who do not possess a degree from a U.S. university must achieve a minimum English-language proficiency test score as indicated on the GAPE website.</br>

## Requirements for Advancement to Graduate Candidacy
Students may advance to candidacy  after completing all prerequisites assigned during admissions, the degree core courses, specialization courses, and the Graduation Writing Assessment Requirement (GWAR) . MSSE program course requirements and the links to specialization course requirements are listed at www.sjsu.edu/msse.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS - Software Engineering Graduation Requirements
The Computer Engineering Department offers courses designed to provide a flexible curriculum structure that allows students to follow a course of study to meet their individual career goals. As shown below, the program consists of 33 semester units of 200-level courses with a cumulative GPA of 3.0 or better. At least 27 units must be 200-level software engineering courses, and undergraduate coursework will not count towards the master’s degree unless approved by the MSSE Graduate Advisor. A detailed description of elective class requirements can be found at www.sjsu.edu/msse. Students may further their degree by adding internships (CMPE 298I ) to their plan of study.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing CMPE 294  or ENGR 200W  or CMPE 295W .</br>

### Culminating Experience (Plan A or Plan B)
All students must complete one of the following culminating experiences: thesis or project. Theses and projects are completed under the supervision of an advisor.</br>
Plan A (Thesis)</br>
A master’s thesis includes original research on a topic approved by the thesis committee and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It undergoes a thorough review and revision process under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
A master’s project is a research or development effort performed by a student individually on a topic chosen by mutual agreement between an advisor and the student. The choice of project topic is also approved by the Graduate Advisor. The individual student projects could be distinct components of a larger integrated project performed by a team of students. At the end of CMPE 295B , a project report is submitted for department review, and students present their project work in a department project exposition.</br>

## Master’s Requirements (33 units)

### Common Core (12 units)

- CMPE 202 - Software Systems Engineering 3 unit(s)</br>

- CMPE 255 - Data Mining 3 unit(s)</br>

- CMPE 272 - Enterprise Software Platforms 3 unit(s)</br>


#### GWAR (3 units)

- CMPE 294 - Computer Engineering Seminar 3 unit(s) (GWAR)</br>

- CMPE 295W - Master’s Project 3 unit(s) (GWAR)</br>

- ENGR 200W - Engineering Reports and Graduate Research 3 unit(s) (GWAR)</br>


### Area of Specialization (6 units)
Complete two courses from one of the specializations:</br>

#### Enterprise Software Technologies

- CMPE 273 - Enterprise Distributed Systems 3 unit(s)</br>

- CMPE 275 - Enterprise Application Development 3 unit(s)</br>


#### Cloud Computing and Virtualization

- CMPE 281 - Intelligent Cloud Platform 3 unit(s)</br>

- CMPE 283 - Virtualization Technologies 3 unit(s)</br>


#### Software Systems Engineering

- CMPE 285 - Software Engineering Processes 3 unit(s)</br>

- CMPE 287 - Intelligent System Quality Validation 3 unit(s)</br>


#### Networking Software

- CMPE 206 - Computer Network Design 3 unit(s)</br>

- CMPE 207 - Network Programming and Application 3 unit(s)</br>


#### Data Science

- CMPE 257 - Machine Learning 3 unit(s)</br>

- CMPE 258 - Deep Learning 3 unit(s)</br>


#### Cybersecurity

- CMPE 209 - Network Security and Applications 3 unit(s)</br>

- CMPE 279 - Software Security Technologies 3 unit(s)</br>


### Approved Electives (9 units)
Elective classes can be any 200-level CMPE course except 295 or 299 culminating experience classes, 298, or 298i. Also permitted are 100-level or 200-level courses from Engineering or Science disciplines selected in consultation with the MSSE Graduate Advisor. One elective must be a specialization core class from a specialization other than the student’s declared specialization.</br>

### Culminating Experience (6 units)
Complete one option (Plan A or Plan B). If Plan A is selected, program departments are required to certify when the Thesis has been completed satisfactorily via the Verification of Culminating Experience form.</br>

#### Plan A (Thesis)

- CMPE 299A - Master Thesis I 3 unit(s)</br>

- CMPE 299B - Master Thesis II 3 unit(s)</br>


#### Plan B (Project)

- CMPE 295A - Master Project I 3 unit(s)</br>

- or</br>

or</br>

- CMPE 295W - Master’s Project 3 unit(s) ; and,</br>

-  </br>

 </br>

- CMPE 295B - Master Project II 3 unit(s)</br>


## Total Units Required (33 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>