
# Public Administration, MPA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (36 units)</br>

- Program Learning Outcomes  </br>

The program leads to the professional degree of Master of Public Administration (MPA). It provides pre-service students with the knowledge and skills necessary for effective administration of local, state, and federal government agencies and of nonprofit organizations. It also offers mid-career administrators and professionals in public service an opportunity to improve their management skills and qualifications. For the convenience of students who are employed full-time, all courses are offered in the evening. Alumni assist with orientation and mentoring activities.</br>
The MPA program, offered by the School of Planning, Policy and Environmental Studies , provides each student with a basic understanding of the environment of public policy and the ability to deal with:</br>

- Political and legal institutions and processes</br>

- Economic and social institutions and processes</br>

- Organization and management concepts, and human resource administration</br>

- Concepts and techniques of budgeting and financial administration</br>

- Application of quantitative and qualitative techniques of analysis in policy and program formulation, implementation and evaluation, and decision making and problem-solving</br>

Students also develop the ability to:</br>

- Define and diagnose public problems, engage in supported decision-making, collect relevant data including big data, perform logical analyses, develop alternatives, implement an effective and ethical course of action, and evaluate results.</br>

- Organize and communicate information clearly to a variety of audiences through formats including oral presentations, written memoranda and technical reports, and statistical charts, graphs, and tables.</br>

- Recognize and value diversity and diverse viewpoints within the community, and integrate diverse views and perspectives into community problem solutions.</br>

- Apply information technology to public administration problems, including community service provision and cybersecurity of systems.</br>

For more information on the program please go to the MPA program’s website.</br>

## Admissions Requirements
The MPA program accepts students in unclassified and classified standing. People in unclassified standing must meet all admissions requirements, but may be lacking one or more of the prerequisites for the program. These prerequisites must be completed before registering for the fifth MPA course. People admitted in classified standing have met all requirements for admission to the program.</br>
Minimum requirements for admission  to the Graduate Division are outlined in the catalog.</br>
The MPA does not use the GRE, as it is not a good predictor of performance especially for people who have been in the professional workforce for several years. The MPA program is primarily designed for working professionals, although well-qualified recent graduates may be admitted.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For the MPA a minimum score of 575 is required.</br>

### Preparation
A bachelor’s degree or its equivalent, from an accredited college or university is required. No specific undergraduate major is necessary. Preparation must include introductory courses in American government, micro-economics and statistics from an accredited community college or university, and competency in spreadsheet use. These are known as prerequisites, requirements to be met before beginning the MPA program. Deficiencies in preparation must be removed before advancement to candidacy and before completion of four MPA courses. Transcripts for the baccalaureate, including from all colleges where prerequisites were taken, must be sent directly to Graduate Admissions & Program Evaluation (GAPE) upon applying to the program, not to the department. Transcripts for the missing prerequisites submitted after admission must go to the MPA Director directly.</br>

### Grade Point Average (GPA) Requirements
Applicants applying directly after graduating from an undergraduate school need an overall grade point average of 3.0 in all courses, or in the last 60 units as an undergraduate, or in the major. Applicants applying three or more years after completing the BA degree need a grade point average of 2.75 overall, or in the last 60 units of undergraduate courses, or in the major. These are minimum qualifications for consideration, and may not result in admission. In addition, applicants should submit evidence of professional development, such as promotions noted on a resume or in letters of recommendation.</br>

## Requirements for Advancement to Graduate Candidacy
Students must apply for advancement to candidacy as early as possible, but no later than the last semester of their graduate program. University requirements for advancement to candidacy  for the master’s degree are outlined in the Graduate Policies and Procedures  section of this catalog.</br>
Final date for submission in each semester may be found at the GAPE Deadlines webpage. In addition to meeting the university requirements for advancement to candidacy, applicants must have submitted an approved program for the degree.</br>
Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) . Within the MPA program, PADM 210  meets the GWAR.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing PADM 210 .</br>

### Culminating Experience
Plan A (with Thesis)</br>
A thesis demonstrating the student’s competence in original research and acceptable to the department must be submitted to the department at least eight weeks prior to the date on which the degree is to be awarded. This thesis must conform to the SJSU Master’s Thesis and Doctoral Dissertation Guidelines and be approved by the Associate Dean of Graduate Studies.</br>
Plan B (with Project)</br>
In lieu of a thesis, a student may complete an academically rigorous research project by enrolling in PADM 298 - Special Problems . In PADM 298  the student will complete a substantial paper under faculty supervision to complete the project component of Plan B.</br>

## Master’s Requirements (36 units)

### Core Courses (15 units)
The courses form a base of knowledge and skills that prepare students for advanced seminars. Students must complete these courses before taking PADM 298 .</br>
Complete fifteen units from:</br>

- PADM 210 - Introduction to Public Administration 3 unit(s) (GWAR)</br>

- PADM 212 - Administrative Research Methods 3 unit(s)</br>

- PADM 213 - Policy Analysis and Evaluation 3 unit(s)</br>

- PADM 214 - Introduction to Public Management 3 unit(s)</br>

- PADM 218 - Public Budgeting 3 unit(s)</br>


### Advanced Seminars Electives (9-18 units)
Complete three courses from:</br>

- PADM 202 - Regional Governance 3 unit(s)</br>

- PADM 215 - Public Personnel Administration 3 unit(s)</br>

- PADM 217 - Organizational Theory 3 unit(s)</br>

- PADM 219 - Public Financial Administration 3 unit(s)</br>

- PADM 220 - Non-Profit Management 3 unit(s)</br>

- PADM 223 - Law and Public Administration 3 unit(s)</br>

- PADM 295 - Topics in Public Administration 3 unit(s)</br>


### Additional Electives (0-9 units)
Depending on thesis or project arrangements, electives may include additional MPA courses</br>

- PADM 281 - Public Administration Internship 3 unit(s)</br>

- PADM 284 - Directed Reading 1-3 unit(s)</br>

- PADM 297 - Advanced Seminar in Public Management 3 unit(s) (or approved 100- or 200-level courses in political science or other departments, up to a maximum of 9 units)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B):</br>

#### Plan A (with Thesis) (3 units)

- PADM 299 - Master’s Thesis 3 unit(s)</br>


#### Plan B (with Project)

- PADM 298 - Special Problems 3 unit(s)</br>


## Total Units Required (36 units)
No more than six units of 100-level course work may be applied towards the MPA degree.</br>
No more than six units of transfer credit from other universities may be applied toward the MPA degree.</br>
Students who do not have substantial management work experience related to the curriculum are required to register for PADM 281  and complete an appropriate internship.</br>
Elective courses must be planned in consultation with the Graduate Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>