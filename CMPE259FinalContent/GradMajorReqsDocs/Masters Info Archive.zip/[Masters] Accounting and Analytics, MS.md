
# Accounting and Analytics, MS
 </br>

- Educational Objectives</br>

- Benefits of the MSAA</br>

- Admissions Requirements</br>

- Program of Study Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Accounting and Analytics (MSAA). a STEM designated program, offered by the Lucas College and Graduate School of Business , prepares students for careers in public and corporate accounting. Students develop and apply an analytics-oriented mindset to audit, tax, advisory and managerial scenarios. Course work is structured to combine academic learning and accounting internship experience in a well-rounded preparation for careers in professional accounting. The program balances technical study and preparation for the CPA exam with business soft skills needed for recruitment and a career in accounting. The MSAA is a full-time, 9-month, daytime program, although students with flexible employers may be able to study part-time. The 30-unit program, taught online and on the SJSU campus, admits both accounting and non-accounting undergraduate majors in a competitive process. Non-accounting undergraduate students have the opportunity to prepare for the program in a 15-unit summer certificate program preceding Fall enrollment in the MSAA. </br>
For more information, see the Lucas Graduate School of Business website.</br>

## Purpose of the MSAA Program
The MSAA program prepares students for a career in public or corporate accounting by providing them with a strong foundation for both public accounting certification (CPA) and career advancement.</br>

## Educational Objectives
Students with an MSAA degree should recognize and apply the accounting principles and procedures involved in measuring, recording, summarizing, and reporting financial and non-financial data for business organizations; taxation concepts; auditing and control procedures; and the ethical and legal challenges in an accounting career. They should communicate effectively, both orally and in writing, evaluate information technology, and demonstrate analytical proficiency.</br>

## Benefits of the MSAA
The program is designed for people with undergraduate degrees in accounting who want to further their studies in accounting while acquiring an additional 30 units needed for CPA licensure. It also allows liberal arts/sciences/business undergraduates who are interested in changing careers an entrance into the accounting profession. The course work and optional internship provide opportunities to build a framework for a successful and rewarding career in public or corporate accounting.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements . Applicants apply separately to the Lucas Graduate School of Business to obtain admission into the MSAA program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Requirements for Admission to Classified Standing
To be fully accepted into the MSAA in classified standing, an applicant must have:</br>

- A four-year bachelor’s degree from an accredited college or university in the United States or from a recognized institution if the degree was earned outside of the United States.</br>

- A preferred GPA of 3.0 or better (on a 4.0 scale) in the last 60 semester units or 90 quarter units of course work (Professional Development and Certificate Program course work cannot be included in this calculation);</br>

- (Optional) A Graduate Management Admission Test (GMAT) or the Graduate Record Examination (GRE) exam. Applicants with a GPA below 3.0 are strongly encouraged to take the GMAT or GRE to demonstrate their readiness for graduate work.</br>

- A personal statement explaining the MSAA applicant’s career objectives.</br>

- A resume detailing the applicant’s professional and academic experiences.</br>

- Two letters of recommendation.</br>

In addition, a personal interview may be conducted for each applicant.</br>

### Requirements for Admission to Conditionally Classified Standing
If not accepted into classified standing, the applicant may qualify for conditionally classified status. Ambitious, highly motivated applicants with undergraduate degrees in liberal arts, sciences, or business will need to complete the intensive Certificate in Accounting Fundamentals program during the summer semester before matriculation into the MSAA degree program. The individual admission letter will explain the required terms and conditions for attaining Classified standing.</br>

## Program of Study Requirements
To receive the Master of Science in Accounting and Analytics, students must complete 30 semester units of prescribed course work. Specific program policies include the following:</br>

### Prerequisites
The curriculum requires completion of two lower-division and five upper-division prerequisite courses (3 semester hours or equivalent) within the past five years with an average grade in the courses of “B” (3.0)or better prior to the start of the program. All upper-division prerequisites must be completed at an accredited four-year university in the U.S. The seven prerequisite courses are:</br>

- Introductory Financial Accounting (lower-division course, gateway to upper-division courses 2-6)</br>

- Intermediate Financial Accounting I</br>

- Intermediate Financial Accounting II</br>

- Accounting Information Systems</br>

- Management Accounting and Control Systems</br>

- Tax Factors of Business and Investment Decisions</br>

- Statistics (lower division course)</br>

Students may be conditionally admitted into the program pending completion of the prerequisite courses. Students must, at a minimum, submit completion and/or verification of enrollment in Introductory Financial Accounting and Statistics by the published GAPE document submission deadline. One way to fulfill the rest of the prerequisites is to enroll in the Certificate in Accounting Fundamentals at SJSU to complete courses 2-6 with an average of B in the summer preceding Fall enrollment in the MSAA program.</br>

### Course Requirements
The 30 semester units of coursework include three core courses (9 units) required of all students, two core courses (6 units) from a list of designated topics, a culminating experience course (3 units), and four elective MSAA courses (12 units). Electives may be taken from offerings in the MST and/or MBA programs with approval from the MSAA director.</br>

### Internship
The courses in the MSAA program are designed to prepare students for internships with public accounting firms, governmental agencies, and corporations. From January through March, students may enroll in an internship course, BUS 220K . Students in this course gain practical work experience, participate in firm training programs, and attend roundtable meetings to discuss topics such as professional ethics, working in the professional environment, communication effectiveness, marketing professional services, and planning for professional growth.</br>

### Graduation Writing Assessment Requirement
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

### Culminating Experience
Plan B (Project)</br>
All students must complete a comprehensive project integrating business functional and interdisciplinary areas. The MSAA culminating experience is incorporated into BUS 220A - Financial Statement Analysis . An individual written project report is required and may take the form of a field study, business plan, research project, or business simulation.</br>

### Maintenance of 3.0 GPA
Students must maintain a grade point average of 3.0 or better on all graduate-level coursework. Students who receive grades of C-, D, F, or U in any business graduate course must repeat that course to achieve a grade of C or better.</br>

### Other University Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . Students must comply with all other graduate requirements contained in this catalog.</br>

### Prerequisite Courses
Any of the prerequisite courses may be waived through evidence of recent prior equivalency (within the last five years with a grade of “B” or better)</br>

- Introductory Financial Accounting</br>

- Intermediate Financial Accounting I</br>

- Intermediate Financial Accounting II</br>

- Accounting Information Systems</br>

- Management Accounting and Control Systems</br>

- Tax Factors of Business and Investment Decisions</br>

- Statistics</br>


## Master’s Requirements (30 units)

### Required Courses (15 units)
If more than two courses are taken, two fulfill the core course requirements and all others are electives.</br>

- BUS 220J - Business Communications & Ethics 3 unit(s) (GWAR)</br>

- BUS 220U - Information Technology Audit 3 unit(s)</br>

- BUS 220Z - Advanced Data Science and Analytics for Accounting 3 unit(s)</br>


#### Choose two courses:
Choose two of the following courses in consultation with the graduate advisor. If more than two courses are taken, two fulfill the core course requirements and all others are electives.</br>

- BUS 220H - Auditing: Concepts and Practice 3 unit(s)</br>

- BUS 220P - Taxation of Individuals and Flow-Through Entities 3 unit(s)</br>

- BUS 220R - Data Analytics for Accounting 3 unit(s)</br>

- BUS 220S - Financial Reporting and Analysis III 3 unit(s)</br>

- BUS 220V - Special Topics in Accounting 3 unit(s)</br>


### Electives (12 units)
12 units of elective courses selected in consultation with the graduate advisor.</br>

- BUS 220I - Forensic Accounting 3 unit(s)</br>

- BUS 220K - Accounting Practicum 3 unit(s)</br>

- BUS 220M - Accounting Ethics 3 unit(s)</br>

- BUS 220X - Business Analysis and Valuation Using Financial Statements 3 unit(s)</br>

- BUS 223A - Tax Research and Decision Making 3 unit(s)</br>

- BUS 223G - Taxation of Business Entities 3 unit(s)</br>

- BUS 225L - Accounting for Income Taxes 3 unit(s)</br>

- BUS 250 - Law and Ethics 3 unit(s)</br>

- BUS 253 - Negotiation and Conflict Management 3 unit(s)</br>

- BUS 286 - Project Management 3 unit(s)</br>


### Culminating Experience (3 units)

#### Plan B (Project)

- BUS 220A - Financial Statement Analysis 3 unit(s)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>