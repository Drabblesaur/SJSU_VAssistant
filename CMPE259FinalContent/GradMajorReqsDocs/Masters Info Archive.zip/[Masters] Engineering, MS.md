
# Engineering, MS
 </br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy</br>

- Completing Requirements for the MS - Engineering</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MS Engineering degree by the Interdisciplinary Engineering Program  offers practicing engineers the opportunity to develop a wide range of knowledge and skills needed to function in today’s complex industrial environment. The program is designed to provide flexibility for students who need coursework that is truly interdisciplinary and not available through the other engineering programs in the college. The MS-Engineering programs typically include courses from at least three different programs in the College of Engineering  and may also use courses in other colleges. Students are required to submit a program-of-study proposal by the end of their first semester enrolled in MSE. Additional off-campus specialized MSE programs are offered at local industry sites.</br>

## Requirements for Admission to Classified Standing
Students seeking admission to MS Engineering programs must meet the general university requirements for admission as outlined in this catalog. In addition, the applicant must possess a baccalaureate degree from an ABET-accredited engineering program with a grade point average of at least 3.0 in the last 60 semester hours of upper-division work completed in all subjects and in technical subjects only. Students meeting these criteria may be admitted in classified standing; however, students may still be admitted conditionally if they need prerequisite courses for the selected specialization. More information on admission requirements can be found on the program website.</br>

## Requirements for Admission to Conditionally Classified Standing
A graduate applicant whose undergraduate record indicates deficiencies in one or more technical areas and/or has a grade point average less than 3.0 in the last 60 semester hours of upper-division work completed in all subjects and in technical subjects only may be admitted for graduate work on a conditionally classified basis. Such students will be expected to satisfactorily complete additional coursework before becoming classified. Students admitted in conditionally classified status may petition for classified status when coursework in deficient areas has been completed, when they have satisfied the Graduation Writing Assessment Requirement (GWAR), and when their records in classes at San José State University show sufficient promise of success in the master’s degree program.</br>

## Requirements for Advancement to Candidacy
Students seeking the MS Engineering degree must meet the general university requirements for candidacy  as outlined in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, the applicant must demonstrate an aptitude for advanced professional work in engineering as measured by instructor appraisals, analysis of previous academic work, or other appropriate means. Advancement to candidacy and approval of programs will be handled by a faculty committee and the student’s advisor.</br>

## Completing Requirements for the MS - Engineering
The normal course of study for the MS-Engineering degree consists of 30 semester hours of approved work in the following areas:</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core Courses (6 units)

- ENGR 201 - Engineering Analysis 3 unit(s)</br>

- ENGR 202 - Systems Engineering 3 unit(s) (GWAR)</br>


### Specialized Core (3-9 units)

### Approved Specialization Electives (9-15 units)

### Culminating Experience (3-6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Sequence From:</br>

#### Master’s Thesis Sequence (Plan A)

- ENGR 281 - Master’s Project/Thesis Preparation Seminar 1 unit(s)</br>

- ENGR 299 - Master’s Thesis 1-6 unit(s)</br>


#### Master’s Project Sequence 1 (Plan B)

- ENGR 281 - Master’s Project/Thesis Preparation Seminar 1 unit(s)</br>

- ENGR 298 - Master’s Project 2 unit(s)</br>


#### Master’s Project Sequence 2 (Plan B)

- ENGR 295A - Master Project I 3 unit(s)</br>

- ENGR 295B - Master Project II 3 unit(s)</br>


## Total Units Required (30 units)
 </br>