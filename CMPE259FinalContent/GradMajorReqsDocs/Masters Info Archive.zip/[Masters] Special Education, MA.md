
# Special Education, MA
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- University Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

Advisors: Dr. Andrea Golloher, Dr. Peg Hughes, Dr. Sudha Krishnan, Dr. Saili Kulkarni, and Dr. Lisa Simpson.</br>
The MA in Special Education is a 30-unit program, offered by the Department of Special Education , that prepares candidates to be transformative educators who possess the knowledge and skills necessary to creatively and holistically meet the intersectional identities (dis/ability, race, gender, linguistic, and ethnic identities) of all learners, and who work as change agents to create equitable and inclusive environments in schools and communities in order to reimagine accessible schooling. Students complete an MA action research project in their fieldwork setting. Students may opt to complete the MA simultaneously with the Education Specialist credential.</br>

## Department of Special Education Master’s Program Admission Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system at calstate.edu/apply and meet all the university and department admission requirements. See the GAPE Graduate Admissions website and this Catalog for general information about graduate admissions at SJSU. Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on GAPE’s Graduate Program Test Requirements webpage. For TOEFL requirements, see the Policies and Procedures section, Graduate and Post-Baccalaureate Information in this Catalog.</br>

- CSU Apply application with statement of purpose for admission to SJSU.</br>

- Bachelor’s degree from a regionally accredited institution of higher education.</br>

- Grade point average (GPA) of at least 2.50 in last 60 units of coursework.</br>

- 45 hours of Pre-professional experience.</br>

- Certificate of Clearance (fingerprint clearance) from California Commission on Teacher Credentialing (CTC).</br>

- Two letters of recommendation.</br>

If completing MA simultaneously with the Education Specialist Credential must also submit:</br>
     7. Verification of Basic Skills (met with undergraduate degree.</br>
     8. Verification of Subject Matter Competency or California Subject Examination for Teachers - submit by end of first semester in program.</br>
Upon review of submitted document applicants may be called for a department interview. Applicants are encouraged to attend a department information session for more information about the application process and program offerings. Students must complete each course with a B or higher and maintain a GPA of 3.0 in the program.</br>

## Requirements for Advancement to Candidacy
To be advanced to candidacy for the Master of Arts degree, a student must first meet the university requirements for the degree as stated in the Advancement to Candidacy  section. Applicants may be admitted to classified standing if they meet the admissions requirements for both the Graduate Division and the department. The minimum requirements for the program are a bachelor’s degree in any discipline and a minimum 2.50 GPA at entrance. Candidates must maintain a 3.0 GPA for Advancement to Candidacy.</br>

### University Requirements
Candidacy denotes that a student is fully qualified to complete the final stages of the Master of Arts degree. General university requirements for advancement to candidacy are detailed in the Graduate Policies and Procedures section of this catalog. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR). Students satisfy the GWAR, by successfully completing EDSE 285 - Seminar on Issues Related to Teaching Exceptional Individuals with a grade of B or higher.</br>

### Department Requirements
1. Complete the Graduate Writing Assessment Requirement (GWAR) by completing EDSE 285 with a grade of B or higher.
2. Maintain an overall graduate GPA of 3.0 or higher
3. Meet with your graduate advisor to complete the Petition for Advancement to Graduate Candidacy form.</br>

## University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . Students must pass the Graduation Writing Assessment Requirement (GWAR)  course and Culminating experience identified below.. </br>

## Master’s Requirements (30 units)

### Core Courses (24 units)

- EDSE 102 - Intro to Language Development and Disability 3 unit(s)</br>

- EDSE 218D - Teaching Students with Autism Spectrum Disorders 3 unit(s)</br>

- EDSE 224 - Methods for Emergent Bilinguals with Disabilities 1-3 unit(s)</br>

- EDSE 228A - Topics in Collaboration and Transition 3 unit(s)</br>

- EDSE 241 - Applying Assistive & Instructional Technology 3 unit(s)</br>

- EDSE 279 - Positive Behavior Support 3 unit(s)</br>


#### Complete One From:

- EDSE 215 - Assessing Students with Disabilities 3 unit(s)</br>

- EDSE 108 - Assessing Young Children 3 unit(s)</br>


#### Complete One From:

- EDSE 213A - Methods for Students with Extensive Support Needs 3 unit(s)</br>

- EDSE 221 - Methods for Young Children with Disabilities 3 unit(s)</br>

- EDSE 230A - Inclusive Pedagogy for Students with M/MSN 3 unit(s)</br>


### Research Course (3 units)

- EDSE 285 - Intro to Action Research in Special Education 3 unit(s) (GWAR)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Choose one of the following:</br>

- Plan A (Thesis):  EDSE 299 - Master’s Thesis 3 unit(s)</br>

- Students selecting the Plan A option will write a master’s thesis. The thesis will include original research on a topic approved by the thesis committee, and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. Thesis proposals must be approved by the graduate committee made up of two department faculty and a third faculty member from outside the department. 

 </br>
Students selecting the Plan A option will write a master’s thesis. The thesis will include original research on a topic approved by the thesis committee, and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. Thesis proposals must be approved by the graduate committee made up of two department faculty and a third faculty member from outside the department. </br>
 </br>

- Plan B (Project):  EDSE 220 - Advanced Research Projects in Special Education 3 unit(s)</br>

- Students selecting the Plan B option will complete a master’s project or research paper. This a significant undertaking that evidences originality and independent thinking, appropriate form and organization, and a rationale. The final paper includes the significance, objectives, methodology and a conclusion or recommendation.</br>

Students selecting the Plan B option will complete a master’s project or research paper. This a significant undertaking that evidences originality and independent thinking, appropriate form and organization, and a rationale. The final paper includes the significance, objectives, methodology and a conclusion or recommendation.</br>

## Total Units Required (30 units)
The maximum number of graduate units (with a grade of “B” or better) that can be transferred from approved accredited universities is 9 units. Continuing education and extended studies units are not accepted for transfer. Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>