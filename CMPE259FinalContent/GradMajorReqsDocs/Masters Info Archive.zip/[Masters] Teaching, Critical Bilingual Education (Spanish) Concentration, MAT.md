
# Teaching, Critical Bilingual Education (Spanish) Concentration, MAT
 </br>

- Admissions Requirements</br>

- Conditionally Classified Standing</br>

- Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (34 units)</br>

- Program Learning Outcomes  </br>

The Master of Arts Teaching (MAT) degree program, offered by the Department of Teacher Education , prepares teacher candidates to engage in social justice teaching practices, contribute to the development of cultural literacy, provide education that promotes democracy, and develop content knowledge expertise to teach in urban and suburban schools. The program additionally prepares teacher candidates to provide instruction for multilingual learners and students with special needs. Teacher candidates also will learn to set up a supportive classroom environment based on social-emotional learning principles and experience collaborative co-teaching experiences with successful mentor teachers in the field. Finally, teacher candidates will design, carry out, and report on classroom-based teacher inquiry.</br>
Bilingual Candidates admitted to the Critical Bilingual Concentration will specialize further in the application of the knowledge and skills developed in the MAT to current issues in bilingual education. Additionally, they will engage with content specific to bilingual education that prepares them as transformational bilingual educators and leaders in their communities.</br>

## Admissions Requirements
Applicants must submit a complete graduate application to the Multiple or Single Subject Credential Program by applying through CSU Cal State Apply and meet all the university admissions requirements. A full list of current admission requirements can be found on the Teacher Education Department website. Note that the Teaching, MAT is not a stand-alone degree and must be completed in conjunction with one of the above teacher credentials. </br>
Provided that admitted teacher candidates remain in good standing, those who want to pursue the MAT degree will complete a program transfer (credential to MAT) during their credential program.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Admissions Test Requirements webpage. For TOEFL requirements, see the Graduate Admissions  section.</br>
Prospective Critical Bilingual Concentration candidates must meet additional requirements (outlined below) in an admission process conducted by the Coordinator/Faculty advisor: Dr. Bernadette Rodriguez.</br>

- Candidates must meet all university admissions requirements.</br>

- Program Materials required by the Department are listed on the Department of Teacher Education website. The materials enumerated below must be uploaded to the Cal State Apply application. For additional details go to the Department of Teacher Education website.

	

Subject Matter Competency (Required)
		The Subject Matter Competency Requirement can be met in a variety of ways including via the CSETs, approved degree major, CTC-approved subject matter preparation program, or qualified coursework that meets each of the CTC subject matter domains. Information about meeting this requirement for current and prospective SJSU students can be found here: Meeting the Subject Matter Competency Requirement. Additional information can be found on the CTC website. Note that the requirements for Subject Matter Competence at the point of admission may differ for the Multiple and Single Subject Programs.


Basic Skills Requirement (Required)
		The Basic Skills Requirement is currently met via a BA/BS degree from a regionally accredited university. Information about meeting this requirement for current and prospective SJSU students, including international students, can be found at the Meeting the Basic Skills Requirement webpage.


Field Experience 
		Required for applicants starting in Spring 2026 or later.  Highly recommended for applicants prior to Spring 2026. Field Experience consists of working/volunteering in a public school traditional classroom setting in your credential area. For further details, see the Field Experience form referenced below. Upload a completed/signed Field Experience Form from the Department of Teacher Education website in the Cal State Apply portal to verify your experience.  You may contact any California public school and let them know that you are applying to the SJSU Teaching Credential program and need to complete Field Experience hours. SJSU courses accepted to meet the Multiple Subject or PK-3 Requirement are: LSTP 185  and CHAD 159 . For PK-3, CHAD 160  will also meet this requirement. 


Certificate of Clearance (Required)
		​There are 3 steps to obtain a Certificate of Clearance (CoC): Do not wait until the last minute to request this item, as it can take weeks for CTC to issue. For detailed information about how to complete these steps, go to the Credential Information website.


Step 1 - Live Scan Service


Step 2 - Certificate of Clearance Application via CTC​


Step 3 - Upload a pdf of the granted Certificate of Clearance ​to your CalState Apply application




</br>

- 

Subject Matter Competency (Required)
		The Subject Matter Competency Requirement can be met in a variety of ways including via the CSETs, approved degree major, CTC-approved subject matter preparation program, or qualified coursework that meets each of the CTC subject matter domains. Information about meeting this requirement for current and prospective SJSU students can be found here: Meeting the Subject Matter Competency Requirement. Additional information can be found on the CTC website. Note that the requirements for Subject Matter Competence at the point of admission may differ for the Multiple and Single Subject Programs.
</br>
Subject Matter Competency (Required)
		The Subject Matter Competency Requirement can be met in a variety of ways including via the CSETs, approved degree major, CTC-approved subject matter preparation program, or qualified coursework that meets each of the CTC subject matter domains. Information about meeting this requirement for current and prospective SJSU students can be found here: Meeting the Subject Matter Competency Requirement. Additional information can be found on the CTC website. Note that the requirements for Subject Matter Competence at the point of admission may differ for the Multiple and Single Subject Programs.</br>

- 

Basic Skills Requirement (Required)
		The Basic Skills Requirement is currently met via a BA/BS degree from a regionally accredited university. Information about meeting this requirement for current and prospective SJSU students, including international students, can be found at the Meeting the Basic Skills Requirement webpage.
</br>
Basic Skills Requirement (Required)
		The Basic Skills Requirement is currently met via a BA/BS degree from a regionally accredited university. Information about meeting this requirement for current and prospective SJSU students, including international students, can be found at the Meeting the Basic Skills Requirement webpage.</br>

- 

Field Experience 
		Required for applicants starting in Spring 2026 or later.  Highly recommended for applicants prior to Spring 2026. Field Experience consists of working/volunteering in a public school traditional classroom setting in your credential area. For further details, see the Field Experience form referenced below. Upload a completed/signed Field Experience Form from the Department of Teacher Education website in the Cal State Apply portal to verify your experience.  You may contact any California public school and let them know that you are applying to the SJSU Teaching Credential program and need to complete Field Experience hours. SJSU courses accepted to meet the Multiple Subject or PK-3 Requirement are: LSTP 185  and CHAD 159 . For PK-3, CHAD 160  will also meet this requirement. 
</br>
Field Experience 
		Required for applicants starting in Spring 2026 or later.  Highly recommended for applicants prior to Spring 2026. Field Experience consists of working/volunteering in a public school traditional classroom setting in your credential area. For further details, see the Field Experience form referenced below. Upload a completed/signed Field Experience Form from the Department of Teacher Education website in the Cal State Apply portal to verify your experience.  You may contact any California public school and let them know that you are applying to the SJSU Teaching Credential program and need to complete Field Experience hours. SJSU courses accepted to meet the Multiple Subject or PK-3 Requirement are: LSTP 185  and CHAD 159 . For PK-3, CHAD 160  will also meet this requirement. </br>

- 

Certificate of Clearance (Required)
		​There are 3 steps to obtain a Certificate of Clearance (CoC): Do not wait until the last minute to request this item, as it can take weeks for CTC to issue. For detailed information about how to complete these steps, go to the Credential Information website.


Step 1 - Live Scan Service


Step 2 - Certificate of Clearance Application via CTC​


Step 3 - Upload a pdf of the granted Certificate of Clearance ​to your CalState Apply application


</br>
Certificate of Clearance (Required)
		​There are 3 steps to obtain a Certificate of Clearance (CoC): Do not wait until the last minute to request this item, as it can take weeks for CTC to issue. For detailed information about how to complete these steps, go to the Credential Information website.</br>

- 

Step 1 - Live Scan Service
</br>

- 

Step 2 - Certificate of Clearance Application via CTC​
</br>

- 

Step 3 - Upload a pdf of the granted Certificate of Clearance ​to your CalState Apply application
</br>
Note: A US Social Security or Tax Identification Number is required to obtain a COC. If you are an international student, please consult an advisor in our International Student & Scholars Services (ISSS) to see if this is possible on your particular visa.</br>

- 

Statement of Purpose (2 required)
	In your Statement of Purpose, explain how you arrived at your decision to become a teacher.
</br>
Statement of Purpose (2 required)
	In your Statement of Purpose, explain how you arrived at your decision to become a teacher.</br>

- 

A second Statement of Purpose is required for Bilingual Authorization applicants (only). Spanish Bilingual Authorization applicants must write their second statement in Spanish. Mandarin or Vietnamese Bilingual Authorization applicants must write their second statement in English.
</br>
A second Statement of Purpose is required for Bilingual Authorization applicants (only). Spanish Bilingual Authorization applicants must write their second statement in Spanish. Mandarin or Vietnamese Bilingual Authorization applicants must write their second statement in English.</br>

- 

Resume (Required)
	Prepare a brief (one or two page) resume that details your college-level academic, employment, and volunteer experiences. In describing a position that you held (employment or volunteer service), highlight the duties you performed and any awards/accomplishments.
</br>
Resume (Required)
	Prepare a brief (one or two page) resume that details your college-level academic, employment, and volunteer experiences. In describing a position that you held (employment or volunteer service), highlight the duties you performed and any awards/accomplishments.</br>

- 

Two Letters of Recommendation (Required)
	​Two professional letters of recommendation are required and are requested within your CalState Apply application. Letters must be written within the last 2 years and should be from someone in a supervisory role. Up to four letters of recommendation may be submitted but only two are required.
</br>
Two Letters of Recommendation (Required)
	​Two professional letters of recommendation are required and are requested within your CalState Apply application. Letters must be written within the last 2 years and should be from someone in a supervisory role. Up to four letters of recommendation may be submitted but only two are required.</br>

- 

Official Transcripts (Required)
	Official transcripts (sealed or electronic) from each college/university attended, aside from SJSU, must be submitted. Information about how to submit transcripts can be found at the SJSU Graduate Admissions website.  A minimum 2.5 GPA is required. International transcripts must go through additional evaluation steps and will take additional time to prepare and submit. Please see the Graduate Admissions website for more information.
</br>
Official Transcripts (Required)
	Official transcripts (sealed or electronic) from each college/university attended, aside from SJSU, must be submitted. Information about how to submit transcripts can be found at the SJSU Graduate Admissions website.  A minimum 2.5 GPA is required. International transcripts must go through additional evaluation steps and will take additional time to prepare and submit. Please see the Graduate Admissions website for more information.</br>

- 

Interview
	​Most applicants to the program are recommended for an interview.
</br>
Interview
	​Most applicants to the program are recommended for an interview.</br>

- 

Language Proficiency (required upon graduation)
Critical Bilingual Concentration Candidates also need to pass the state test Languages Other than English (LOTE), subtest 3, in order to be eligible for the associated bilingual authorization (separate from the concentration). Alternate options include a BA in Spanish or a degree from a Spanish speaking country. Based on availability due to cohort size, candidates may opt to pursue a portfolio assessment option to satisfy the language proficiency requirement.
</br>
Language Proficiency (required upon graduation)
Critical Bilingual Concentration Candidates also need to pass the state test Languages Other than English (LOTE), subtest 3, in order to be eligible for the associated bilingual authorization (separate from the concentration). Alternate options include a BA in Spanish or a degree from a Spanish speaking country. Based on availability due to cohort size, candidates may opt to pursue a portfolio assessment option to satisfy the language proficiency requirement.</br>

### Conditionally Classified Standing
Because the MAT program is nested within the Multiple Subject Credential  and Single Subject Credential program, which requires applicants to meet departmental admissions requirements, admission to conditionally classified standing is not appropriate and is not permitted.</br>

### Advancement to Candidacy
Candidacy denotes that a student is fully qualified to complete the final stages of the MAT degree. Requirements for advancement to candidacy, including the Graduation Writing Assessment Requirement (GWAR), are listed on the Graduate Admissions and Program Evaluation website.</br>

### Department Requirements

- 

Complete 8 units of core courses (EDTE 224 , EDTE 260 , EDTE 262 , and EDTE 294 ) with a grade of “C” or better in each one.
</br>
Complete 8 units of core courses (EDTE 224 , EDTE 260 , EDTE 262 , and EDTE 294 ) with a grade of “C” or better in each one.</br>

- 

Complete the 3-unit Critical Bilingual Education (Spanish) Concentration foundations course, EDTE 208B , with a grade of “C” or better.
</br>
Complete the 3-unit Critical Bilingual Education (Spanish) Concentration foundations course, EDTE 208B , with a grade of “C” or better.</br>

- 

Complete the 3-unit Critical Bilingual Education (Spanish) Concentration research methods course, EDTE 250B , with a grade of “C” or better.
</br>
Complete the 3-unit Critical Bilingual Education (Spanish) Concentration research methods course, EDTE 250B , with a grade of “C” or better.</br>

- 

Maintain an overall graduate GPA of 3.0 or higher. 
</br>
Maintain an overall graduate GPA of 3.0 or higher. </br>

- 

Note: Grades of “C-” or lower will remain on a student’s record, be computed for GPA, and require a course retake.
</br>
Note: Grades of “C-” or lower will remain on a student’s record, be computed for GPA, and require a course retake.</br>

- Critical Bilingual Education (Spanish) Concentration MAT candidates who also are Single Subject Credential candidates must complete each of their subject-area methods courses with a grade of “B” or better.</br>


## Requirements for Graduation

### University Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements section of the Graduate Policies and Procedures . Completion of the degree also requires a minimum grade of “C” in all courses taken and a minimum overall GPA of 3.0.</br>

### Department Requirements

- Complete 12 units of core courses (EDTE 224 , EDTE 260 , EDTE 262 , and EDTE 294 ) and 10 units of concentration courses (EDTE 208B , EDTE 250B , and EDTE 297B -twice).</br>

- Complete at least 6 units of subject-area curriculum and instruction courses.</br>

- Successfully receive approval for a project proposal (Plan B) or thesis proposal (Plan A) while completing EDTE 250B .</br>

- Apply for graduation via MySJSU (through one.SJSU.edu).</br>

- Successfully complete either a project / portfolio (Plan B, EDTE 298 ) or thesis (Plan A, EDTE 299 ).</br>

- Satisfy the culminating experience requirements, which typically consist of successful completion of the project / portfolio or thesis (i.e., 5 above) AND a presentation on the same at the department’s colloquium, which is held near the end of each fall and spring semester.</br>


### Culminating Experience
Plan A (Thesis)
Students selecting the Plan A option will write a master’s thesis. The thesis will include original research on a topic approved by the thesis committee, and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. The thesis identifies the problem, states the major assumptions, explains the significance of the undertaking, sets forth the sources for and methods of gathering information, analyzes the data, and offers a conclusion or recommendation. Thesis proposals must be approved by the graduate committee, which is made up of two department faculty and a third faculty member from outside the department. Students enroll in EDTE 299 - Master’s Thesis .</br>
Plan B (Portfolio or Project)
Students selecting the Plan B option will complete a master’s portfolio or project report. Either is a significant undertaking that evidences originality and independent thinking, appropriate form and organization, and a rationale. It is described and summarized, its significance, objectives, methodology and a conclusion and / or implications. Students enroll in EDTE 298 - Special Studies in Education  (for PK-3), EDTE 298 - Special Studies in Education  or CHAD 298 - Special Studies in Child and Adolescent Development .</br>

## Master’s Requirements (32 units)

### Core Courses (12 units)

- EDTE 224 - Seminar in Educational Psychology 3 unit(s)</br>

- EDTE 260 - Critical Perspectives on Schooling for a Pluralist Democracy 3 unit(s)</br>

- EDTE 262 - Classroom Issues in the Language/Literacy Development of L2 Learners 3 unit(s)</br>

- EDTE 294 - Research/Practices in Health and Special Education 3 unit(s)</br>


### Critical Bilingual Education Concentration (8 units)

- EDTE 208B - Bilingual Educational Sociology 3 unit(s) (GWAR)</br>

- EDTE 250B - Qualitative Research in Bilingual Education 3 unit(s) (GWAR)</br>

- EDTE 297B - Advanced Issues in Bilingual Education 1-3 unit(s) (Course should be taken twice.)</br>


### Curriculum and Instruction Tracks (6-9 units)
Complete the Multiple Subject Credential or Single Subject Credential:</br>

#### Elementary Education Track (9 units)

- EDEL 108A - Curriculum: Reading/Language Arts 3 unit(s)</br>

- EDEL 108B - Curriculum: Science 3 unit(s)</br>

- EDEL 108C - Curriculum: Social Studies 3 unit(s)</br>


#### Secondary Education Track (6-7 units)

- EDTE 282 - Assessment and Evaluation 3 unit(s)</br>

Complete 3-4 units:</br>

- ARED 238 - Principles of Art Education 3 unit(s)</br>

- ENED 353 - Methods of Teaching English 4 unit(s)</br>

- FLED 380 - Teaching Foreign Languages 3 unit(s)</br>

- KNED 339 - Instructional Materials and Procedures in Physical Education 3 unit(s)</br>

- MTED 394 - Secondary Mathematics Methods 3 unit(s)</br>

- MUED 370A - Methodology for Music Educators: Elementary K-8 2 unit(s)</br>

- MUED 370B - Methodology for Music Educators: Secondary 2 unit(s)</br>

- SCED 273 - Secondary School Science 3 unit(s)</br>

- SSED 378 - Social Science Methods 3 unit(s)</br>


### Culminating Experience (3-6 units)
MAT Presentation at Department Colloquium AND satisfactory completion of MAT Project / Portfolio or Thesis. Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete Plan A (Thesis) or Plan B (Portfolio or Project):</br>

#### Plan A (Thesis)

- EDTE 299 - Master’s Thesis 1-6 unit(s)</br>


#### Plan B (Portfolio or Project)

- EDTE 298 - Special Studies in Education 1-6 unit(s)</br>


## Total Units Required (32 units)
Upon completion of the credential requirements, students must have achieved an SJSU cumulative grade point average of 3.0 in order to be recommended for a credential.</br>
 </br>