
# Geography, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MA in Geography is offered by the School of Planning, Policy and Environmental Studies . Admission to the graduate program is flexible, and potential students are evaluated on a case-by-case basis. A strong record based on either undergraduate performance or employment experience is expected. Graduate students without a geography degree can expect added course work in geographic literature and theory. More information can be found on the Geography webpage.</br>

## Admissions Requirements
All graduate applicants must submit a complete graduate application by applying through the CSU Cal State Apply system. Additional information regarding university admission requirements  is in this catalog. Applicants from countries in which the native language is not English must achieve a minimum English language proficiency test score as indicated on the Graduate Program Test Requirement webpage.</br>

### Admissions to Classified Standing
Basic requirements for admission to the Graduate Division are outlined in the Admissions section. In addition, the department requires the following for admission to classified standing:</br>

- An undergraduate degree in geography or a reasonably related field from an accredited institution.</br>

- A 3.0 (“B”) overall grade point average for the last 60 semester units of academic study.</br>

- The capability, in the opinion of the Department Graduate Committee, of successfully completing the degree requirements.</br>

- The removal of deficiencies if preparation differs markedly from the BA - Geography at San José State University.</br>


### Admissions to Conditionally Classified Standing
If not accepted into classified standing, the applicant may qualify for conditionally classified status for which the following will be required:</br>

- The ability, in the opinion of the Department Graduate Committee, to remove deficiencies which do not exceed the equivalent of one full-time semester of course work.</br>

- The qualifications to be accepted to classified standing within a reasonable length of time, and the background to conduct studies at the graduate level.</br>


## Requirements for Advancement to Candidacy
The student may be advanced to candidacy   for the MA - Geography by complying with requirements of the university as outlined in the Academic Regulations section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, students must obtain their thesis advisor’s approval for their thesis proposal.</br>
Students will complete a course of study designed to prepare them for professional work in their chosen subfield. Accordingly, they will need to take specific courses to support research and project work in that field.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
In consultation with the department advisor, the candidate will develop and pursue a program of study outlined in Plan A or Plan B. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approved Program.</br>
Plan A (with Thesis)</br>

- A minimum of eighteen units in geography.</br>

- The thesis, based on independent research, is to be conducted under the direction of a thesis advisor and must be acceptable to and approved by the Thesis Committee. The Committee consists of the thesis advisor (committee chair), an additional member from the university faculty, and an additional member who may be from outside the university. The thesis topic shall be developed within the departmental foci in consultation with the thesis advisor. The thesis must conform to the SJSU Master’s Thesis and Doctoral Dissertation Guidelines.</br>

- Final Examination: The thesis must be successfully defended orally before the thesis committee.</br>

Plan B (without Thesis)</br>

- A minimum of twenty-one units in geography, with at least 50% of the units in graduate-level courses.</br>

- Project: The student shall present the results of a project in one of the areas of departmental focus. Appropriate projects include research completed for a geography graduate seminar or an independent study conducted under the supervision of a faculty advisor. The results will be reported in a written paper and other materials submitted to the department, and will be presented formally to a geography faculty and student colloquium for acceptance.</br>


## Master’s Requirements (30 units)

### Plan A (with Thesis) (30 units)

#### Core Seminar (3 units)

- GEOG 290 - Seminar in Research Design for Geographic Information Science 3 unit(s) (GWAR)</br>


#### Geography Seminars (6 units)
Complete two courses from:</br>
Courses can be repeated twice if topic changes.</br>

- GEOG 239 - Geographic Information Technology 3 unit(s)</br>

- GEOG 279 - Geographic Information Science Applications 3 unit(s)</br>

- GEOG 282 - Advanced Geographic Techniques 3 unit(s)</br>

- GISC 205 - Spatial Data Literacy and Ethics 4 unit(s) (GWAR)</br>


#### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- GEOG 299 - Master’s Thesis 1-6 unit(s)</br>


#### Electives (15 units)
100 or 200-level courses in geography or related fields selected with advisor’s approval. Students should take the following courses, depending on their area of focus:</br>

- GEOG 282 - Advanced Geographic Techniques 3 unit(s)</br>

- GEOG 195 - Open Source GIS 3 unit(s)</br>

- GEOG 173 - Drones and Spatial Data Collection 3 unit(s)</br>

- GISC 279 - Python Programming for Advanced GIS 4 unit(s)</br>

- GISC 230 - Web GIS/Geo Visualization 4 unit(s)</br>

- GISC 282 - Advanced Remote Sensing & Image Processing 4 unit(s)</br>

- GISC 210 - Spatial Data Science Through Open-Source GIS Technologies 4 unit(s)</br>

- GISC 220 - Spatial Statistics, Analysis, & Modeling 4 unit(s)</br>

- GISC 205 - Spatial Data Literacy and Ethics 4 unit(s) (GWAR)</br>


### Plan B (without Thesis) (30 units)

#### Core Seminar (3 units)

- GEOG 290 - Seminar in Research Design for Geographic Information Science 3 unit(s) (GWAR)</br>


#### Geography Seminars (9 units)

- GEOG 239 - Geographic Information Technology 3 unit(s)</br>

- GEOG 279 - Geographic Information Science Applications 3 unit(s)</br>

- GEOG 282 - Advanced Geographic Techniques 3 unit(s)</br>


#### Culminating Experience (6 units)

- GEOG 298 - Special Study 1-4 unit(s)</br>


#### Electives (18 units)
At least 3 units must be 200-level. </br>
100 or 200-level courses in geography or related fields selected with advisor’s approval. Students should take the following courses, depending on their area of focus:</br>

- GEOG 282 - Advanced Geographic Techniques 3 unit(s)</br>

- GEOG 195 - Open Source GIS 3 unit(s)</br>

- GEOG 173 - Drones and Spatial Data Collection 3 unit(s)</br>

- GISC 210 - Spatial Data Science Through Open-Source GIS Technologies 4 unit(s)</br>

- GISC 220 - Spatial Statistics, Analysis, & Modeling 4 unit(s)</br>

- GISC 230 - Web GIS/Geo Visualization 4 unit(s)</br>

- GISC 279 - Python Programming for Advanced GIS 4 unit(s)</br>

- GISC 282 - Advanced Remote Sensing & Image Processing 4 unit(s)</br>

- GISC 205 - Spatial Data Literacy and Ethics 4 unit(s) (GWAR)</br>


## Total Units Required (30 units)
 </br>