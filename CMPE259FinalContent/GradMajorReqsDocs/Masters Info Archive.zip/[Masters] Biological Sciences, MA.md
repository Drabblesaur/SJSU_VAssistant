
# Biological Sciences, MA
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MA in Biological Sciences, offered by the Department of Biological Sciences , offers students broad training in areas of science that may include general biology, plant biology, cell biology, ecology, entomology, genetics, microbiology, immunology, systems physiology, toxicology, zoology, or, under special circumstances, marine biology. Students with an MA in Biological Sciences go on to careers in research, biotechnology, medical and health sciences, and teaching.</br>
For more information visit the SJSU Biological Sciences website.</br>

## Admissions Requirements
Candidates must apply through the CSU admissions portal, Cal State Apply, and meet all university admission requirements.</br>
In addition, applicants must upload a personal statement, resume, and two letters of recommendation in the Cal State Apply admissions portal.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. The program does not currently require the GRE for admission.</br>
Note: Applicants’ admission into the program is contingent upon their being accepted by a tenured or tenure-track faculty member in the Department of Biological Sciences who will become their major advisor. Applicants must contact the graduate coordinator.</br>

### Requirements for Admission to Classified Standing
Students can be admitted in either classified or conditionally classified standing. To be admitted to the MA in Biological Sciences program in Classified status, an applicant must meet all of the minimum university and departmental requirements for admission.</br>

### Admission to Conditionally Classified Standing
If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental and/or faculty requirements, the conditions will include passing additional courses (specified by the student’s major advisor) in the first semester of the program with a grade of B or better. The program admissions letter will explain terms and requirements.</br>

## Requirements for Advancement to Candidacy
Each semester, students should consult with their graduate advisor to develop a schedule of courses. Students admitted as conditionally classified must satisfy the requirements listed in their acceptance agreement before advancement to candidacy. Students who have completed matriculation and achieved classified standing in the master’s degree curriculum must next advance to candidacy for the degree. A student may advance to candidacy after completing a minimum of 9 units of graded work as a graduate student in letter-graded 100- or 200- level courses acceptable to the department as well as fulfilling the other university requirements for advancement to candidacy , as detailed in the Graduate Policies and Procedures  section. Candidacy includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which is satisfied in this degree by the completion of BIOL 202  with a “B” or higher.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
A grade of “B” or better in BIOL 202  will satisfy the graduate competency in writing requirement.</br>

### Culminating Experience
Students in the MA, Biological Sciences may complete the program Culminating Experience through either a comprehensive exam or graduate project. Students who have advanced to candidacy, and who have completed or are in the final semester of completing the 30 units of required coursework will choose, in consultation with their major advisor, one of two options for their Culminating Experience. The program does not offer a thesis option.</br>
Plan B (Comprehensive Exam)</br>
Students choosing the Plan B (Comprehensive Exam) will enroll in BIOL 298M , and successfully complete the written exam, followed by an oral exam as their culminating experience. The advising committee determines the format of the written and oral exams. Once the written portion of the exam is passed, students take a two- to three-hour oral examination. Successful completion of both exams is required for the award of the MA Biological Sciences degree. Students who are not successful in their first attempt will have one opportunity to retake one or both exams. Written and oral exams will include material from graduate-level coursework taken by the student. Successful completion of both the written and oral exams is determined by a majority vote of the student’s graduate committee.</br>
Plan B (Project)</br>
The student choosing the Plan B (Project) must enroll in the 1-unit BIOL 298M  and complete a research project that has been approved and supervised by their major advisor. This culminating experience option requires students to complete a written report in the style of a manuscript for publication that describes the project and to deliver an oral presentation describing the project to the advising committee. Research projects for the MA Biological Sciences are typically 1-2 semesters in duration. Successful completion of both the manuscript and the oral presentation is determined by a majority vote of the student’s graduate committee.</br>
As shown below, the program consists of 30 semester units of approved work. The student consults with his or her advisor to select coursework.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- BIOL 201 - Graduate Seminar in Biological Sciences 1 unit(s) (2 units required)</br>

- BIOL 202 - Graduate Studies in Biology 3 unit(s) (GWAR)</br>


#### Foundations in Biology (3 units)
Complete one course:</br>

- BIOL 215 - Seminar in Advanced Genetics 3 unit(s)</br>

- BIOL 218 - Advanced Evolution 3 unit(s)</br>

- BIOL 230 - Comparative Animal Physiology 3 unit(s)</br>


#### Current Trends in Biology (3 units)
Complete one course:</br>

- BIOL 255E - Advanced Topics: Ecology and Evolution 1-4 unit(s)</br>

- BIOL 255MMP - Advanced Topics:Molecular, Microbial, and Physiological Biol 1-4 unit(s)</br>


#### Supervised Studies (4 units)
Complete 4 units:</br>

- BIOL 280 - Master’s Individual Studies 1-3 unit(s)</br>

- BIOL 284 - Master’s Directed Reading 1-3 unit(s)</br>


### Electives (14 units)
Students may enroll in a maximum combination of 4 units in BIOL 280  and BIOL 284 .</br>

- BIOL 205 - Advanced Molecular Techniques 4 unit(s)</br>

- BIOL 215 - Seminar in Advanced Genetics 3 unit(s)</br>

- BIOL 218 - Advanced Evolution 3 unit(s)</br>

- BIOL 220 - Science Communication 3 unit(s)</br>

- BIOL 227 - Advanced Physiological Techniques 3 unit(s)</br>

- BIOL 233 - Immunological Techniques 3 unit(s)</br>

- BIOL 230 - Comparative Animal Physiology 3 unit(s)</br>

- BIOL 255E - Advanced Topics: Ecology and Evolution 1-4 unit(s)</br>

- BIOL 255L - Advanced Biology Laboratory 1-4 unit(s)</br>

- BIOL 255MMP - Advanced Topics:Molecular, Microbial, and Physiological Biol 1-4 unit(s)</br>

- BIOL 256 - Advanced Experimental Design and Analysis 3 unit(s)</br>

- BIOL 280 - Master’s Individual Studies 1-3 unit(s)</br>

- BIOL 284 - Master’s Directed Reading 1-3 unit(s)</br>

- 100- or 200-level courses chosen with advisor consent</br>


### Culminating Experience (1 unit)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Choose One Option:</br>

#### Plan B (Project)

- BIOL 298M - MA Culminating Experience 1 unit(s)</br>

- Seminar - Project Defense</br>


#### Plan B (Comprehensive Exam)

- BIOL 298M - MA Culminating Experience 1 unit(s)</br>

- Comprehensive Written Examination</br>

- Comprehensive Oral Examination</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
At least 60% of the units applying toward the degree must be letter-graded coursework.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>