
# Engineering Management, MS
 </br>

- University Admissions</br>

- Requirements for Advancement to Candidacy for the MS - Engineering Management</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

Engineering Management, offered by the Department of Industrial and Systems Engineering , is a specialized form of management that is concerned with the application of engineering principles to business practice. Engineering management is a career that brings together the technological problem-solving savvy of engineering and the organizational, administrative, and planning abilities of management in order to oversee complex enterprises from conception to completion.</br>
Engineering Management programs typically include instruction in the areas of accounting, economics, project management, finance, systems engineering, mathematical modeling and optimization, quality control and six sigma, operations research, human resource management, industrial psychology, safety, and health. At SJSU, the engineering management program emphasizes quality and six sigma, statistics, fundamentals of business accounting and finance, engineering economic analysis, business ethics, supply chain engineering, and systems engineering. Through technical electives, students become knowledgeable in other aspects of business management, such as project management, human resource management, and operations research.</br>
Additional information can be found at the MS Engineering Management website.</br>

## University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the MS, Engineering Management program. See the GAPE Graduate Admissions website and this Catalog for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE. For TOEFL Requirements, see the English Language Proficiency Requirement  section in this catalog.</br>

### Requirements for Admission to Classified Standing
Applicants must meet all university admission requirements . Applicants who meet the following requirements beyond university requirements will be considered for admission into the ISE Department. In addition, applicants must possess a baccalaureate degree from an ABET-accredited engineering program with a grade point average of at least 3.0 in the last 60 semester hours of upper-division work completed in all subjects and in technical subjects only. Students meeting these criteria may be admitted in classified standing; however, students may still be admitted conditionally if they need prerequisite courses for the selected option. An engineering technology degree does not satisfy the degree requirement for admission to this program.</br>

### Requirements for Admission to Conditionally Classified Standing
Applicants who do not meet the requirements for classified standing may be admitted with specific conditions as conditionally classified. An applicant whose undergraduate record indicates deficiencies in one or more technical areas and/or has a grade point average less than 3.0 in the last 60 semester hours of upper-division work completed in all subjects and in technical subjects only may be admitted for graduate work on a conditionally classified basis. Such students will be expected to satisfactorily complete additional course work before becoming classified. Any conditions stated in the admission notification must be fulfilled within the first year and before the student can be advanced to candidacy for the degree.</br>
Students admitted in conditionally classified status may petition for classified status when course work in deficient areas has been completed, when they have satisfied the Graduation Writing Assessment Requirement (GWAR) , and when their records in classes at San José State University show sufficient promise of success in the master’s degree program.</br>

## Requirements for Advancement to Candidacy for the MS - Engineering Management
Students seeking the Master of Science in Engineering Management degree must meet the general university requirements for advancement to candidacy  as outlined in the Academic Requirements section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR) as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. Advancement to candidacy and approval of the degree program will be handled by the Graduate Advisor. All classified graduate students must apply for advancement to candidacy after completing the GWAR and a minimum of nine units of graduate work. All MS EM students are encouraged to apply for advancement to candidacy as soon as they have completed the GWAR and three graduate courses.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students choose the Plan A (Thesis) or Plan B (Project) option as their program culminating experience. The decision as to whether to embark on a thesis or project will be made by the student in consultation with the program’s assigned advisor.</br>
Plan A (Thesis)</br>
Students wishing to pursue the thesis option must begin by obtaining the approval of the MS, Engineering Management (MS EM) program director, and then secure the agreement of a qualified faculty member to serve as Chair of the thesis committee. The candidate must provide the name of the committee Chair to the MS EM Program Director prior to the beginning work on the thesis. The thesis and thesis process must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. The thesis will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
The project is the expected choice for the MS, Engineering Management candidate’s culminating experience. Students must begin the project by identifying a qualified faculty advisor, or by having one appointed by the MS EM program director. The advisor and the student mutually agree on the scope of the project. The advisor determines when the student has met agreed-upon project requirements and when the project report is acceptable for submission to the MS EM program and notifies the MS EM program director of the student’s satisfactory completion of the culminating experience requirement.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- ISE 200 - Financial Methods for Engineers 3 unit(s)</br>

- ISE 213 - Principles of Engineering Management 3 unit(s)</br>

- ISE 222 - Adv Sys Engr 3 unit(s)</br>

- ISE 250 - Leading the Six Sigma Improvement Project 3 unit(s)</br>

- ISE 251 - Managing the Lean Enterprise Improvement Program 3 unit(s) (GWAR)</br>


### Approved Electives (12 units)
Twelve units of electives selected in consultation with a graduate advisor. Students take BUS electives (a minimum of 3 units and a maximum of 6 units) and ISE electives (a minimum of 6 units and a maximum of 9 units).</br>

### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Course From:</br>

#### Plan A (Thesis)

- ISE 299 - Master’s Thesis 1-4 unit(s) (3 units required)</br>


#### Plan B (Project)

- ISE 298 - Special Problems 1-4 unit(s) (3 units required)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>