
# Marine Science, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

Moss Landing Marine Laboratories  (MLML) is the second oldest marine lab in Monterey Bay. Established in 1966, it has an international reputation for excellence in marine science research and education. The hands-on, field oriented MLML approach places students, faculty, research, and staff where discoveries are made: at the frontiers of marine science worldwide. The wealth of nearby marine resources, excellent marine facilities and operations, renowned faculty and research-based curriculum combine to make the MLML program one of the best graduate programs of its kind in the United States. MLML provides students with a cutting-edge education that prepares them for careers in marine science and oceanography, education and outreach, conservation, policy and management, and for doctoral studies. See the program website at mlml.sjsu.edu/gradprog/.</br>
For more information about the program contact the MLML graduate program coordinator at mlml-grad-program@sjsu.edu.</br>

## Admissions Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements . Applicants apply separately to the department (MLML) to obtain admission into the MS Marine Science program. See the MLML graduate program website for program application and admission requirements.</br>
Before submitting application materials, prospective students must select and contact an MLML faculty advisor(s) and consider scheduling a visit to MLML. Discussing your application with a potential faculty advisor will (1) provide you with a better understanding of what our program has to offer; (2) help you determine if the selected faculty advisor is the right academic mentor for you; (3) enable you to speak with the potential advisor about the application process; (4) allow you to speak with current students; and (5) strengthen your application and improve your chances of acceptance. </br>
For Fall admission, the MLML online program application deadline is February 1, after which applicants must also email the supplemental application materials listed below to the MLML Graduate Program Coordinator (mlml-grad-program@sjsu.edu) as a single PDF attachment by February 15.</br>
For Spring admission, the MLML online program application deadline is September 30, and applicants must also email the following supplemental application materials to the MLML Graduate Program Coordinator (mlml-grad-program@sjsu.edu) as a single PDF attachment by September 30 as well:</br>

- Statement of Purpose - detailing (at a minimum) (1) why you want to study marine science, (2) why you want to attend MLML, (3) your background in marine science, (4) your specific research interests, and (5) what long-term goals you ultimately intend to pursue by attending MLML;</br>

- CV/Resume - summarizing relevant academic and professional experience, including (1) academic background (degrees earned, GPA, relevant coursework), (2) research experience, and (3) relevant employment history, volunteer experience, and/or memberships;</br>

- Unofficial Transcripts - from all post-secondary institutions attended;</br>

- The GRE is not required.</br>

Applicants must also request to have three letters of recommendation sent to the program from people familiar with their academic and/or professional background. Letters of recommendation must be emailed directly from your recommenders as a .pdf attachment to the MLML Graduate Program Coordinator at mlml-grad-program@sjsu.edu by February 15 for Fall admission and by September 30 for Spring admission.</br>
These application instructions can also be found at Applying to the MLML Master’s Program.</br>
Applicants may be admitted either as conditional or classified. Conditionally admitted applicants will have some condition(s), such as completion of additional coursework, placed upon their admission into the MLML program; classified students are admitted into the program without any such condition(s).</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirement  webpage.</br>

## Requirements for Advancement to Candidacy
SJSU university requirements for advancement to candidacy  for the master’s degree are outlined in the Graduate Policies and Procedures  section.</br>
Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
The MLML program requirements for Advancing to Candidacy are as follows:</br>

- Completion of the majority of coursework with the exception of the Culminating Experience course MS 299 - Master’s Thesis  </br>

- Acquired thesis proposal approval from the entire thesis committee</br>

- Acquired research permitting approval (if applicable)</br>

CSU policy requires that English competency shall be a requirement of classified graduate students as a condition necessary for advancement to candidacy for the award of a master’s degree. MLML students satisfy this requirement by earning a grade of B or better in one of the five core marine science courses.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Marine Science MS Graduation Requirements
Graduate students shall successfully complete 30 units of course work with a grade of “B” or better in each course, a thesis project, and an oral research defense to qualify for the M.S. degree in Marine Science at Moss Landing Marine Laboratories.</br>
All students shall maintain continuous enrollment in the MLML graduate program until all degree requirements are met. All students shall complete core courses with a grade of “B” or better. If a student receives lower than a “B” in a core course, the student may either retake this course or take another core course to fulfill the core course degree requirement. If a student receives lower than a “B” in a non-core class, the student may either retake the course or take another course to use towards the 30-unit requirement. Students may enroll in MS 297 , while they are conducting their research. Students are eligible to use 5-unit of MS 297  toward their Elective Coursework requirement. Students are encouraged to complete their degree requirements within three years.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan A (Thesis)</br>
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee, and must meet the academic standards of the MLML program. The candidate for the MS in Marine Science at MLML must also successfully pass a final oral defense of the thesis, in the form of a seminar open to the public, with the thesis committee evaluating the success of the presentation.</br>

## Master’s Requirements (30 units)

### Core (18 units)

- Complete three marine science core courses from:</br>

Complete three marine science core courses from:</br>

- MS 203 - Advanced Marine Ecology 4 unit(s) (GWAR)</br>

- MS 241 - Advanced Geological Oceanography 4 unit(s) (GWAR)</br>

- MS 242 - Advanced Physical Oceanography 4 unit(s) (GWAR)</br>

- MS 243 - Advanced Chemical Oceanography 4 unit(s) (GWAR)</br>

- MS 244 - Advanced Biological Oceanography 4 unit(s)</br>

-  

Complete one data analysis course from:</br>
 </br>
Complete one data analysis course from:</br>

- MS 204 - Sampling and Experimental Design 4 unit(s)</br>

- MS 263 - Data Analysis in Marine Science 4 unit(s)</br>

-  

Complete at least 2 units of the variable topic seminar:</br>
 </br>
Complete at least 2 units of the variable topic seminar:</br>

- MS 285 - Graduate Seminar in Marine Science 2 unit(s)</br>


### Elective Courses (11 units)

-  Complete additional 200- or 100-level Elective Courses selected in consultation with the graduate advisor to meet the 30 units degree requirements </br>

Complete additional 200- or 100-level Elective Courses selected in consultation with the graduate advisor to meet the 30 units degree requirements</br>

- MS 285 - Graduate Seminar in Marine Science 2 unit(s) (Variable topic seminar may be taken up to two times total)</br>

- MS 297 - Graduate Research in Marine Science 1 unit(s) (May be taken for up to 5 units)</br>


### Culminating Experience (1 unit)
Program departments are required to certify when Plan A has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Plan A (Thesis)</br>

- MS 299 - Master’s Thesis 1-4 unit(s) (1 unit required)</br>

- Thesis Defense 0 unit(s)</br>


## Total Units Required (30 units)
Advanced Coursework must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>