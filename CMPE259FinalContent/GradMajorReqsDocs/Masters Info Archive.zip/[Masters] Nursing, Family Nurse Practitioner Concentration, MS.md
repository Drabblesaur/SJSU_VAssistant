
# Nursing, Family Nurse Practitioner Concentration, MS
 </br>
FNP MS Program Coordinator and Advisor: Jennifer Aldred.</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (40 units)</br>

- Program Learning Outcomes </br>

The Master of Science - Family Nurse Practitioner (FNP) Program is designed to prepare registered nurses for advanced practice roles in primary care. This program equips nurses with the clinical expertise, leadership skills, and evidence-based knowledge necessary to provide comprehensive healthcare to individuals and families across the lifespan. Graduates will be prepared to assess, diagnose, and manage acute and chronic conditions while promoting health and disease prevention</br>
This hybrid program integrates both synchronous and asynchronous online coursework with in-person intensive sessions at San José State University. Didactic courses include self-directed learning components (asynchronous) and scheduled live virtual class meetings (synchronous) to enhance engagement with course materials. In-person intensive sessions provide essential hands-on training, faculty interaction, and peer collaboration.</br>
Students are assigned clinical preceptors throughout the Bay Area to support their training. Students complete a minimum of 540 direct patient care hours, distributed over three semesters (summer, fall, spring), providing hands-on experience in diverse healthcare settings.</br>

## Requirements for Advancement to Graduate Candidacy
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR) as a condition for advancement to candidacy and for conversion from conditional to classified standing. Advancement to candidacy for the MS - Nursing program also requires that the candidate must have:</br>

- Earned at least a “B” (3.0) average in a minimum of 9 letter-graded semester units of 100-level and/or 200-level coursework completed while in graduate standing at San José State University and in any coursework completed while in graduate standing at other institutions before enrollment here.</br>

- Classified standing.</br>

- MSN Project Plan approved by the Nursing Graduate Coordinator.</br>


### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS - Nursing, Concentration FNP Graduation Requirements

#### Culminating Experience: Project
Candidates for the degree complete a written capstone project over two semesters as part of their 40-unit regular degree requirement. This project is an investigation of an evidenced-based nursing topic.  It shall identify a clinical problem and question(s), state the major theoretical perspectives, explain the significance of the undertaking, relate it to relevant, scholarly and professional literature, set forth the appropriate sources for and methods of gathering and analyzing the data, and offer a conclusion or recommendation.</br>

#### Completion of Clinical Hours: Practice
All students are required to complete a minimum of 540 supervised direct patient care hours.</br>

#### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (40 units)

### Core Courses (19 units)

- NURS 200 - Population Based Health Care Systems 3 unit(s)</br>

- NURS 202 - Theoretical Foundations 2 unit(s)</br>

- NURS 248 - Advanced Health Assessment 3 unit(s)</br>

- NURS 258 - Professional Issues for Nurse Practitioners 2 unit(s)</br>

- NURS 259 - Advanced Clinical Pharmacology 3 unit(s)</br>

- NURS 260 - Advanced Physiology and Pathophysiology for Advanced Practice Nursing 3 unit(s)</br>

- NURS 295A - Research Methods 3 unit(s) (GWAR)</br>


### FNP Concentration (18 units)

- NURS 250 - Family Nurse Practitioner Concepts and Theory I 2 unit(s)</br>

- NURS 251 - Family Nurse Practitioner (FNP) Concepts and Theory II 2 unit(s)</br>

- NURS 252A - Family Nurse Practitioner (FNP) Concepts and Theory III 2 unit(s)</br>

- NURS 253 - Family Nurse Practitioner Practicum I 2 unit(s)</br>

- NURS 254 - Family Nurse Practitioner Practicum II 5 unit(s)</br>

- NURS 256 - Family Nurse Practitioner Practicum III 5 unit(s)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- ​NURS 297 - Master’s Project  1-4 unit(s)</br>


## Total Units Required (40 units)
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>