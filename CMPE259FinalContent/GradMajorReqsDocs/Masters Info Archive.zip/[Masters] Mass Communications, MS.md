
# Mass Communications, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The School of Journalism and Mass Communications  offers a 30-unit, four-semester Master of Science in Mass Communications degree program that culminates with a professional standard project. The curriculum was designed to help students master the concepts and skills that are driving emerging communication technologies in public relations, advertising, and journalism. Elective units allow students to tailor the program to their interests.</br>
Information about the Master of Science in Mass Communications is available on the website of the School of Journalism and Mass Communications website.</br>

## Admission Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system at calstate.edu/apply and meet all the university admission requirements. Applications meeting university graduate admission standards will be reviewed by the School of Journalism and Mass Communications. See the Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. </br>

### Requirements for Admission to Classified Standing
The School admits students in the fall semester only. Applicants are responsible for obtaining information on admissions criteria and deadlines from the JMC School Graduate Coordinator or the main school office.</br>
To be admitted to the program a prospective student must:</br>

- Complete an application for admission to the university, submit required transcripts and pay the required application fees.</br>

- Complete a 250-500 word essay on the applicant’s career objectives and upload it on the same application site as above.</br>

- Obtain two letters of recommendation from current or former professors and/or employers who can testify to the candidate’s ability to pursue an advanced academic degree. These letters should be sent directly to the Graduate Coordinator of the program. At least one recommendation letter must be from a current or former professor unless the applicant has not taken any courses during the previous five years.</br>

- Foreign students must score at least 600 on the TOEFL (90 on the iBT) and must demonstrate English proficiency in a written essay.</br>

- Grade point averages are given considerable weight in evaluating applications, but are not the sole criterion. An applicant should have an average of 3.0 or better (3.3 for foreign students) in the last two years of undergraduate study and the undergraduate major. Exceptions may be made for applicants if the candidate has had significant professional experience in the mass media, offers strong letters of recommendation or other evidence indicating a potential for success in graduate study.</br>

Applicants must meet requirements for graduate admission; however, no particular specialization in undergraduate work is required of a candidate.</br>

## Requirements for Advancement to Candidacy
To be advanced to candidacy  for the Master of Science degree, a student must first meet all university requirements for the degree as stated in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. That requirement is met by taking MCOM 210  (a required course in the program).</br>
The student must demonstrate an aptitude for advanced work in communications, as measured by instructor appraisals, evaluation of previous academic work, recommendations by qualified professionals, or other assessments.</br>
The student will meet with the graduate coordinator to develop a formal course of study. The MS degree-approved program will be individually designed to meet the specific objectives of each student. It will take into consideration the nature of previous undergraduate work and post-graduate work completed, as well as any professional and related occupational experience. The proposed graduate course of study must be approved by the graduate coordinator before the student may be considered a candidate for the MS, Mass Communications.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
In consultation with the department graduate coordinator, the candidate will develop and pursue a program of study. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approval Program.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
All students in this program follow Plan B (Project) for their culminating experience.</br>
Plan B (Project)</br>
Plan B requires the successful completion of a professionally-oriented project employing multiple media and an oral presentation to a faculty-student audience. Projects should reflect the values of journalism, advertising, or public relations. Projects are designed and completed in a two-semester sequence.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- MCOM 210 - Media and Social Issues 3 unit(s) (GWAR)</br>

- MCOM 215 - New Media Visionaries 3 unit(s)</br>

- MCOM 284 - Advanced User Experience 3 unit(s)</br>

- MCOM 285 - Web Design and Development 3 unit(s)</br>

- MCOM 295 - Mass Communications Research 3 unit(s)</br>


### Electives (9 units)
Nine units of electives approved by graduate advisor. 100- or 200-level courses in the School or other departments, related to the candidate’s career objective and culminating experience topic.</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Plan B (Project)</br>
Students take 3 units of MCOM 298A  and MCOM 298B  in consecutive semesters.</br>

- MCOM 298A - Master’s Project I 3 unit(s)</br>

- MCOM 298B - Master’s Project II 3 unit(s)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>