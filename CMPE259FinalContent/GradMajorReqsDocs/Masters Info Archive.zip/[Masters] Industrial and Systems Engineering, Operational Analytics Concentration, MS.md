
# Industrial and Systems Engineering, Operational Analytics Concentration, MS
 </br>

- Admissions</br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Industrial and Systems Engineering Department  at SJSU administers the Master of Science in Industrial and Systems Engineering (MS ISE) degree program with a concentration in Operational Analytics. This program provides students with competency in data analytics methods along with fundamental knowledge in industrial and systems engineering through coursework and a culminating project. The students take 6 core courses, and 3 electives. The program culminates in a thesis or project. Additional information can be found on the MS ISE website.</br>

## Admissions
Applicants must submit a complete graduate application through the CSU Cal State Apply portal to MS ISE - Operational Analytics program and meet all the university admission requirements. See the Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.  </br>
Applicants from countries in which the native language is not English must achieve a minimum English language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the English Language Proficiency Requirement  section in this Catalog. </br>
Admissions to the MS ISE Operational Analytics Concentration will require the same departmental requirements as the MS ISE program which are listed as follows: </br>
1. A bachelor’s degree in Industrial or Systems Engineering from an ABET-accredited University; OR
2. A bachelor’s degree in Engineering or Mathematical Sciences (including Mathematics, Statistics, and Computer Science) plus ISE courses specified by the Graduate Advisor to prepare for graduate work in the Department; OR
3. A bachelor’s degree in Natural Sciences plus ISE and MATH courses specified by the Graduate Advisor to prepare for graduate work in the Department.</br>

## Requirements for Admission to Classified Standing
Applicants must meet all university admissions requirements. Applicants who meet the following requirements beyond university requirements will be considered for admission into the ISE Department. Applicants for classified standing will ordinarily be expected to have completed work for the BS degree in industrial engineering (or its equivalent) at San Jose State University or at another university with an accredited curriculum, with a grade point average of 3.0 (B) or better in the upper division work.</br>

## Requirements for Admission to Conditionally Classified Standing
If the student’s preparation for advanced graduate work is inadequate, they may be admitted with conditionally classified standing, and be required to take the necessary preparatory courses to become classified. Such courses will not ordinarily count towards the Master’s degree program requirements.  </br>
Students who are admitted on a conditionally classified basis may complete a “Change of Classification in Graduate’s Program” petition immediately upon completion of specified conditions. While in the conditionally classified standing, the student can take graduate ISE courses that do not require any prerequisites that have not yet been completed. </br>

## Requirements for Advancement to Graduate Candidacy
Students seeking the Master of Science degree in Industrial and Systems Engineering concentration in  Operational Analytics must meet the general university requirements for advancement to candidacy  as outlined in the  Academic Requirements section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR) as a condition for advancement to candidacy. Please refer to the SJSU catalog section titled “Graduation Writing Assessment Requirement ” for details. Courses that satisfy the GWAR are listed in the course requirements for the program. Advancement to candidacy and approval of programs will be handled by the student’s graduate advisor.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Culminating Experience
Students choose either Plan A (Thesis) or Plan B (Project) option as their program culminating experience. The decision to embark on a thesis or project will be made by the student in consultation with the program’s assigned advisor.</br>
Plan A (Thesis)</br>
Students wishing to pursue the thesis option must begin by obtaining the approval of the MS ISE program Director, and then secure the agreement of a qualified faculty member to serve as chair of the thesis committee. The candidate must provide the name of the committee chair to the MS ISE Program Director prior to working on the thesis. The thesis and thesis process must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. The thesis will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
It is expected that most students will choose the Plan B (Project) option as the MS ISE culminating experience. Students must begin the project by identifying a qualified faculty advisor, or by having one appointed by the MS ISE Operational Analytics Program Director. The advisor and the student mutually agree on the scope of the project. The advisor determines whether the student has met agreed upon project requirements and when the project report is acceptable for submission to the MS ISE Operational Analytics concentration, and notifies the program director of the student’s satisfactory completion of the culminating experience requirement.</br>

### Course Requirements
Students must maintain a GPA of 3.0 or above in all courses taken in fulfilling prerequisites and the 30 graduate units required for completion of the program. The general requirements for the course completion are as follows:</br>

## Master’s Requirements (30 units)

### Core Courses (18 units)

- ISE 202 - Design and Analysis of Engineering Experiments 3 unit(s) (GWAR)</br>

- ISE 205 - Data Ethics 3 unit(s)</br>

- ISE 230 - Advanced Operations Research 3 unit(s)</br>

- ISE 233 - Operational Data Analysis for Industrial Systems 3 unit(s)</br>

- ISE 240 - Analytics for Systems Engineering 3 unit(s)</br>

- ISE 244 - AI Tools and Practice for Systems Engineering 3 unit(s)</br>


### Approved Electives (9 units)
Complete 3 courses. Elective courses must be planned in consultation with the graduate advisor.</br>

- ISE 234 - Electricity Markets & Power Systems Analytics 3 unit(s)</br>

- ISE 235 - Quality Assurance and Reliability 3 unit(s)</br>

- ISE 241 - Advanced Operations Planning and Control 3 unit(s)</br>

- ISE 243 - Advanced Supply Chain Analytics 3 unit(s)</br>

- ISE 245 - Advanced Supply Chain Engineering 3 unit(s)</br>

- ISE 247 - Logistics for Supply Chain 3 unit(s)</br>

- ISE 265 - Advanced System Simulation 3 unit(s)</br>


## Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one option (Plan A Thesis or Plan B Project).</br>

### Plan A (Thesis)

- ISE 299 - Master’s Thesis 1-4 unit(s)  (3 units required)</br>


### Plan B (Project)

- ISE 298 - Special Problems 1-4 unit(s)  (3 units required)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>