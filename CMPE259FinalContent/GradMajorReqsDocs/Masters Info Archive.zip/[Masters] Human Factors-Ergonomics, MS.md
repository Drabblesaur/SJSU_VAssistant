
# Human Factors/Ergonomics, MS
 </br>

- Admission Requirements</br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy for the MS - Human Factors/Ergonomics</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Department of Industrial and Systems Engineering  administers the Master of Science in Human Factors/Ergonomics (HF/E) degree program. This is a cooperative program involving the Departments of Industrial and Systems Engineering, Psychology, Industrial Design, and Kinesiology.</br>
Human factors/ergonomics is the discipline concerned with the development and application of human-system interface technology to systems analysis, design, and evaluation. This technology encompasses human-machine (hardware ergonomics), human-task (workplace ergonomics), human-environment (environmental ergonomics), human-software (cognitive ergonomics) and organizational-machine (macro-ergonomics) interfaces. Practitioners are engaged in developing design specifications, guidelines, methods, and tools. They also apply human-system interface technology to ensure that work systems are compatible with the characteristics of the humans who operate, maintain, or otherwise interact with them. Their efforts include improving the operability, maintainability, usability, comfort, safety and health characteristics of systems to improve human and system effectiveness and to reproduce the potential of injury and error (adapted from remarks published by H. Holbrook, 1995-96 President, Human Factors and Ergonomics Society, HFES Bulletin, January 1996).</br>
This program prepares students for practice in this emerging profession through an interdisciplinary course sequence that emphasizes theory, practical applications, and research. HF/E students take a group of five core courses from several different SJSU departments and elective courses in topics of their choosing. A one-semester weekly seminar is required of all students. The program culminates in a thesis or project.</br>
Additional information can be found on the Human Factors/Ergonomics Program website.</br>

## Admission Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the MS, Human Factors/Ergonomics program. See the Graduate Admissions website and this Catalog for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the English Language Proficiency Requirement  section in this catalog.</br>

## Requirements for Admission to Classified Standing
Applicants must meet all university admission requirements . Applicants who meet the following requirements beyond university requirements will be considered for admission into the ISE Department. Applicants for classified standing must have completed a BS or BA degree in Psychology, Industrial Engineering, Occupational Therapy, Industrial Design, Kinesiology, or other related fields at an accredited institution. A grade point average of 3.0 (“B”) or better in the last two years of academic work is preferred. Applicants for classified standing will also be expected to have completed upper-division courses in statistics, cognition, and perception.</br>

## Requirements for Admission to Conditionally Classified Standing
Applicants who do not meet the requirements for classified standing may be admitted with specific conditions as conditionally classified; any conditions stated in the admission notification must be fulfilled within the first year and before the student can be advanced to candidacy for the degree. If the conditions are not fulfilled, the program reserves the right to dismiss the student from the program by a process known as Administrative Academic Disqualification (see Section 41300.1, Title 5, California Code of Regulations).</br>

## Requirements for Advancement to Candidacy for the MS - Human Factors/Ergonomics
Students seeking the Master of Science degree in Human Factors/Ergonomics must meet the general all-university requirements for candidacy as outlined in the Academic Requirements section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, the applicant must demonstrate an aptitude for advanced professional work in human factors/ergonomics, as measured by instructor appraisals, analysis of previous academic work, or other appropriate means. Advancement to candidacy and approval of programs will be handled by the student’s graduate advisor.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must satisfy the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
The decision as to whether to embark on the project (Option B) or Thesis (Option A) path for the culminating experience will be made by the student in consultation with the program’s assigned advisor.</br>
Plan A (Thesis)</br>
Students wishing to pursue the thesis option must begin by obtaining the approval of the HF/E program Director and then by securing the agreement of a qualified faculty member to serve as Chair of the candidate’s thesis committee. The name of the committee Chair must be provided to the HF/E program Director prior to the candidate beginning work on the thesis. The thesis and thesis process must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Plan B (Project)</br>
The project is the expected choice for the HF/E candidate’s culminating experience. Students must begin the project by identifying a qualified faculty advisor, or one will be appointed by the HF/E Program Director. The advisor and the student mutually agree on the project’s scope. The advisor determines when the student has met the agreed-upon project requirements and when the project report is acceptable for submittal to the HF/E program, and notifies the HF/E program Director of the student’s satisfactory completion of the requirement.</br>
Three (3) elective courses must be planned in consultation with the Graduate Advisor. Electives may be selected from a wide range of graduate courses offered on the SJSU campus in industrial engineering, psychology, kinesiology, and other departments. Course descriptions can be found under the listings for the respective departments elsewhere in this catalog. The program develops and offers its own elective courses from time to time in topics such as usability testing, human-computer interaction, safety, and others. Please see the program website for further details.</br>

### Course Requirements
Students must maintain a GPA of 3.0 or above in all courses taken in fulfilling prerequisites and the 30 graduate units required for completion of the program. The general requirements for the course completion are as follows:</br>

## Master’s Requirements (30 units)

### Core Courses (17 units)

- ISE 210 - Human Factors/Ergonomics 3 unit(s)</br>

- ISE 212 - Human Factors Experiments 3 unit(s) (GWAR)</br>

- ISE 290 - Human Factors & Ergonomics Professional Seminar 2 unit(s)</br>

- KIN 266 - Principles and Concepts of Perceptual Motor Learning 3 unit(s)</br>

- PSYC 273 - Seminar in Human Factors 3 unit(s)</br>


#### Complete One Course From:

- ISE 135 - Design of Experiments 3 unit(s)</br>

- ISE 202 - Design and Analysis of Engineering Experiments 3 unit(s)</br>

- ISE 211 - Experiment Design for Human Factors Engr 3 unit(s)</br>


### Approved Electives (9 units)
Elective courses must be planned in consultation with the graduate advisor</br>

### Culminating Experience (4 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Plan A (Thesis) or Plan B (Project)</br>
Complete four units from:</br>

- ISE 298 - Special Problems 1-4 unit(s)</br>

- PSYC 298 - Special Problems 1-6 unit(s)</br>

- KIN 298 - Special Studies 3 unit(s)</br>

- ISE 299 - Master’s Thesis 1-4 unit(s)</br>

- PSYC 299 - Master’s Thesis 1-6 unit(s)</br>

- KIN 299 - Master’s Thesis 1-6 unit(s)</br>


## Total Units Required (30 units)
 </br>