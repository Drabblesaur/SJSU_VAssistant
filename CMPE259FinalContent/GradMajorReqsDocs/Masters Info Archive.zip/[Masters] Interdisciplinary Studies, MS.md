
# Interdisciplinary Studies, MS
 </br>

- Overview</br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>


## Overview
The Interdisciplinary Studies master’s program for either an MA or MS provides an alternative for individuals whose desired plan of study does not fit into the degree offerings of any single existing graduate degree program on campus.</br>
More information about the program can be found on the College of Graduate Studies  website at www.sjsu.edu/cgs.</br>

## Admissions Requirements
Candidates apply separately to the university to obtain approval for university-level admission and to the College of Graduate Studies for admission to the Interdisciplinary Studies program. Candidates must meet all university admission requirements . They must also satisfy programmatic requirements, including a minimum 3.25 GPA in the last 60 semester units of post-secondary academic work.</br>
The student must then complete, sign, and route the DocuSign PowerForm: Information and Application for Interdisciplinary Studies Majors. In brief, the application includes the signature of a tenured or tenure-track faculty member from San Jose State who agrees to chair the master’s committee of the student. Approval of the proposed curriculum, periodic advice, and supervision of the student’s research and culminating experience are required of the faculty mentor. A summary of the proposed research and reasons for the appropriateness of the Interdisciplinary Studies program are also needed in advance of a positive admissions decision.</br>
Finally, all coursework listed in the program of study must receive documented permission from the department(s) offering the courses to enroll. Once the application is completed, the application is routed to the applicant’s advisor and the College of Graduate Studies Graduate Program Coordinator (Dr. Ted Butryn) who will make the final admissions decision. A copy will be sent to the Associate Dean (AD) of Graduate Studies. Please be sure to use proper email addresses for both your proposed program advisor and Dr. Butryn so that the form is reviewed and approved.</br>
Applicants from countries in which the official language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE.</br>

## Requirements for Advancement to Graduate Candidacy
General university requirements for advancement to candidacy  for the Interdisciplinary Studies master’s degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MA or MS - Interdisciplinary Studies Graduation Requirements
The program consists of an individualized program of 30 units in classes taken from at least two different departments; a minimum of half of the units must be in graduate-level classes. Prerequisite classes must be taken in excess of the 30 unit total. The program may be Plan A (thesis), Plan B (project, but under highly restricted circumstances), or Plan C (creative project). All courses must be approved by the AD of Graduate Studies. The culminating experience must be approved by the student’s master’s program advisor. </br>
Program departments are required to certify when Plan A, Plan B or Plan C has been completed satisfactorily via the Verification of Culminating Experience form.</br>
 </br>