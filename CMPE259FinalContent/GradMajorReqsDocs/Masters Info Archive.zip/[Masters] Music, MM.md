
# Music, MM
 </br>

- Admission Requirements</br>

- Advancement to Candidacy</br>

- University Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Music graduate program in the School of Music  offers training for careers in performance, conducting, composition, research, and teaching. We also provide preparation for further advanced study in ten distinct areas:</br>

- Composition</br>

- Choral conducting</br>

- Instrumental conducting</br>

- Instrumental performance</br>

- Jazz studies</br>

- Keyboard studies</br>

- Music education</br>

- Music history</br>

- Vocal performance</br>

Our MM, Music degree program is a 30-unit course of study, typically taken in four semesters over two years, and consists of graduate seminars, one-on-one private lessons, performance ensembles, and area of specialization coursework. The program culminates with the master’s exam and the completion of a graduate recital, project, thesis, or music composition.</br>
Additional information is available in the School of Music Office and at the department website.</br>

## Admission Requirements

### University Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements . Applicants apply separately to the department to obtain admission into the MM, Music program. See Graduate Admissions website and this Catalog for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the Policies and Procedures  section, Graduate and Post-Baccalaureate Information .</br>

### Program Requirements
Students need to apply separately to the university to obtain approval for university-level admission and to the department to obtain admission into the Master of Music Program. All required transcripts and supporting documents should be sent directly to the university. The School of Music  graduate program requires applicants to:</br>

- Have a bachelor’s degree in Music from a regionally accredited institution;</br>

- Be in good academic standing at the last college or university attended;</br>

- Have a minimum GPA of 3.00 in the last 60 units of undergraduate coursework;</br>

- Students from a country where the official language is not English are required to submit a TOEFL (Test of English as a Foreign Language), PTE (Pearson Test of English), or International English Language Testing System (IELTS) score. The minimum entrance score for the TOEFL is 590 (paper-based), 243 (computer-based), or 96 (internet-based), with a score of 5 in the Writing Section. The minimum score for the PTE is 68; for the IELTS, the minimum score is 7.0. All test scores must be less than 2 years old. Test scores must be sent directly from the Educational Testing Service office (institution code 4687), Pearson Office, or IELTS office directly to SJSU.</br>

- Audition, Portfolio, Interview


Conducting and Performance: a live (preferred) or unedited recorded audition is required for conducting and performance specializations. Please see the School of Music website for specific requirements of individual performance areas.
Composition, Education, History, Systems/Theory: the submission of a portfolio of work is required for all academic specializations. Please see the School of Music website for specific requirements of individual academic areas.
Individual areas may also require an interview.

</br>

- Conducting and Performance: a live (preferred) or unedited recorded audition is required for conducting and performance specializations. Please see the School of Music website for specific requirements of individual performance areas.</br>

- Composition, Education, History, Systems/Theory: the submission of a portfolio of work is required for all academic specializations. Please see the School of Music website for specific requirements of individual academic areas.</br>

- Individual areas may also require an interview.</br>

- Submit three letters of recommendation addressing the applicant’s potential for graduate-level work in music to be sent to the appropriate performance area advisor.</br>

The School of Music  does not require the GRE (Graduate Record Exam).</br>

### Admission to Classified Standing
Graduate students admitted to the School of Music are usually admitted in “conditionally classified” status. This status is normal for all entering graduate students, who must demonstrate a bachelor’s level competence in music history and music theory by passing the Graduate Entrance Evaluations given during Pre-Instruction before the start of the fall semester. Students who pass their Entrance Evaluations may then become “graduate classified” and are eligible to take all 200-level graduate seminars after completing MUSC 200 . Students who fail one or more portions of the Evaluation will remain conditionally classified and will be required to remediate with the appropriate coursework before taking graduate seminars beyond MUSC 200 . Coursework taken as remediation is not applied to the Master’s degree requirement units. Students who fail the entire Entrance Evaluation will not be admitted into the program. Please see the “Graduate Program Test Requirements” for more information</br>

## Advancement to Candidacy
Candidacy denotes that the student is fully qualified to complete the final stages of the MM. In order to achieve candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the Master’s degree are detailed in the Graduate Policies and Procedures  section. Advancement to candidacy requires that the student be in good standing with a 3.0 GPA or better in a minimum of 9 units of letter-graded coursework as a graduate student in 100- or 200-level courses in the degree program as indicated by all courses on the Petition for Advancement to Graduate Candidacy. These courses must conform to university and departmental requirements, and the area and graduate advisors must approve the proposed program. The proposed program must list a total of 30 semester units, including the appropriate number of “core” courses, area of specialization courses, required ensembles, and supervised graduate study.</br>
The student must be “graduate classified” and have met and cleared their conditions for admission to the program indicated by their results in the Graduate Entrance Evaluation in music history and music systems/theory. Candidacy also includes successful completion of the Graduation Writing Assessment Requirement (GWAR) , which in the School of Music is MUSC 200 .</br>

## University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . All students must satisfy Graduation Writing Assessment Requirement (GWAR)  and culminating experience as outlined in the degree requirements.</br>

### Program Requirements
The Music master’s degree is based on 12 units of four “core” graduate seminars, beginning with MUSC 200 , and 12 units of area courses and ensembles. Students with the academic specializations (Plan A), 6 units of thesis/composition supervision are taken in preparation for completing a thesis or composition. Students in performance specializations (Plan B), 6 units of private lessons with an individual teacher are taken in preparation for their master’s recital or project. All required prerequisite course work must be passed with a grade of “B” or better and a minimum 3.0 GPA must be maintained in order to continue with the graduate program. To complete the program, students take their Written Culminating Exams (WCE) in their final semester.</br>

## Master’s Requirements (30 units)

### Core Courses (12 units)

- MUSC 200 - Methods of Music Research & Writing 3 unit(s) (GWAR)</br>

- MUSC 201 - Seminar in Music History 3 unit(s)</br>

- MUSC 202 - Seminar in Music Systems & Theory 3 unit(s)</br>


#### Complete One Course From:

- MUSC 203 - Seminar in Style & Performance Practices 3 unit(s)</br>

- MUSC 220 - Seminar in Advanced Conducting 3 unit(s)</br>


### Area of Specialization (12 units)
Students must complete twelve (12) units of graduate 200-level and approved 100-level elective courses in one area of specialization. Areas of specialization include:</br>

- Composition</br>

- Music History</br>

- Music Theory</br>

- Music Education</br>

- Choral Conducting</br>

- Instrumental Conducting</br>

- Jazz Studies</br>

- Performance: Woodwinds, Brass & Percussion</br>

- Performance: Piano</br>

- Performance: Voice </br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Students choose a Plan A (Composition or Thesis) or Plan B (Project or Recital) option as their program culminating experience. All students must also successfully complete the Written Culminating Exams (WCE).</br>

#### Plan A (Composition or Thesis)
Six units are devoted to the preparation and writing of an advisor-approved thesis on a topic approved by the candidate’s major professor. Students choosing the thesis option must secure the commitment of three faculty members of the university, two of whom must be members of the permanent faculty, to serve as members of the student’s Plan A (Composition or Thesis) committee, with one permanent faculty member agreeing to serve as chair. After final approval by the major advisor and thesis committee members, the thesis is submitted to Graduate Studies. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines.</br>

- MUSC 224 - Supervised Graduate Study 1-2 unit(s) (0-4 units requires)</br>

- MUSC 299 - Master’s Thesis 1-3 unit(s) (2-6 units required)</br>

- Written Culminating Exam 0 unit(s)</br>


#### Plan B (Project or Recital)
Six units are devoted to the preparation and production of a written project.</br>

- MUSC 224 - Supervised Graduate Study 1-2 unit(s) (2 units in each of three semesters)</br>

- Written Culminating Exam 0 unit(s)</br>


#### Written Culminating Exam (WCE)
At the end of their studies, all Music, MM students must demonstrate their thorough grasp of their field of specialization, music history, and music theory through the Written Culminating Exams (WCE). Students must pass all sections of the examination to be awarded their master’s degrees. The examination consists of three essay questions, which will concern subjects in:</br>

- the student’s major field (piano, composition, etc.);</br>

- the information covered in the student’s MUSC 201  history class; and,</br>

- the information covered in the student’s MUSC 202  theory class.</br>

The essay questions will be written by the major instructor and by the professors who taught the student MUSC 201 and MUSC 202 . The examination will be given in the middle of the semester. If students are enrolled in MUSC 201  and/or MUSC 202  during their last semester, the essay question(s) will cover the material covered in class to that date. Students have two weeks to complete the examination, which is open book. Students are required to research their topics but cannot work with other students or any other persons on their examination. Each essay must represent only the student’s work, and students must sign a declaration on the cover sheet that the essays represent only their own research and writing. Each essay must be 4-6 pages in length, typed, and double-spaced. Footnotes must be used in the correct format to identify all sources. Failure to demonstrate knowledge of correct bibliographic citation will result in a failure in the examination. Students will be notified two weeks after the examinations are turned in if they have passed or failed. If the student fails, the examination may be retaken one time upon consultation with the Graduate Advisor. The examinations will be filed in the student’s School file.</br>
It is the student’s responsibility to inform the Graduate Advisor at the beginning of his or her last semester that he or she needs to take the WCE that semester. The Graduate Advisor will ask for the names of the three professors who will be writing the examination questions, and will assign the dates for the examination. The Graduate Advisor will request the essay questions from your professors and give you the examination on the appointed date.</br>

## Total Units Required (30 units)
Elective courses must be planned in consultation with the Area Coordinator and the School of Music Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and an SJSU Cumulative grade point average of 3.0 in order to graduate.</br>
 </br>