
# Art, Pictorial Art Concentration, MFA
 </br>

- Step I. Admission to MFA Classified Standing</br>

- MFA - Art Advancement to Candidacy</br>

- MFA - Art Completing Requirements</br>

- Master’s Requirements (60 units)</br>

- Program Learning Outcomes  </br>


## Step I. Admission to MFA Classified Standing
Applicants must meet university requirements  for admission to classified standing as outlined in this catalog. In addition, they must meet the following requirements:</br>

- Demonstrated interest in the area of study by a professional portfolio. The equivalent to a Bachelor of Fine Art (BFA) degree in the applicant’s designated area of graduate emphasis is recommended. At least 6 upper-division units in art history are required.</br>

- Successful completion of the application procedure for the MFA Admission Review. During the MFA Admission Review, appropriate materials documenting the applicant’s creative work are examined by the art faculty to determine whether the quality of the work meets the standards expected for MFA graduate work. Applicants should submit copies of their creative materials for the MFA Admission Review; applicants should not submit their original materials unless requested to do so by the faculty. Applicants who pass the review and who meet minimum school and university requirements are admitted to classified standing for the following semester.</br>

Applicants for the MFA Admission Review will be considered only if the review instructions have been carefully followed and all requested materials (including official transcripts) are supplied. For details, email or call the Department of Art and Art History  at art@sjsu.edu or 408-924-4320. All materials should be submitted with the application to SJSU prior to the university’s deadline.</br>

### Admission to Conditionally Classified Status
Applicants who meet the University’s minimum requirements for graduate admission and whose creative work, as examined during the MFA Admission Review, shows promise but is not supported by traditional undergraduate preparation in Art may be admitted to conditionally classified status and provided with a list of requirements to be addressed as soon as they enroll. They will be advanced to classified status when the art graduate advisor certifies all appropriate requirements for classified standing have been satisfied. Applicants who have completed an MA - Art degree must meet all prerequisites and requirements for the MFA - Art degree program.</br>

## MFA - Art Advancement to Candidacy
Candidacy denotes that the classified graduate student is fully qualified to complete the final stages of the MFA - Art program and is thus eligible to enroll in ART 298A - MFA Project Planning Seminar  and ART 298B - MFA Project . In order to attain candidacy, the student must meet the university requirements for advancement to candidacy  as outlined in this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program. In addition, the student must:</br>

- Formalize their MFA project committee by obtaining the signatures of at least three university faculty members (two must be members of the art faculty) to serve as members of the student’s committee. A regular art faculty member who teaches in the student’s major area of emphasis must serve as chair. This committee must approve the student’s proposed program of study for the MFA - Art degree no later than one month prior to the end of the semester preceding the one in which the final project is created.</br>

- The student must submit a proposed program of study conforming to university and school requirements on the Petition for Advancement to Candidacy form and filed according to university deadlines. The proposed program of study must be approved by the art graduate committee and the College of Graduate Studies before the student may be considered for the MFA - Art.</br>

- Pass the Advancement to Candidacy (ATC) Review. This is an exhibition of original work that can be scheduled during any semester in one of the department’s student galleries. Students must obtain signatures of two faculty members willing to serve on their culminating project committee, including at least one faculty member teaching in the designated area of emphasis, in order to apply to the ATC Review. Passing the review is necessary before the student may file for the Petition for Advancement to Candidacy and enroll in their culminating project classes, ART 298A  and ART 298B .</br>

Additional information regarding advancement to candidacy is available in the Art & Art History Department Office.</br>

## MFA - Art Completing Requirements

- General Requirements: The MFA - Art program requires a minimum of 60 units of approved courses completed after admission to classified status in the program, of which at least 30 units must be in courses at the 200 level. Electives to complete the 60 units may be drawn from approved 100 and 200 level courses. The program also requires the student to participate in regularly scheduled departmental activities such as studio visits by faculty, first-semester review, first-year review, and Advancement to Candidacy reviews.</br>

- Required Courses: see below.</br>

- All students must meet the university’s graduation writing assessment requirement.</br>

- MFA - Art Project: The culmination of the degree is the MFA - Art culminating project which must demonstrate the professional level of the candidate’s accomplishment. After advancement to candidacy, the culminating project will be developed under the guidance of the candidate’s MFA - ART project committee chair with the assistance of the project committee. Upon the committee’s prior approval of the completed work, projects will be appropriately exhibited in accordance with departmental requirements.</br>

All candidates must also submit to the Department of Art and Art History a satisfactory report of the project, following the department’s approved format. MFA project reports will document the creative project and the creative process and context for that project with color images that illustrate each work in the project. The project report and the image record (in the case of studio projects) must be approved by the candidate’s culminating project committee and by the art graduate advisor before the degree may be awarded.</br>

- Final Examination: The candidate must successfully complete an oral examination based on the area of the MFA - Art culminating project.</br>

- The application for graduation must be filed with the university Graduate Admissions and Program Evaluations (GAPE) according to the posted deadline during the semester prior to completion of degree requirements.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (60 units)

### Graduate Seminars and Critiques (12 units)
Graduate Seminars and Critiques in Area of Concentration</br>

- ART 281A - Interdisciplinary Critique & Presentation Seminar 3 unit(s) (6 units required)</br>

- ART 281B - Interdisciplinary Critique Seminar 3 unit(s) (6 units required)</br>


### Seminars (6 units)

- ART 282A - Seminar in the Theory and Criticism of Contemporary Art 3 unit(s)</br>

- ART 282B - Seminar in Contemporary Art 3 unit(s) (GWAR)</br>


### Additional Course (3 units)

- ART 174A - Museum and Gallery Operations 3 unit(s)</br>

- ART 276 - Artists Teaching Art 3 unit(s)</br>


### Upper Division Art History (6 units)

### Professional Writing Course (3 units)

- ART 200W - Professional Writing in Contemporary Art 3 unit(s) (GWAR)</br>


### Electives (24 units)

### Special Study (3 units)

- ART 298A - MFA Project Planning Seminar 3 unit(s)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- ART 298B - MFA Project 3 unit(s)</br>


## Total Units Required (60 units)
 </br>