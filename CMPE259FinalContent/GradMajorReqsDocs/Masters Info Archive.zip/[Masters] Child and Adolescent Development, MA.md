
# Child and Adolescent Development, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Arts degree in the Department of Child and Adolescent Development (ChAD)  prepares students for advanced study leading to professional careers in settings that serve children, youth, and families.</br>
Detailed information about the program can be found on the department website: https://www.sjsu.edu/chad/academics/ma-degree.php.</br>

## Admissions Requirements
Candidates apply separately to the university to obtain approval for university-level admission and to the department to obtain admission to the ChAD master’s program. Candidates must meet all the university admission requirements . Note that applicants must have an undergraduate grade point average of 3.0 (B) or better in the last 60 semester units of undergraduate work.</br>
In addition to meeting university requirements, the minimum requirement for admission to the ChAD MA program is:</br>

- a baccalaureate degree awarded by an accredited institution,</br>

- a completed department application,</br>

- three letters of recommendation,</br>

- a 1-2-page typed statement of educational and professional background and professional goals, and</br>

- an essay on various topic areas in child and adolescent development. Preference is given to candidates with a background in ChAD or a related field (e.g., Psychology, Sociology, Education, Social Work, Nursing). Applicants can be admitted either in a conditional or classified status.</br>

Applicants from countries in which the official language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE.</br>

## Requirements for Advancement to Graduate Candidacy
Students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
During the semester that the first 9 units of coursework will be completed, the ChAD MA candidate will need to submit a Departmental Request for Candidacy form [pdf]. This form must be signed by the ChAD graduate program coordinator  and submitted to GAPE by the appropriate deadline. Check the deadline for submitting the Petition for Advancement to Graduate Candidacy. Any changes made in the program degree academic plan as listed on the candidacy form need to be requested using the Request for Course Substitution in Graduate Degree Program [pdf]. This form must be signed by the ChAD graduate program coordinator prior to submission to GAPE.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MA - Child and Adolescent Development Graduation Requirements
Students are expected to complete all required courses and select three electives from the department-approved list. In order to meet degree requirements, candidates for the MA in ChAD must maintain a 3.0 GPA in all courses with no single course grade below a B-. Students who earn less than a B- in any required course (CHAD 260A , CHAD 260B , CHAD 262 , CHAD 266 , CHAD 268 , and CHAD 270 ) must retake the course and earn a grade of B- or better. For electives in which the earned grade was less than a B-, students have the option to retake the same course or to select a different elective.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing CHAD 260A .</br>

## Master’s Requirements (30 units)

### Core Courses (18 units)

- CHAD 260A - Seminar in Child and Adolescent Development: Research 3 unit(s) (GWAR)</br>

- CHAD 260B - Seminar in Child and Adolescent Development 3 unit(s)</br>

- CHAD 262 - Culture and Diversity in Child & Adolescent Development 3 unit(s)</br>

- CHAD 266 - U.S. Social Policy Affecting Children and Families 3 unit(s)</br>

- CHAD 268 - Seminar in Social and Emotional Development 3 unit(s)</br>

- CHAD 270 - Seminar in Cognitive and Language Development 3 unit(s)</br>


### Interdisciplinary Electives (9 units)
Complete three department-approved elective courses from the department-approved list. Electives may be taken at any time during the MA program. In some circumstances, MA candidates may petition to take an elective not on the list. Candidates should submit a written statement to the Graduate Program Coordinator with the course request and justification.</br>

### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B)**:</br>

#### Plan A (Thesis)

- CHAD 299 - Master’s Thesis 3-6 unit(s)</br>


#### Plan B (Project)

- CHAD 298 - Special Studies in Child and Adolescent Development 3-6 unit(s)</br>


## Total Units Required (30 units)
* Meets the Graduation Writing Assessment Requirement (GWAR). Must be taken in the first semester of enrollment.</br>
** To be completed concurrently with CHAD 260B .</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>