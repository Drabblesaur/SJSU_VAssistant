
# Art, Art History and Visual Culture Concentration, MA
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Arts in Art History and Visual Culture offers a broad education in art history including preparation for a Ph.D. degree program. It also helps to prepare students for a graduate library degree with a specialization in art history as well as a variety of positions including community college professor, researcher, museum curator, art administrator, conservator, and visual resource librarian. Two tracks allow students to specialize in either Research or Applied Practice.</br>
 </br>
Additional information is available in the Department of Art and Art History  Office and on the department website: www.sjsu.edu/art.</br>

## Admissions Requirements

### Admission to Classified Standing
Depending on their level of preparation, applicants can be admitted in either classified or conditionally classified standing. Admission requires two steps.</br>
In addition to the university admission requirements , applicants must meet requirements for their area:</br>

- 

Research in Art History and Visual Culture: completion of 30 or more college-level semester units or equivalent in Art History courses with a minimum 3.0 GPA. At least 18 units should have been in upper-division Art History courses. Courses in related academic areas will be assessed in reviewing the qualifications of applicants. Reading knowledge of a foreign language related to the subject of the intended thesis research is strongly recommended.
</br>
Research in Art History and Visual Culture: completion of 30 or more college-level semester units or equivalent in Art History courses with a minimum 3.0 GPA. At least 18 units should have been in upper-division Art History courses. Courses in related academic areas will be assessed in reviewing the qualifications of applicants. Reading knowledge of a foreign language related to the subject of the intended thesis research is strongly recommended.</br>

- 

Art Criticism and Applied Practice: completion of 30 or more college-level semester units or equivalent in Art History courses with a minimum 3.0 GPA. At least 18 units should have been in upper-division Art History courses. Courses in related academic areas will be assessed in reviewing the qualifications of applicants.
</br>
Art Criticism and Applied Practice: completion of 30 or more college-level semester units or equivalent in Art History courses with a minimum 3.0 GPA. At least 18 units should have been in upper-division Art History courses. Courses in related academic areas will be assessed in reviewing the qualifications of applicants.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>

### Admission to Conditionally Classified Standing
Applicants who meet minimum requirements for admission to the Graduate Division but do not meet all other (programmatic) requirements (i.e., lacking prerequisites or GPA) may be admitted to conditionally classified standing. They will be advanced to classified standing when the Art History graduate advisor certifies they have satisfied all appropriate requirements.</br>

## Requirements for Advancement to Graduate Candidacy
Candidacy denotes that the student is fully qualified to complete the final stages of the MA - Art and is thus eligible to enroll in  ARTH 299 - Master’s Thesis  or  ART 297B - Master’s Project . In order to advance to candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MA degree are detailed in the Graduate Policies and Procedures  section. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR) .</br>
Additional departmental requirements for candidacy include:</br>

- Secure commitment of three faculty members of the university, two of whom must be members of the Art and Art History faculty, to serve as members of the student’s MA - Art project or thesis committee, with one regular Art faculty member agreeing to serve as chair. For candidates in Art History and Visual Culture, the chair of the committee and at least one other committee member must be art historians. This committee must approve the student’s proposed program for the MA - Art degree no later than one month prior to the end of the semester preceding the one in which enrollment in the final project or thesis course(s) is planned.</br>

- Submission of a proposed curriculum program conforming to university and departmental requirements. The proposed program must be approved by the Art graduate committee before the student may be considered for the MA - Art. The proposed program must list a total of 30 semester units, of which at least 15 must be in courses at the 200 level. The proposed program must include the required seminars and  ARTH 299 - Master’s Thesis  or  ART 297B - Master’s Project . Electives to complete the 30 units may be drawn from approved 100 and 200-level courses.</br>

- Passage of the first of two comprehensive exams and the language exam.</br>


## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MA - Art Graduation Requirements
Requirements are as follows:</br>

- 

Core Course Requirements for Both Tracks: There are 3 foundation courses required for all MA Art History & Visual Culture candidates: ARTH 175 , ARTH 275 , ARTH 277 . 
</br>
Core Course Requirements for Both Tracks: There are 3 foundation courses required for all MA Art History & Visual Culture candidates: ARTH 175 , ARTH 275 , ARTH 277 . </br>

- 

Additional course requirements in the two areas or tracks are as follows:​


Research in Art History and Visual Culture: 18 Units of Upper Division Courses focusing on research methods. Students following the track in Research in Art History and Visual Culture must demonstrate reading knowledge of a foreign language related to the subject of the intended thesis research. The student must also pass a two-part comprehensive written examination designed to test general competence in Art History and Visual Culture. The second part of the exam is based on the candidate’s thesis proposal once that has been approved by a pre-thesis committee. Attainment of candidacy and eligibility to enroll in  ARTH 299 - Master’s Thesis  will be contingent upon satisfactory completion of all comprehensive and language examinations.


Art Criticism and Applied Practice: 18 Units of Upper Division Courses focusing on applied practice. Two of the upper-division courses may be taken in studio art or, with graduate advisor approval, outside of the department. The student must also pass a two-part comprehensive written examination designed to test general competence in Art History and Visual Culture. Attainment of candidacy and eligibility to enroll in ART 297B Master’s Project  will be contingent upon satisfactory completion of all comprehensive examinations. 


</br>
Additional course requirements in the two areas or tracks are as follows:​</br>

- 

Research in Art History and Visual Culture: 18 Units of Upper Division Courses focusing on research methods. Students following the track in Research in Art History and Visual Culture must demonstrate reading knowledge of a foreign language related to the subject of the intended thesis research. The student must also pass a two-part comprehensive written examination designed to test general competence in Art History and Visual Culture. The second part of the exam is based on the candidate’s thesis proposal once that has been approved by a pre-thesis committee. Attainment of candidacy and eligibility to enroll in  ARTH 299 - Master’s Thesis  will be contingent upon satisfactory completion of all comprehensive and language examinations.
</br>
Research in Art History and Visual Culture: 18 Units of Upper Division Courses focusing on research methods. Students following the track in Research in Art History and Visual Culture must demonstrate reading knowledge of a foreign language related to the subject of the intended thesis research. The student must also pass a two-part comprehensive written examination designed to test general competence in Art History and Visual Culture. The second part of the exam is based on the candidate’s thesis proposal once that has been approved by a pre-thesis committee. Attainment of candidacy and eligibility to enroll in  ARTH 299 - Master’s Thesis  will be contingent upon satisfactory completion of all comprehensive and language examinations.</br>

- 

Art Criticism and Applied Practice: 18 Units of Upper Division Courses focusing on applied practice. Two of the upper-division courses may be taken in studio art or, with graduate advisor approval, outside of the department. The student must also pass a two-part comprehensive written examination designed to test general competence in Art History and Visual Culture. Attainment of candidacy and eligibility to enroll in ART 297B Master’s Project  will be contingent upon satisfactory completion of all comprehensive examinations. 
</br>
Art Criticism and Applied Practice: 18 Units of Upper Division Courses focusing on applied practice. Two of the upper-division courses may be taken in studio art or, with graduate advisor approval, outside of the department. The student must also pass a two-part comprehensive written examination designed to test general competence in Art History and Visual Culture. Attainment of candidacy and eligibility to enroll in ART 297B Master’s Project  will be contingent upon satisfactory completion of all comprehensive examinations. </br>

### Thesis Requirements

- Research in Art History and Visual Culture:

	
Students following the track in Research in Art History and Visual Culture must develop a thesis proposal and enroll in  ARTH 299 - Master’s Thesis .

		
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.


Thesis Examination: The candidate must successfully pass a final oral examination based on the Master’s Thesis.

</br>

- Students following the track in Research in Art History and Visual Culture must develop a thesis proposal and enroll in  ARTH 299 - Master’s Thesis .


		
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.

</br>

- The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>

- Thesis Examination: The candidate must successfully pass a final oral examination based on the Master’s Thesis.</br>

- Art Criticism and Applied Practice:

	
Students following the track in Art Criticism and Applied Practice must develop a proposal for an applied research project and enroll in ART 297B Master’s Project .
Thesis Examination: The candidate must successfully pass a final oral examination based on the Master’s Project.

</br>

- Students following the track in Art Criticism and Applied Practice must develop a proposal for an applied research project and enroll in ART 297B Master’s Project .</br>

- Thesis Examination: The candidate must successfully pass a final oral examination based on the Master’s Project.</br>


### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core Requirements (9 units)
ARTH 200-level seminars are repeatable for credit when course content changes.</br>

- ARTH 175 - Theories of Art History and Art Criticism 3 unit(s)</br>

- ARTH 275 - Seminar in Twentieth Century Art 3 unit(s) (GWAR)</br>

- ARTH 277 - Seminar in Historiography 3 unit(s)</br>


### For Track, Research in Art History and Visual Culture, complete the following course (18 units):

-  3 upper-division division elective elective courses. Six units may be taken from other departments with graduate advisor approval. </br>

3 upper-division division elective elective courses. Six units may be taken from other departments with graduate advisor approval.</br>

-  3 additional Art History Graduate Seminar Courses </br>

3 additional Art History Graduate Seminar Courses</br>

### For Track, Art Criticism and Applied Practice, complete the following courses (18 units):

- ARTH 174A - Exhibition and Curatorial Practices 3 unit(s)</br>

- ART 282A - Seminar in the Theory and Criticism of Contemporary Art 3 unit(s)</br>

- ART 282B - Seminar in Contemporary Art 3 unit(s) (GWAR)</br>

- 1 additional Art History Graduate Seminar Course</br>

- 2 additional elective Art History or Art Studio Upper-Division Courses. Six units may be taken from other departments with graduate advisor approval</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
For Track in Art History Research, complete the following:</br>

- 2 Comprehensive Qualifying Exams</br>

- Language Examination</br>

- Plan A (Thesis)   ARTH 299 Master’s Thesis    </br>

- ARTH 299 Master’s Thesis  </br>

For Track in Art Criticism and Applied Practice complete the following:</br>

- 1 Comprehensive Qualifying Exam</br>

- Plan B (Project)   ​ART 297B Master’s Project     </br>

- ​ART 297B Master’s Project   </br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Art History and Visual Culture Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>