
# Transportation Management, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- University Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Transportation Management (MSTM), offered by the Lucas Graduate School of Business  with support from the Mineta Transportation Institute, is a fully accredited, 30-unit program that takes two and half or three years to complete as a part-time student. The curriculum consists of six required courses, two electives, and a two-course culminating capstone experience.</br>
The curriculum is led by nationally recognized instructors who are academic or industry experts. The MSTM is fully accredited by the Association to Advance Collegiate Schools of Business (AACSB).</br>
Live, online classes are held on weekday evenings, allowing students to work full time while earning their degrees. Students generally take one course at a time, one night per week, for each ten-class session, for a total of four classes per year.</br>

## Admission Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the Special Session MS, Transportation Management degree program. See the GAPE Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage at GAPE. For these requirements, see the Policies and Procedures  section, Graduate and Post-Baccalaureate Information .</br>

### Admission to the Department
Applicants who meet university and program requirements will be considered for classified admission. Admission to the Special Session MS, Transportation Management degree program requires the following (more details about these requirements are provided at the “Admissions” tab from transweb.sjsu.edu/education/graduate):</br>

- A bachelor’s degree from an accredited university in the U.S. or the equivalent of a U.S. bachelor’s degree earned from a recognized institution if the degree was earned outside of the U.S.</br>

- A preferred 3.0 (on a 4.0 scale) grade point average (GPA) in the last 60 semester units or 90 quarter units of study. An absolute minimum GPA of 2.5 is required for graduate admission at SJSU.</br>

- A statement of purpose explaining how a Master of Science in Transportation Management will help you to achieve your career objectives (500 to 800 words).</br>

- A resume detailing your professional and academic experiences.</br>

- A letter of recommendation written by a supervisor who managed you in paid or volunteer work or by a university instructor who taught you. Letters should include an evaluation of your writing and analysis skills.</br>

- For students who did not earn a 4-year bachelor’s degree, master’s degree, or Ph.D. from an institution in which the principal language of instruction was English: scores from an English language proficiency examination. The university minimum entrance score for the TOEFL is 213 (computer-based) or 80 (internet-based); the minimum score required on the IELTS is 6.5, and the minimum PTE score is 53.</br>

- Applicants with a GPA below 3.0 may submit GMAT or GRE scores to demonstrate their readiness for graduate work.</br>


### Admission in Conditionally Classified Standing
Applicants not accepted into classified standing may qualify for conditionally classified status. The individual admission notification will explain required coursework, terms and conditions for removing deficiencies and attaining classified standing.</br>

## Requirements for Advancement to Candidacy
Candidacy denotes that the student is fully qualified to complete the final stages of the MS - Transportation Management. In order to achieve candidacy, students must meet the university requirements for candidacy, as detailed in the Graduate Policies and Procedures  section. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

## University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
Students disqualified from the MSTM program must follow the Disqualification and Probation - Graduate Students procedures  in the SJSU catalog. It is the policy of the Donald and Sally Lucas Graduate School of Business not to readmit disqualified graduate students after a second disqualification.</br>

### Transfer Credit
With the approval of the MSTM Program Director, the Donald and Sally Lucas Graduate School of Business Associate Dean for Graduate Programs, and the SJSU Associate Vice President for Graduate Studies and Research, students may transfer a maximum of nine units of related graduate course work from another accredited university in the United States to satisfy elective course requirements. Grades in the transfer courses must be “B” or better. Extension course work from other institutions is not acceptable.</br>
MTM courses taken via SJSU’s “Open University” are treated as transferred into the MSTM program (and thus count toward the maximum of nine units of transferable coursework).</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
​MTM 201  serves as the GWAR requirement for this program.</br>

### Culminating Experience
Plan B (Project)</br>
The program’s culminating experience is incorporated into MTM 283  and MTM 290 . Students use these courses to design and then carry out an individual, comprehensive capstone project.</br>
Special Session Program Information</br>
Academic Programs offered through Special Session are operated by Professional & Global Engagement. Registration and enrollment in a Special Session course or program must use the special session application form and will follow special session fee and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Professional Education website for more information.</br>

## Master’s Requirements (30 units)

### Required Core (18 units)

- MTM 201 - Transportation Systems and Society 3 unit(s) (GWAR)</br>

- MTM 202 - Introduction to Transportation Funding and Finance 3 unit(s)</br>

- MTM 203 - Transportation Marketing and Communications Management 3 unit(s)</br>

- MTM 214 - Transportation Policy and Regulation 3 unit(s)</br>

- MTM 215 - Transportation Planning and Project Development 3 unit(s)</br>

- MTM 217 - Leadership and Management of Transportation Organizations 3 unit(s)</br>


### Electives (6 units)

- MTM 226A - Transportation Emergency Management 3 unit(s)</br>

- MTM 226B - Transportation Security Management 3 unit(s)</br>

- MTM 226C - Transportation Safety and Compliance Management 3 unit(s)</br>

- MTM 236 - Managing Technology Innovations in Transportation 3 unit(s)</br>

- MTM 245 - High-Speed and Intercity Rail: Planning & Design 3 unit(s)</br>

- MTM 246 - High-Speed and Intercity Rail Operations/Engineering 3 unit(s)</br>

- MTM 250 - Sustainable & Resilient Transportation Management 3 unit(s)</br>

- MTM 260 - Project Management in Transportation 3 unit(s)</br>


### Culminating Experience (6 units)

#### Plan B (Project)

- MTM 283 - MSTM Capstone - Project Design 3 unit(s)</br>

- MTM 290 - MSTM Capstone - Evaluation Report 3 unit(s)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the MSTM Program Director. With prior approval from the Program Director, students may count towards the elective requirement one graduate or upper-division undergraduate course (3 units) from another SJSU program.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 3.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
Students must comply with all other graduate requirements contained in this catalog.</br>
 </br>