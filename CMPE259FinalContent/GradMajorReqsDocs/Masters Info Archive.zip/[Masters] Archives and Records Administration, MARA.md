
# Archives and Records Administration, MARA
 </br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (42 units)</br>

- Program Learning Outcomes  </br>

The fully online Master of Archives and Records Administration (MARA) degree program at the San Jose State University’s School of Information  prepares students for leadership positions in information governance and corporate archives.</br>
With the convenient and fully online MARA program, students can live anywhere while they earn their graduate degrees. The master’s program is delivered exclusively online via interactive online learning technology. The multimedia format enlivens the learning experience while introducing students to the same types of tools they’ll use in their professional careers.</br>
For more information: ischool.sjsu.edu.</br>

## Requirements for Admission to Classified Standing
Candidates must meet all university admissions requirements. Applicants who meet the following requirements beyond university requirements will be considered for classified admission into the School of Information:</br>

- A bachelor’s degree from any regionally accredited institution in any discipline with a GPA of at least 3.0 at the bachelor’s degree institution or in the last 60 semester or 90 quarter units.</br>

- A general understanding of computers and technology. See Technology Literacy Requirements.</br>

- The School requires that all students have computer access from home. See Home Computing Requirements.</br>

- Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage.</br>


## Requirements for Admission to Conditionally Classified Standing
The School of Information does not admit students on a conditional basis.</br>

## Requirements for Advancement to Candidacy
In order to achieve candidacy, students must meet the university requirements for candidacy. General university requirements for advancement to candidacy  for the MARA degree are detailed in the Graduate Policies and Procedures  section.</br>
Students must complete and submit the Petition for Advancement to Graduate Candidacy after completion of nine graded units and by the posted deadlines for the semester in which they plan to graduate. For additional program requirements and submission instructions, refer to the MARA Candidacy Approval Form Information website. Candidacy includes the successful completion of the Graduation Writing Assessment Requirement (GWAR).</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, and GPA requirements as outlined in the Graduation Requirements  section of the Policies and Procedures .</br>

### Special Session Program Information
Academic Programs offered through Special Session are operated by Professional and Continuing Education. Registration and enrollment in a Special Session course or program are subject to special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (42 units)

### Core Courses (27 units)

- MARA 200 - Record and Recordkeeping Professions 3 unit(s) (GWAR)</br>

- MARA 204 - Management of Archives, Records, Inf. Governance 3 unit(s)</br>

- MARA 210 - Records Creation, Appraisal, and Retention 3 unit(s)</br>

- MARA 211 - Access, Storage and Retrieval of Records 3 unit(s)</br>

- MARA 249 - Management of Digital Data, Information, Records 3 unit(s)</br>

- MARA 283 - Enterprise Content Management and Digital Preservation 3 unit(s)</br>

- MARA 285 - Research Methods in Records Management and Archival Science 3 unit(s)</br>

- MARA 286 - Information Assurance 3 unit(s)</br>

- MARA 287 - Developing an Information Governance Strategy 3 unit(s)</br>


### Electives (12 units)
Complete twelve units:</br>

- INFO 202 - Information Retrieval System Design 3 unit(s)</br>

- INFO 220 - Resources and Information Services in Professions and Disciplines 1-3 unit(s)</br>

- INFO 240 - Information Technology Tools and Applications 3 unit(s)</br>

- INFO 242 - Database Design and Management 3 unit(s)</br>

- INFO 246 - Information Technology Tools and Applications - Advanced 1-3 unit(s)</br>

- INFO 247 - Vocabulary Design 3 unit(s)</br>

- INFO 248 - Beginning Cataloging and Classification 3 unit(s)</br>

- INFO 251 - Web Usability 3 unit(s)</br>

- INFO 256 - Archives and Manuscripts 3 unit(s)</br>

- INFO 259 - Preservation Management 3 unit(s)</br>

- INFO 281 - Seminar in Contemporary Issues 1-3 unit(s)</br>

- INFO 282 - Seminar in Library Management 1-3 unit(s)</br>

- INFO 284 - Seminar in Archives and Records Management 1-3 unit(s)</br>

- INFO 287 - Seminar in Information Science 1-3 unit(s)</br>

- INFO 298 - Special Studies 1-3 unit(s)</br>

- MARA 284 - Seminar in Archives and Records Management 1-3 unit(s)</br>

- MARA 294 - Professional Experience 3 unit(s)</br>


### Culminating Experience (Plan B only) (3 units)

- MARA 289 - Advanced Topics in Archives and Records Administration (ePortfolio) 1-3 unit(s) (3 units required)</br>


## Total Units Required (42 units)
 </br>