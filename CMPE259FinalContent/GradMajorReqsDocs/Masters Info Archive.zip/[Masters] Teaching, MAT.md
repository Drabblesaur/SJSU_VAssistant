
# Teaching, MAT
 </br>

- Admissions Requirements</br>

- Conditionally Classified Standing</br>

- Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes   </br>

The Master of Arts Teaching (MAT) degree program, offered by the Department of Teacher Education , prepares students to engage in social justice teaching practices, contribute to the development of cultural literacy, provide education that promotes democracy, and develop content knowledge expertise to teach in urban and suburban schools. All the program courses will prepare enrolled students to provide instruction for multilingual learners and students with disabilities in general education classrooms. Enrolled students also will learn to set up a supportive classroom environment based on social-emotional learning principles and experience collaborative co-teaching experiences with successful mentor teachers in the field. Finally, students will design, carry out, and report on classroom-based teacher inquiry. The MAT is earned in combination with a teaching credential and is not a stand-alone Master’s Degree.</br>

## Admissions Requirements
Applicants must submit a complete application to the Multiple Subject, Single Subject, or PK-3 credential program by applying through the CSU Cal State Apply portal and meet all the university admissions requirements . A full list of current admission requirements can be found on the Teacher Education Department website. Note that the Teaching, MAT is not a stand-alone degree and must be completed in conjunction with one of the above teacher credentials. </br>
Provided that admitted teacher candidates remain in good standing, those who want to pursue the MAT degree will complete a program transfer (credential to MAT) during their credential program. For additional information on admissions, see the SJSU Graduate Admissions website and graduate admissions requirements  section.</br>
Applicants from countries in which the native language is not English or who have an international transcript from outside the US/Canada must achieve a minimum English-language proficiency test score as indicated on Graduate Admissions Test Requirements webpage. This applies to applicants on various types of visas AND to applicants who have a degree from outside the USA/Canada. For TOEFL requirements, see the Graduate Admissions  section. In addition, there are additional transcript evaluation requirements. Deadlines for applying may differ.</br>

- 

Candidates must meet all university admissions requirements .
</br>

- 

Minimum grade point average is 2.5.
</br>

- 

The materials enumerated below must be uploaded to the Cal State Apply application. 

Subject Matter Competency. 
		The Subject Matter Competency Requirement can be met in a variety of ways including via the CSETs, approved degree major, CTC-approved subject matter preparation program, or qualified coursework that meets each of the CTC subject matter domains. Information about meeting this requirement for current and prospective SJSU students can be found here: Verifying Subject Matter Competence. Additional information can be found on the CTC website. Note that the requirements for Subject Matter Competence at the point of admission differ for the PK-3, Multiple and Single Subject Programs.

Basic Skills Requirement.
		The Basic Skills Requirement  is currently met via a BA/BS degree from a regionally accredited university. . Information about meeting this requirement for current and prospective SJSU students can be found at the Meeting the Basic Skills Requirement webpage. Additional information can be found on the CTC website. 


Field Experience
		Required for applicants starting in Spring 2026 or later.  Highly recommended for applicants prior to Spring 2026. Field Experience consists of working/volunteering in a public school traditional classroom setting in your credential area. For further details, see the Field Experience form referenced below. Upload a completed/signed Field Experience Form from the Department of Teacher Education website to the Cal State Apply portal to verify your experience. SJSU courses accepted to meet the Multiple Subject or PK-3 Requirement are: LSTP 185 and CHAD 159. For PK-3, CHAD 160 will also meet this requirement. You may contact any California public school and let them know that you are applying to the SJSU Teaching Credential program and need to complete Field Experience hours.


Certificate of Clearance
		There are 3 steps to obtain the Certificate of Clearance (CoC): Do not wait until the last minute to request this item, as it can take weeks for the CCTC to issue. For detailed information about how to complete these steps, go to the Credential Information website.
		Step 1 - Live Scan Service
		Step 2 - Certificate of Clearance Application via CCTC
		Step 3 - Upload a pdf of the granted Certificate of Clearance to your CalState Apply application

		​Note: A US Social Security or Tax Identification Number is required to obtain a COC. If you are an international student, please consult an advisor in our International Student & Scholars Services (ISSS) to see if this is possible on your particular visa.


Statement of Purpose
		In your Statement of Purpose, explain how you arrived at your decision to become a teacher. 


A second Statement of Purpose is required for Bilingual Authorization applicants (only). Spanish Bilingual Authorization applicants must write their second statement in Spanish. Mandarin or Vietnamese Bilingual Authorization applicants must write their second statement in English.


Resume
		Prepare a brief (one-to-two page) resume that details your college-level academic, employment, and volunteer experiences. In describing a position that you held (employment or volunteer service), highlight the duties that you performed and any awards/accomplishments that you would like us to know about.


Two Letters of Recommendation
		The letters of recommendation are requested within CalState Apply. Letters must have been written within the last two years and should be from someone in a supervisory role. Letters from relatives or friends should not be submitted. Up to four letters of recommendation may be submitted but only two are required.


Official transcripts from each college/university attended will be submitted directly to SJSU Graduate Admissions. Transcripts may be submitted electronically or by mail, noting that official transcripts must be in a sealed, unopened envelope.


</br>

- Subject Matter Competency. 

		The Subject Matter Competency Requirement can be met in a variety of ways including via the CSETs, approved degree major, CTC-approved subject matter preparation program, or qualified coursework that meets each of the CTC subject matter domains. Information about meeting this requirement for current and prospective SJSU students can be found here: Verifying Subject Matter Competence. Additional information can be found on the CTC website. Note that the requirements for Subject Matter Competence at the point of admission differ for the PK-3, Multiple and Single Subject Programs.</br>

- 

Basic Skills Requirement.
		The Basic Skills Requirement  is currently met via a BA/BS degree from a regionally accredited university. . Information about meeting this requirement for current and prospective SJSU students can be found at the Meeting the Basic Skills Requirement webpage. Additional information can be found on the CTC website. 
</br>
Basic Skills Requirement.
		The Basic Skills Requirement  is currently met via a BA/BS degree from a regionally accredited university. . Information about meeting this requirement for current and prospective SJSU students can be found at the Meeting the Basic Skills Requirement webpage. Additional information can be found on the CTC website. </br>

- 

Field Experience
		Required for applicants starting in Spring 2026 or later.  Highly recommended for applicants prior to Spring 2026. Field Experience consists of working/volunteering in a public school traditional classroom setting in your credential area. For further details, see the Field Experience form referenced below. Upload a completed/signed Field Experience Form from the Department of Teacher Education website to the Cal State Apply portal to verify your experience. SJSU courses accepted to meet the Multiple Subject or PK-3 Requirement are: LSTP 185 and CHAD 159. For PK-3, CHAD 160 will also meet this requirement. You may contact any California public school and let them know that you are applying to the SJSU Teaching Credential program and need to complete Field Experience hours.
</br>
Field Experience
		Required for applicants starting in Spring 2026 or later.  Highly recommended for applicants prior to Spring 2026. Field Experience consists of working/volunteering in a public school traditional classroom setting in your credential area. For further details, see the Field Experience form referenced below. Upload a completed/signed Field Experience Form from the Department of Teacher Education website to the Cal State Apply portal to verify your experience. SJSU courses accepted to meet the Multiple Subject or PK-3 Requirement are: LSTP 185 and CHAD 159. For PK-3, CHAD 160 will also meet this requirement. You may contact any California public school and let them know that you are applying to the SJSU Teaching Credential program and need to complete Field Experience hours.</br>

- 

Certificate of Clearance
		There are 3 steps to obtain the Certificate of Clearance (CoC): Do not wait until the last minute to request this item, as it can take weeks for the CCTC to issue. For detailed information about how to complete these steps, go to the Credential Information website.
		Step 1 - Live Scan Service
		Step 2 - Certificate of Clearance Application via CCTC
		Step 3 - Upload a pdf of the granted Certificate of Clearance to your CalState Apply application

		​Note: A US Social Security or Tax Identification Number is required to obtain a COC. If you are an international student, please consult an advisor in our International Student & Scholars Services (ISSS) to see if this is possible on your particular visa.
</br>
Certificate of Clearance
		There are 3 steps to obtain the Certificate of Clearance (CoC): Do not wait until the last minute to request this item, as it can take weeks for the CCTC to issue. For detailed information about how to complete these steps, go to the Credential Information website.
		Step 1 - Live Scan Service
		Step 2 - Certificate of Clearance Application via CCTC
		Step 3 - Upload a pdf of the granted Certificate of Clearance to your CalState Apply application

		​Note: A US Social Security or Tax Identification Number is required to obtain a COC. If you are an international student, please consult an advisor in our International Student & Scholars Services (ISSS) to see if this is possible on your particular visa.</br>

- 

Statement of Purpose
		In your Statement of Purpose, explain how you arrived at your decision to become a teacher. 
</br>
Statement of Purpose
		In your Statement of Purpose, explain how you arrived at your decision to become a teacher. </br>

- 

A second Statement of Purpose is required for Bilingual Authorization applicants (only). Spanish Bilingual Authorization applicants must write their second statement in Spanish. Mandarin or Vietnamese Bilingual Authorization applicants must write their second statement in English.
</br>
A second Statement of Purpose is required for Bilingual Authorization applicants (only). Spanish Bilingual Authorization applicants must write their second statement in Spanish. Mandarin or Vietnamese Bilingual Authorization applicants must write their second statement in English.</br>

- 

Resume
		Prepare a brief (one-to-two page) resume that details your college-level academic, employment, and volunteer experiences. In describing a position that you held (employment or volunteer service), highlight the duties that you performed and any awards/accomplishments that you would like us to know about.
</br>
Resume
		Prepare a brief (one-to-two page) resume that details your college-level academic, employment, and volunteer experiences. In describing a position that you held (employment or volunteer service), highlight the duties that you performed and any awards/accomplishments that you would like us to know about.</br>

- 

Two Letters of Recommendation
		The letters of recommendation are requested within CalState Apply. Letters must have been written within the last two years and should be from someone in a supervisory role. Letters from relatives or friends should not be submitted. Up to four letters of recommendation may be submitted but only two are required.
</br>
Two Letters of Recommendation
		The letters of recommendation are requested within CalState Apply. Letters must have been written within the last two years and should be from someone in a supervisory role. Letters from relatives or friends should not be submitted. Up to four letters of recommendation may be submitted but only two are required.</br>

- 

Official transcripts from each college/university attended will be submitted directly to SJSU Graduate Admissions. Transcripts may be submitted electronically or by mail, noting that official transcripts must be in a sealed, unopened envelope.
</br>
Official transcripts from each college/university attended will be submitted directly to SJSU Graduate Admissions. Transcripts may be submitted electronically or by mail, noting that official transcripts must be in a sealed, unopened envelope.</br>

## Conditionally Classified Standing
Because the MAT program is nested within the PK-3 ECE Specialist Instruction Credential , Multiple Subject Credential  and Single Subject Credential programs, which require applicants to meet departmental admissions requirements, admission to conditionally classified standing is not appropriate and is not permitted.</br>

## Advancement to Candidacy
Candidacy denotes that a student is fully qualified to complete the final stages of the MAT degree. Requirements for advancement to candidacy, including the Graduation Writing Assessment Requirement (GWAR) , are listed on the Graduate Admissions and Program Evaluation website.</br>

### Department Requirements

- Complete 12 units of core courses: EDTE 262  and (for Multiple or Single Subject Credential candidates) EDTE 224 , EDTE 294 , and EDTE 260 , or (for PK-Grade 3 Credential candidates) CHAD 272 , EDSE 104 , and EDSE 269  with a grade of “C” or better in each one.</br>

- Complete the 3-unit MAT Foundations and Graduation Writing Assessment Requirement (GWAR)  course, EDTE 208  or EDTE 208B , with a grade of “C” or better.</br>

- Complete the 3-unit research methods course EDTE 250  or EDTE 250B , or (for PK-3) EDTE 250  or CHAD 260A  to develop a project proposal (Plan B) or a thesis proposal (Plan A) with a grade of “C” or higher.</br>

- Maintain an overall graduate GPA of 3.0 or higher.</br>

- MAT candidates who also are Single Subject Credential candidates must complete each of their subject-area methods courses with a grade of “B” or better.</br>


## Requirements for Graduation

### University Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements section of the Graduate Policies and Procedures . Completion of the degree also requires a minimum grade of “C” in all courses taken and a minimum overall GPA of 3.0.</br>

### Department Requirements

- Complete 18 units of core courses (EDTE 208  or EDTE 208B , EDTE 224  or CHAD 272 , EDTE 250  or EDTE 250B  or CHAD 260A , EDTE 260  or EDSE 269 , EDTE 262 , and EDTE 294  or EDSE 104 ).</br>

- Complete at least 6 units of subject-area curriculum and instruction courses.</br>

- Successfully receive approval for a project proposal (Plan B) or thesis proposal (Plan A) while completing EDTE 250  or EDTE 250B  or CHAD 260A .</br>

- Apply for graduation via MySJSU (through one.SJSU.edu).</br>

- Successfully complete either a portfolio or project (Plan B, EDTE 298  or CHAD 298 ) or thesis (Plan A, EDTE 299 ).</br>

- Satisfy the culminating experience requirements, which typically consist of successful completion of the portfolio, project, or thesis (i.e., 5 above) AND a presentation of the same at the department’s colloquium, which is held near the end of each fall and spring semester.</br>


### Culminating Experience

#### Plan A (Thesis)
Students selecting the Plan A option will write a master’s thesis. The thesis will include original research on a topic approved by the thesis committee, and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. The thesis identifies the problem, states the major assumptions, explains the significance of the undertaking, sets forth the sources for and methods of gathering information, analyzes the data, and offers a conclusion or recommendation. Thesis proposals must be approved by the graduate committee, which is made up of two department faculty and a third faculty member from outside the department. Students enroll in EDTE 299 - Master’s Thesis .</br>

#### Plan B (Portfolio or Project)
Students selecting the Plan B option will complete a master’s portfolio or project report. Either is a significant undertaking that evidences originality and independent thinking, appropriate form and organization, and a rationale. It is described and summarized, its significance, objectives, methodology and a conclusion and / or implications. Students enroll in EDTE 298 - Special Studies in Education ,or (for PK-3) EDTE 298 - Special Studies in Education  or CHAD 298 - Special Studies in Child and Adolescent Development .</br>

## Master’s Requirements (30 units)

### Foundations Core Courses (6 units)

- EDTE 208 - Educational Sociology 3 unit(s) (GWAR) or EDTE 208B Bilingual Educational Sociology  </br>

- EDTE 262 - Classroom Issues in the Language/Literacy Development of L2 Learners 3 unit(s)</br>


### Curriculum and Instruction Tracks (24 units)
Complete the Multiple Subject Credential or Single Subject Credential, or one of the PK-Grade 3 Tracks (PK-3 Early Childhood Education Specialist Credential).</br>

#### Multiple Subject Track (24 units)

- EDTE 224 - Seminar in Educational Psychology 3 unit(s)</br>

- EDTE 260 - Critical Perspectives on Schooling for a Pluralist Democracy 3 unit(s)</br>

- EDTE 294 - Research/Practices in Health and Special Education 3 unit(s)</br>

- EDEL 108A - Curriculum: Reading/Language Arts 3 unit(s)</br>

- EDEL 108C - Curriculum: Social Studies 3 unit(s)</br>

- EDEL 108D - Curriculum: Mathematics 3 unit(s)</br>

- EDTE 250 - Qualitative Research in Education 3 unit(s) or EDTE 250B Qualitative Research in Bilingual Education  </br>

Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one of the following:</br>

- EDTE 298 - Special Studies in Education 1-6 unit(s)</br>

- EDTE 299 - Master’s Thesis 1-6 unit(s)</br>


#### Single Subject Education Track (24 units)

- EDTE 224 - Seminar in Educational Psychology 3 unit(s)</br>

- EDTE 260 - Critical Perspectives on Schooling for a Pluralist Democracy 3 unit(s)</br>

- EDTE 294 - Research/Practices in Health and Special Education 3 unit(s)</br>

- EDTE 282 - Assessment and Evaluation 3 unit(s)</br>

Complete 3-4 units from the following:</br>

- ARED 238 - Principles of Art Education 3 unit(s)</br>

- ENED 353 - Methods of Teaching English 4 unit(s)</br>

- FLED 380 - Teaching Foreign Languages 3 unit(s)</br>

- KNED 339 - Instructional Materials and Procedures in Physical Education 3 unit(s)</br>

- MTED 394 - Secondary Mathematics Methods 3 unit(s)</br>

- MUED 370A - Methodology for Music Educators: Elementary K-8 2 unit(s)</br>

- MUED 370B - Methodology for Music Educators: Secondary 2 unit(s)</br>

- SCED 273 - Secondary School Science 3 unit(s)</br>

- SSED 378 - Social Science Methods 3 unit(s)</br>

- EDTE 250 - Qualitative Research in Education 3 unit(s) or EDTE 250B Qualitative Research in Bilingual Education  </br>

Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete one of the following:</br>

- EDTE 298 - Special Studies in Education 1-6 unit(s)</br>

- EDTE 299 - Master’s Thesis 1-6 unit(s)</br>


#### PK-Grade 3 Track - Early Childhood (24 units)

- CHAD 272 - Seminar in Early Childhood Development 3 unit(s)</br>

- EDSE 104 - Early Intervention for Children with Disabilities 3 unit(s)</br>

- EDSE 269 - Supportive Learning Environments for Young Children 3 unit(s)</br>

- CHAD 261 - Seminar in Early Childhood Curriculum 3 unit(s)</br>

- EDEL 108A - Curriculum: Reading/Language Arts 3 unit(s)</br>

- EDEL 108D - Curriculum: Mathematics 3 unit(s)</br>

- CHAD 260A - Seminar in Child and Adolescent Development: Research 3 unit(s)</br>

Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- CHAD 298 - Special Studies in Child and Adolescent Development 3-6 unit(s)</br>


#### PK-Grade 3 Track - Primary Grades (24 units)

- CHAD 272 - Seminar in Early Childhood Development 3 unit(s)</br>

- EDSE 104 - Early Intervention for Children with Disabilities 3 unit(s)</br>

- EDSE 269 - Supportive Learning Environments for Young Children 3 unit(s)</br>

- CHAD 261 - Seminar in Early Childhood Curriculum 3 unit(s)</br>

- EDEL 108A - Curriculum: Reading/Language Arts 3 unit(s)</br>

- EDEL 108D - Curriculum: Mathematics 3 unit(s)</br>

- EDTE 250 - Qualitative Research in Education 3 unit(s) or EDTE 250B Qualitative Research in Bilingual Education  </br>

Program departments are required to certify when Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- EDTE 298 - Special Studies in Education 1-6 unit(s)</br>


## Total Units Required (30 units)
Upon completion of the credential requirements, students must have achieved a SJSU cumulative grade point average of 3.0 in order to be recommended for a credential.</br>
 </br>