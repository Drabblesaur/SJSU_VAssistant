
# Economics, MA
 </br>

- Requirements for Admission with Classified Standing</br>

- Requirements for Admission with Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy for the MA - Economics</br>

- Requirements for Graduation</br>

- Master’s Requirements (32 units)</br>

- Program Learning Outcomes  </br>


## Requirements for Admission with Classified Standing
An applicant first must meet the requirements for admission to the university. In addition, the applicant should possess a minimum grade point average of “B”. Bachelor degrees in fields other than economics are acceptable for admission to the department. For admission to classified standing, an applicant’s preparation in calculus (MATH 71  or MATH 30 ), statistics (STAT 95 ), and intermediate microeconomics (ECON 101 ), intermediate macroeconomics (ECON 102 ) and intermediate econometrics (ECON 103A ), must be satisfactory (grades of “B” or better).</br>

## Requirements for Admission with Conditionally Classified Standing
A student who does not meet all requirements for admission  to classified standing may be admitted into the program on a conditionally classified basis if he or she has demonstrated an interest in and an ability to master economic analysis, and has completed introductory statistics (STAT 95) and calculus (MATH 71 or MATH 30). Such admission will require students to take specific courses, ECON 101, ECON 102, and ECON 103A, with grades of “B” or better, before taking graduate (200-level) courses.</br>

## Requirements for Advancement to Candidacy for the MA - Economics
To be advanced to candidacy  for the Master of Arts degree, a student must first meet the university requirements for the degree as stated in the Academic Regulations section of this catalog . Also, a candidate:</br>

- Must have at least a 3.0 (“B”) average in nine semester hours of approved San José State University courses in economics at the 100- or 200-level.</br>

- Must obtain approval of a formal master’s degree program from the departmental graduate advisor and from the University Graduate Committee.</br>

- Must have successfully completed the Graduation Writing Assessment Requirement (GWAR) . The University requires that all graduate students complete the GWAR as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>


### Graduate Theory Grade Requirement
All master’s degree students must complete a microeconomic theory course (ECON 201 ), a macroeconomic theory or monetary theory course (ECON 202  or ECON 235 ), and ECON 205  with a grade of “B” or better. All 100 - level courses must be completed with a “B” or better. Policies concerning Probation and Disqualification are available online and in the Economics Office.</br>

### Undergraduate Course Grade Requirement
Master’s degree students may count a limited number of 100-level undergraduate courses as approved electives; however, these courses must be completed with a grade of “B” or better and must be approved in advance by a department graduate advisor. Students earning less than a “B” in any of these classes are allowed one attempt to retake and achieve the minimum grade. Policies concerning Probation and Disqualification are available online and in the Department of Economics  Office.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>
In consultation with the department graduate coordinator, the candidate will develop and pursue a program of study. The candidate must successfully complete all requirements of the selected plan including the course work specified in the Master’s Degree Approval Program. At an appropriate time, and with the assistance of the graduate advisor, the student chooses a proposed Master’s degree program and Plan A or Plan B culminating experience as outlined below.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by passing ECON 203A . </br>

### Culminating Experience
Plan A (Thesis)</br>
The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee. It is the candidate’s responsibility to find an Economics Faculty member to Chair the thesis committee, and work with the Chair to determine the other members of the committee and the thesis topic.</br>
Plan B (Comprehensive Examination)</br>
Most students complete a final written examination, not a thesis. The comprehensive exam covers three subjects: microeconomic theory, macroeconomic/monetary and econometrics. Students register once, for one unit of ECON 298E  in the semester they plan to take the examination. Students can take the exam a total of three times. Policies concerning Probation and Disqualification for failure to complete the exam are available online and in the Economics Office.</br>
Plan B (Project)</br>
A student may complete an academically rigorous research project by enrolling in ECON 298P - Master’s Project . In ECON 298P the student will complete a substantial paper under faculty supervision to complete the project component of Plan B. The student is responsible for securing the commitment of a full-time tenured or tenure-track economics faculty member who agrees to serve as project supervisor.</br>

## Master’s Requirements (32 units)

### Core Courses (16 units)

- ECON 104 - Mathematical Methods for Economics 4 unit(s)</br>

- ECON 201 - Seminar in Microeconomic Analysis 3 unit(s)</br>

- ECON 203A - Economic Research Methods 3 unit(s) (GWAR)</br>

- ECON 205 - Workshop in Economic Analysis 3 unit(s)</br>


#### Complete One Course:

- ECON 202 - Seminar in Macroeconomic Analysis 3 unit(s)</br>

- ECON 235 - Seminar in Monetary Theory and Policy 3 unit(s)</br>


### Electives (12 units)

- Approved 100- or 200-level courses</br>


### Culminating Experience (4 units)

#### Plan A (Thesis)

- ECON 299 - Master’s Thesis 1-6 unit(s)</br>


#### Plan B (Comprehensive Exam)

- ECON 298E - Special Study Comprehensive Exam 1 unit(s)</br>

- One additional 200-level Economics elective 3 unit(s)</br>


#### Plan B (Project)

- ECON 298P - Master’s Project  1-6 unit(s)</br>


## Total Units Required (32 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 12.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>