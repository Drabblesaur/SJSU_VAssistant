
# Computer Science, MS
 </br>

- Admissions Requirements</br>

- Requirements for Advancement to Graduate Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Computer Science degree, offered by the Department of Computer Science , provides greater depth in computer science for more advanced positions in industry or teaching at the community college level. Check the Department website for details about the Computer Science program.</br>

## Admissions Requirements

### University Admissions
Applicants must submit a complete graduate application by applying through Cal State Apply and meet all the university admission requirements. See the Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirement webpage at GAPE. For TOEFL Requirements, see the Policies and Procedures  section, Graduate and Post-Baccalaureate Information  in this Catalog.</br>

### Requirements for Admission to Classified Standing
To enter this program with classified standing, a student must meet the minimum requirements for admission to the Graduate Division. In addition, entering students are expected to have a bachelor’s degree in computer science or its equivalent, e.g., a degree presenting at least the breadth and depth of the SJSU BS, Computer Science program. An applicant holding a recent bachelor’s degree in Computer Science from an ABET-accredited university will normally meet the course requirements for admission to the MSCS program.</br>

### Requirements for Admission to Conditionally Classified Standing
Applicants who meet the minimum requirements for admission  to the Graduate Division but lack other prerequisite course knowledge can be admitted in conditionally classified status if there is sufficient space in the program to accommodate them. Conditionally classified students will be required to complete undergraduate coursework to attain Classified standing. The individual admission notification will explain the required terms and conditions for attaining Classified standing.</br>

### Transfer of Courses into the Major
Students may transfer nine credits into the program from coursework completed in the SJSU Computer Science Department. A maximum of 6 units may be from courses outside the SJSU Computer Science Department. All transfer credit must fulfill MS, Computer Science program requirements and be approved by the Graduate Coordinator.</br>

## Requirements for Advancement to Graduate Candidacy
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy . The Computer Science Department policy is that students should complete the GWAR requirement (usually by taking CS 200W ) in their first year in the MS program and must complete it two semesters before graduation. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>
This requirement is satisfied by taking CS 200W .</br>

### Culminating Experience
Students choose a Plan A (Thesis) or Plan B (Written Project) option as their program culminating experience.</br>
Plan A (Thesis)</br>
After being advanced to candidacy, the student choosing the thesis option must obtain a thesis director from among the tenured or tenure-track faculty of the Computer Science Department who then becomes his or her advisor. Before work can begin, the thesis topic must be approved by a three-member committee consisting of the thesis director, another professor from the CS Department, and a third member who is an expert in the field, selected by the thesis director and approved by the Department Chairperson. The candidate should register for CS 297  before the final semester, and take CS 299  in the final semester of the program. Students who do not finish the thesis in that semester enroll in the 1290R for subsequent semesters until it is completed. Upon completion of the thesis, the candidate must pass a comprehensive oral examination in the area of his or her thesis, conducted by the thesis committee. The thesis must also meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines.</br>
Plan B (Written Project)</br>
After being advanced to candidacy, the student must obtain a project director from the Computer Science Department who then becomes his or her advisor. Before work can begin, the project topic must be approved by a three-member committee consisting of the project director, another professor from the CS Department, and a third member who is an expert in the field, selected by the thesis director and approved by the Department Chairperson. The candidate should register for the CS 297  before the final semester, and take the CS 298  in the final semester of the program. Students who do not finish the project in that semester enroll in the 1290R for subsequent semesters until it is completed. Upon completion of the project, the candidate must pass an oral examination in the area of his or her project conducted by the project committee.</br>

## Master’s Requirements (33 units)

### Core Courses (21 units)

- CS 200W - Graduate Technical Writing 3 unit(s) (GWAR)</br>


#### Foundations (3 units)

- CS 252 - Advanced Programming Language Principles 3 unit(s)</br>

- CS 254 - Theory of Computation 3 unit(s)</br>

- CS 255 - Design and Analysis of Algorithms 3 unit(s)</br>

- CS 262 - Randomized Algorithms and Applications 3 unit(s)</br>

- MATH 279A - Graph Theory 3 unit(s)</br>


#### Architecture (3 units)

- CS 247 - Advanced Computer Architecture 3 unit(s)</br>

- CS 258 - Computer Communication Systems 3 unit(s)</br>

- CS 259 - Advanced Parallel Processing 3 unit(s)</br>

- CS 268 - Topics in Wireless Mobile Networking 3 unit(s)</br>


#### Systems Software (3 units)

- CS 218 - Topics in Cloud Computing 3 unit(s)</br>

- CS 249 - Distributed Computing 3 unit(s)</br>

- CS 253 - Advanced Compiler Design 3 unit(s)</br>

- CS 257 - Database System Principles 3 unit(s)</br>

- CS 267 - Topics in Database Systems 3 unit(s)</br>


#### Specialty Courses (9 units)

- CS 216 - Physically Based Modeling for Computer Graphics 3 unit(s)</br>

- CS 223 - Advanced Bioinformatics 3 unit(s)</br>

- CS 224 - Next Generation Sequencing & Genome Assembly 3 unit(s)</br>

- CS 225 - Topics in Sequence-based Machine Learning for Bioinformatics 3 unit(s)</br>

- CS 228 - Biometric Security with AI 3 unit(s)</br>

- CS 256 - Topics in Artificial Intelligence 3 unit(s)</br>

- CS 265 - Cryptography and Computer Security 3 unit(s)</br>

- CS 266 - Topics in Information Security 3 unit(s)</br>

- CS 271 - Topics in Machine Learning 3 unit(s)</br>

- CS 272 - Reinforcement Learning and Sequential Decision Making 3 unit(s)</br>

- CS 273 - Topics in Natural Language Processing 3 unit(s)</br>

- CS 274 - Topics in Web Intelligence 3 unit(s)</br>

- CS 276 - Machine Learning on Graphs 3 unit(s)</br>

- CS 286 - Advanced Topics in Computer Science 3 unit(s)</br>


#### Subject Varies by Topic

- CS 286 - Advanced Topics in Computer Science 3 unit(s) (Note: Unless the course syllabus states otherwise, a CS 286 course offering is deemed to be in the Speciality Courses area)</br>


### Electives (6 units)
Select 6 units of permissible elective courses from the following list. Courses not on the list must be approved in advance by a graduate coordinator. Any graduate courses listed above not used to satisfy degree requirement may be used as an elective course.</br>

- CS 116A - Introduction to Computer Graphics 3 unit(s)</br>

- CS 116B - Computer Graphics Algorithms 3 unit(s)</br>

- CS 123A - Bioinformatics I 3 unit(s)</br>

- CS 123B - Bioinformatics II 3 unit(s)</br>

- CS 134 - Computer Game Design and Programming 3 unit(s)</br>

- CS 136 - Introduction to Computer Vision 3 unit(s)</br>

- CS 143C - Numerical Analysis and Scientific Computing 3 unit(s)</br>

- CS 143M - Numerical Analysis and Scientific Computing 3 unit(s)</br>

- CS 153 - Concepts of Compiler Design 3 unit(s)</br>

- CS 155 - Introduction to the Design and Analysis of Algorithms 3 unit(s)</br>

- CS 156 - Introduction to Artificial Intelligence 3 unit(s)</br>

- CS 157B - Database Management Systems II 3 unit(s)</br>

- CS 157C - NoSQL Database Systems 3 unit(s)</br>

- CS 158A - Computer Networks 3 unit(s)</br>

- CS 158B - Computer Network Management 3 unit(s)</br>

- CS 159 - Introduction to Parallel Processing 3 unit(s)</br>

- CS 161 - Software Project 3 unit(s)</br>

- CS 168 - Blockchain and Cryptocurrencies 3 unit(s)</br>

- CS 171 - Introduction to Machine Learning 3 unit(s)</br>

- CS 174 - Server-side Web Programming 3 unit(s)</br>

- CS 175 - Mobile Device Development 3 unit(s)</br>

- CS 176 - Introduction to Social Network Analysis 3 unit(s)</br>

- MATH 142 - Introduction to Combinatorics 3 unit(s)</br>

- MATH 161A - Applied Probability and Statistics I 3 unit(s)</br>

- MATH 161B - Applied Probability and Statistics II 3 unit(s)</br>

- MATH 162 - Statistics for Bioinformatics 3 unit(s)</br>

- MATH 163 - Probability Theory 3 unit(s)</br>

- MATH 164 - Mathematical Statistics 3 unit(s)</br>

- MATH 177 - Linear and Non-Linear Optimization 3 unit(s)</br>

- MATH 178 - Mathematical Modeling 3 unit(s)</br>

- MATH 179 - Introduction to Graph Theory 3 unit(s)</br>

- MATH 203 - Applied Mathematics, Computation, and Statistics Projects 3 unit(s)</br>

- LING 220 - Computational Linguistics I 3 unit(s)</br>

- 

Electives may include three units from:</br>

Electives may include three units from:</br>

- CS 180 - Individual Studies 1-3 unit(s)</br>

- CS 280 - Graduate Individual Studies 1-3 unit(s)</br>


### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete One Option (Plan A or Plan B)</br>

#### Plan A (Thesis) (6 units)

- CS 297 - Preparation for Writing Project or Thesis 3 unit(s)</br>

- CS 299 - Master’s Thesis 3 unit(s)</br>

- Comprehensive Oral Examination</br>


#### Plan B (Project) (6 units)

- CS 297 - Preparation for Writing Project or Thesis 3 unit(s)</br>

- CS 298 - Master’s Writing Project 3 unit(s)</br>

- Comprehensive Oral Examination</br>


## Total Units Required (33 units)
No more than 6 units may be taken from outside the Department of Computer Science.</br>
Elective courses must be planned in consultation with a CS Graduate Advisor or your CS Thesis or CS Writing Project advisor.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>