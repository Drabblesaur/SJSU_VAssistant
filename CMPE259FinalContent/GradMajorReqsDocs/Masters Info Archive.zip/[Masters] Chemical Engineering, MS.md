
# Chemical Engineering, MS
 </br>

- Requirements for Admission</br>

- Requirements for Candidacy</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MS Chemical Engineering program, offered by the Department of Chemical and Materials Engineering , provides advanced study of chemical engineering topics with an emphasis on both the fundamental and applied aspects. Elective courses are also available in science, other engineering fields, and business. This broad-based, multidisciplinary educational program has proven to be an important factor for a student’s future success including leading Silicon Valley companies and in Ph.D. programs. </br>
Faculty are involved in research areas including biochemical engineering, semiconductor processing, green and alternative energy, process control, microfluidics, polymers and nanocomposites, nanotechnology, and environmental health and safety engineering, remediation, sustainability, and computational methods using AI and machine learning. Research activity is sponsored by local industries as well as by government funding agencies.</br>
The MS Chemical Engineering program welcomes students with undergraduate BS degrees in Chemical Engeineering or closely related science (e.g. biology, chemistry, physics) and engineering disciplines (e.g. biochemical, biomedical, civil, materials, and mechanical).</br>
Class schedules are designed for the convenience of employed engineers who wish to pursue graduate work on a part-time basis as the majority of classes are scheduled during the evening hours.</br>
Department Website: www.sjsu.edu/cme.</br>

## Requirements for Admission

### University Admission
Candidates must apply through the CSU admissions portal, Cal State Apply, and meet all university admissions requirements. Applicants should note that some department admission requirements are higher than university admissions requirements.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. The program does not currently require the GRE for admission.</br>

### Admission to the Program
Candidates must meet all the university admissions requirements . Students can be admitted in either classified or conditionally classified standing. To be admitted to classified standing, a student must possess a U.S. baccalaureate degree with a major in chemical engineering and a grade point average of 3.0 or better in the last 60 units, from an ABET-accredited chemical engineering program.</br>
Students can be admitted with conditionally classified standing if they have a CHE degree from a U.S. accredited university in which they obtained a 2.7-2.99 GPA in the last 60 units; a U.S. equivalent CHE degree from a non-U.S. institution; or a BS degree in chemistry, biology, physics or closely related engineering discipline from an accredited or equivalent institution. Students admitted with conditionally classified standing will take a series of transition courses. The program admissions letter will explain terms and requirements. Once these conditions are completed satisfactorily, students can petition for classified standing. For more information on transition courses, see the department website.</br>

## Requirements for Candidacy
Students must meet the university requirements for candidacy which include successful completion of the Graduation Writing Assessment Requirement (GWAR) . The University requires that all graduate students complete the GWAR as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

### Course Requirements
To meet the requirements for the MS - Chemical Engineering degree, a student must complete 30 units of approved courses. Students must achieve a minimum of a “C” in each course and maintain a cumulative GPA of 3.0 or better. In addition to the 30 approved course units, students should select a Culminating Experience in consultation with their SJSU research advisor, and a written thesis or project report and an oral defense of their thesis or project must be completed.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students in the MS, Chemical Engineering program will complete CHE 280 /CHE 280I  and CHE 281  and may complete 1-unit of CHE 298  / CHE 298I  or CHE 299  / CHE 299I  through their choice of a graduate project or master’s thesis, respectively.</br>
Thesis Requirements</br>
Students opting to complete a master’s thesis are responsible for securing the commitment of a full-time tenured or tenure-track faculty member who agrees to serve as the thesis committee chair. The student must also secure the commitments of two additional committee members, one of whom must be a full or part-time SJSU faculty member, to serve as the student’s thesis committee. If the student is completing their thesis research off-site, then one person of their thesis committee must be at least a supervisor-level employee from that off-site facility. The student must write a thesis proposal and have it approved by the thesis committee in order to pass CHE 281 . CHE 299  is taken in the semester the student expects to complete their final oral and written defense which will serve as their culminating experience. The MS candidate must successfully pass an oral defense and complete an approved thesis report in order to receive credit for CHE 299 . Students must be enrolled in courses every semester with the exception of an approved leave of absence for one semester. Students who have finished all their 30 units with the exception of an RP grade in CHE 299  are eligible for enrollment in CHE 1290R  for a reduced tuition fee. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Project Requirements</br>
Students opting to complete a graduate project are responsible for securing the commitment of a full-time tenured or tenure-track faculty member who agrees to serve as the project committee chair. The student must also secure the commitments of an additional committee member to serve as the student’s project committee. If the student is completing their thesis project research off-site, then one person of their project committee must be at least a supervisor-level employee from that off-site facility. The student must write a project proposal and have it approved by the project committee in order to pass CHE 281 . CHE 298  is taken in the semester the student expects to complete their final oral defense and written project report, which will serve as their culminating experience. The MS candidate must successfully pass an oral and defense and complete an approved written project report in order to receive credit for CHE 298 . Students must be enrolled in courses every semester with the exception of an approved leave of absence for one semester. Students who have finished all their 30 units with the exception of an RP grade in CHE 298  are eligible for enrollment in CHE 1290R  for a reduced tuition fee.</br>

## Master’s Requirements (30 units)

### Core Courses (12 units)

- CHE 200 - Research Methods 3 unit(s) (GWAR)</br>

- CHE 211 - Advanced Chemical Engineering Thermodynamics 3 unit(s)</br>

- CHE 218 - Reaction Kinetics 3 unit(s) (GWAR)</br>

- CHE 219 - Transport Processes 3 unit(s)</br>


### Approved Electives (12 units)
12 units of electives selected in consultation with a graduate advisor. At least one technical elective needs to be an approved 200-level course.</br>
 Only students who are doing research on campus may be eligible for CHE 282  (3 units). CHE 282 may be taken 2 times for a maximum of 6 units of technical elective credit. Only one section of CHE 280 /CHE 280I /CHE 282   can be taken per semester.  </br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- ​CHE 281 - MS Thesis/Project Preparation Seminar  3 unit(s)</br>

- CHE 280 - Graduate Research  OR CHE 280I - Graduate Research Internship  2 unit(s)</br>

Complete one course for 1 unit:</br>

- CHE 298 - MS Research/Project 1-2 unit(s)</br>

- CHE 298I - MS Research/Project Internship 1-3 unit(s)</br>

- CHE 299 - Master’s Thesis 1-3 unit(s)</br>

- CHE 299I - Master’s Thesis Internship 1-3 unit(s)</br>


## Total Units Required (30 units)
 </br>