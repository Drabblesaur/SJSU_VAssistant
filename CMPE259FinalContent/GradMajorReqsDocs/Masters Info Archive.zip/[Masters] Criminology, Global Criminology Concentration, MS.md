
# Criminology, Global Criminology Concentration, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- University Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Department of Justice Studies  at San José State University offers an online Master of Science in Criminology with a Concentration in Global Criminology designed to adapt to the ever-changing environment of the justice and legal systems, and the discipline of criminology. It uniquely combines the advanced study of contemporary international crime and the various responses to crime around the globe with analytic and research techniques used by advanced scholars. It provides an international comparative curriculum that develops analytical skills, understanding of legal concepts, theoretical competency, and abilities to apply criminology in practical ways. It aims to equip graduates with a truly global outlook on crime and criminal justice, a commitment to international justice, and professional competencies to apply practices from around the globe to meet the particular needs of their communities.</br>
This degree program is housed in the Department of Justice Studies. </br>
Graduate Coordinator: Dr. Jodie Warren</br>

## Admission Requirements
To be considered for admission to the MS in Criminology program, applicants must complete the university admission requirements, as well as have a baccalaureate degree from an accredited four-year college or university, minimum grade point average of 3.0 in the last 60 credits of coursework, a general understanding of computers and technology, and access to a computer with Internet. International applicants must have a TOEFL score of 550 (Paper Based), 213 (Computer Based), or 80 (Internet Based).</br>

### International (Foreign) Students
Documentation of the applicant’s TOEFL score should accompany other admission materials. For TOEFL requirements see Graduate Program Test Requirements.</br>

## Requirements for Advancement to Candidacy
For advancement to candidacy for the Master of Science degree in Criminology, Concentration in Global Criminology, students must meet the general university requirements for advancement to candidacy  outlined in the academic requirements section of this catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

## University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Requirements for the MS - Criminology, Concentration in Global Criminology.
Each student must take a core curriculum of 15 units (JS 265 , JS 266 , JS 271 , JS 272 , and JS 273 ). Elective courses must be 200-level courses in the department. Subject to graduate coordinator approval, two graduate courses in other departments or programs may be taken as electives, if the student demonstrates their relevance to the student’s program of study, and/or career goals. Undergraduate courses may not count toward the 30 units of required graduate course work. Students who are academically or administratively disqualified from the program will generally not be readmitted.</br>
Special Session Program Information</br>
Academic Programs offered through Special Session are operated by Professional & Global Engagement. Registration and enrollment in a Special Session  course or program must use the special session application form and will follow the special session fees and course schedules. Note that regular session students seeking to enroll simultaneously in a special session course or the program will trigger a separate and additional set of fees. This may require an additional enrollment appointment from the Registrar and it may have implications for financial aid status or requirements. Please visit the Professional Education website for more information.</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- JS 265 - Comparative Criminal Justice Systems 3 unit(s) (GWAR)</br>

- JS 266 - Applied Research Methods and Statistics 3 unit(s)</br>

- JS 271 - International Human Rights 3 unit(s)</br>

- JS 272 - Policing in Global Contexts 3 unit(s)</br>

- JS 273 - International Criminology and Juvenile Delinquency 3 unit(s)</br>


### Concentration Requirements (12 units)

- JS 267 - Crime and Gender Around the World 3 unit(s)</br>

- JS 268 - Immigration and International Law 3 unit(s)</br>

- JS 269 - Cyber Forensics 3 unit(s)</br>

- JS 270A - Global Terrorism 3 unit(s)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- JS 274 - Applied Project 3 unit(s)</br>


## Total Units Required (30 units)
 </br>