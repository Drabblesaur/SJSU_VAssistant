
# Business Administration (Early Career), MBA
 </br>

- Purpose of the MBA Program</br>

- Educational Objectives</br>

- Benefits of the MBA</br>

- Lucas MBA Programs</br>

- Admission Requirements</br>

- Program of Study Requirements for the MBA Degree</br>

- Early Career MBA Requirements (42 units)</br>

- Program Learning Outcomes  </br>


## Purpose of the MBA Program
The MBA program provides a strong foundation of business concepts, models, skills, and methods with which to face immediate and future managerial challenges. The basic program aims at creating a general management (rather than a functional specialist) perspective. Pragmatic in approach, the focus is on problem analysis and synthesis, decision making, action taking throughout the functional areas of business, and understanding the international context of business. The Lucas Graduate School of Business  prepares students through a broad curriculum of functional, cross-functional and integrative core courses, and elective courses.</br>

## Educational Objectives
The educational objectives of the Donald and Sally Lucas Graduate School of Business MBA are threefold: to provide a solid base of interdisciplinary business theories and techniques; to apply theory and analytic tools to the practical improvement of organizational performance; to explore personal beliefs and values as they affect ethical and economic organizational practices. Key processes involve: investigating opportunities and problems; defining causes or contributing factors to problems, including those that cut across organizational units; generating alternatives from which feasible programs of action are selected and implemented; and monitoring and changing, where necessary, the progress of enacted decisions.</br>
These skills are developed using a combination of approaches including the case method, experiential exercises, computer simulations, team projects, and problem sets. Students are expected to develop competencies both as action-oriented leaders and as logical decision-makers.</br>

## Benefits of the MBA
The program is geared to the professionally-oriented person who aspires to move into middle management or to undertake greater managerial responsibility. It is designed to aid those who have the capabilities or potential to be action initiators. The MBA program accommodates students with a variety of educational and work backgrounds.</br>

## Lucas MBA Programs
Although SJSU grants one unique MBA degree, the Lucas Graduate School of Business offers two distinct MBA programs that differ according to student profile, flexibility, degree completion time, admission cycle, and cost.</br>
The Early Career MBA program is tailored to students who have fewer than five years of work experience. Classes are conducted in a hybrid format with a mix of in-person classes on the SJSU campus and online classes. Classes meet during evenings and Saturdays in eight-week sessions during the Fall and Spring semesters and five-week sessions during the Summer semester. The Early Career Program offers three tracks that vary in length and pace: Accelerated Track (12 months), Full-Time Track (21-24 months), and Part-Time Track (33-36 months).</br>
The MBA for Professionals is designed for working professionals with more than five years of work experience. This program offers a high level of flexibility in order to accommodate professionals with demanding life and work schedules. Classes are conducted in a hybrid format with a mix of in-person classes held on the SJSU campus and online classes. Classes meet during evenings and Saturdays in eight-week sessions during the Fall and Spring semesters and five-week sessions during the Summer semester.</br>

## Admission Requirements

### Requirements for Admission to Classified Standing
To be fully accepted into classified standing, an applicant must have:</br>

- A bachelor’s degree from an accredited university in the U.S. or the equivalent of a U.S. bachelor’s degree earned from a recognized institution if the degree was earned outside of the U.S.</br>

- A preferred GPA of 3.0 on a 4.0 scale.</br>

- Taken an English language proficiency examination if the previously earned degree was from an institution in which the principal language of instruction was not English. The university’s minimum entrance score for the TOEFL is 213 (computer-based) or 80 (internet-based). The minimum score required on the IELTS is 6.5, and the minimum PTE score is 53.</br>

- (Optional) Taken the GMAT or GRE. Applicants with a GPA below 3.0 are strongly encouraged to take the GMAT or GRE to demonstrate their readiness for graduate work.</br>

- Completed two prerequisite courses (Economics and Statistics, with a grade of B or higher). The economics course may be one of the following: Introduction to Microeconomics, Introduction to Macroeconomics, or Principles of Economics. An applicant may be admitted to the MBA program on a conditional admission basis prior to completion of these two courses but will need to provide proof of completion of all prerequisites before the day of orientation.</br>

- A personal statement of one to two pages explaining how an MBA can help to achieve the applicant’s career objectives.</br>

- A resume detailing the applicant’s professional and academic experiences.</br>

- (Optional) Two letters of recommendation.</br>

The Lucas School does not follow a set formula for determining admission to the MBA programs. Our goal is to admit academically qualified candidates who show potential for completing the program and advancing into a successful business career. We seek to admit students whose backgrounds will enable them to contribute to the academic excellence and the demographic, educational, and experiential diversity of each class.</br>
An applicant’s academic profile - undergraduate major and institution, any graduate-level work, GPA, and optional GMAT or GRE scores - is a major factor in the admission decision. Other important areas of evaluation include a personal statement, work experience, letters of recommendation, writing skills, and extracurricular, community, and professional activities. From this overall review, we assess an applicant’s potential for success and compatibility with our MBA program.</br>
The average GPA of admitted candidates is 3.3. Ideally, a candidate’s GPA will be at 3.0 or above. Many circumstances may exist which offer an explanation for a GPA below 3.0; candidates are encouraged to submit a statement of explanation if this is the case. However, please note that an absolute minimum GPA of 2.5 is required for graduate admission at San José State University.</br>

## Program of Study Requirements for the MBA Degree
To earn the MBA degree, all students must satisfy the following requirements:</br>

### Business Prerequisite Courses

- Introduction of Macroeconomics (at SJSU this course is ECON 1A ) or Introduction to Microeconomics (at SJSU this course is ECON 1B ) or Principles of Economics</br>

- Statistics (at SJSU this course is BUS2 90 )</br>


### Advanced Management Courses (Core Courses)
In both the Early Career MBA and the MBA for Professionals, all students are required to successfully complete eleven core courses for a total of thirty-semester units. Although the total units of core courses are identical across the two MBA programs, the composition of the core curriculum is slightly different to account for the differences in student academic and professional profiles. The advanced graduate courses (core courses - 30 units) ensure breadth in general management knowledge and help the student to develop mastery in applying essential business skills.</br>

### Elective Courses
Four elective courses (12 units) are required of all students. As an elective course, a graduate student can select a maximum of one upper-division business undergraduate course (100-level) OR one graduate non-business course (200-level). Enrollment in such an elective course is conditional on the written approval by the MBA Director and it is specific to a given course and a given semester.</br>

### Comprehensive Project
The comprehensive project is incorporated in the Strategic Thinking course (BUS 290 ). The comprehensive project is a culminating experience integrating business functional areas and interdisciplinary perspectives. An individual written project report is required and an oral examination may be included. The project may take the form of a field study, research project, business simulation, or a strategic plan for an organization, as assigned by the Business 290 instructor. Students must receive an overall equivalent grade of “B” or better on the comprehensive project and may be given a maximum of two opportunities to satisfy requirements.</br>

### Graduation Writing Assessment Requirement
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

### Maintenance of 3.0 GPA
Students must maintain a grade point average of 3.0 or better on all graduate-level coursework. Students who receive grades of “C-“, “D”, “F”, or “WU” in any business graduate course must repeat that course to achieve a grade of “C” or better.</br>

### Transfer Credit
Subject to the approval of the Donald and Sally Lucas Graduate School of Business MBA Program Director and validation by the College of Graduate Studies, students may transfer a maximum of twelve-semester units of business graduate course work from another regionally accredited institution. Grades in the transfer courses must be “B” or better.</br>

### Other University Requirements
Students must comply with all other graduate requirements contained in this catalog. </br>

## Early Career MBA Requirements (42 units)

### Advanced Management Courses (Breadth Requirements) (27 units)

- BUS 201 - Business Communications 1 unit(s)</br>

- BUS 210 - Developing and Managing People 3 unit(s) (GWAR)</br>

- BUS 220 - Financial Accounting 3 unit(s)</br>

- BUS 230 - Marketing Management 3 unit(s)</br>

- BUS 250 - Law and Ethics 3 unit(s)</br>

- BUS 260 - Managerial Decision Analysis 3 unit(s)</br>

- BUS 265 - Silicon Valley Experience 2 unit(s)</br>

- BUS 270 - Financial Management 3 unit(s)</br>

- BUS 280 - Operations and Supply Chain Management 3 unit(s)</br>


#### Complete One Course From:

- BUS 202 - Managing in the Global Economy 3 unit(s)</br>

- BUS 244 - Information Technologies for Business: Essentials & Emerging 3 unit(s)</br>


### Electives (12 units)
Four elective courses. Students may take a maximum of one 100-level business course OR 200-level non-business course with written approval of the MBA director.</br>

### Culminating Experience (3 units)

#### Plan B (Project)

- BUS 290 - Strategic Thinking 3 unit(s)</br>


## Total Units Required (42 units)
 </br>