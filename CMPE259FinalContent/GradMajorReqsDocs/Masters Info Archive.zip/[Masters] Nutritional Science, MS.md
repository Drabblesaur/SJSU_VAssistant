
# Nutritional Science, MS
 </br>

- University Admissions</br>

- Requirements for Advancement to Candidacy for the MS - Nutritional Science</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Nutritional Science program is designed to meet the needs of the student who has a baccalaureate degree and seeks advanced preparation in nutrition science, nutrition education, geriatric nutrition, and foodservice/restaurant management. The program is intended to prepare candidates to assume leadership roles in their profession and communities and to provide the opportunity to acquire a foundation for doctoral study. Our MS graduates have earned doctorates, become college and university faculty, been employed in private, federal, and state research institutions, and have established their own private practice or consulting business. In the process of fulfilling requirements for the MS degree, it is possible to complete the academic requirements of the Academy of Nutrition and Dietetics (AND) and the Accreditation Council for Education in Nutrition and Dietetics (ACEND) toward becoming a registered dietitian. Courses are scheduled to accommodate the time needs of working graduate students.</br>
Additional information is available on the Department of Nutrition, Food Science and Packaging website.</br>

## University Admissions
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. See the Graduate Admissions website and Graduate Admissions  for general information about graduate admissions at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see English Language Proficiency Requirement .</br>

### Requirements for Admission to Classified Standing
Candidates must meet all the university admission requirements . Students can be admitted to the MS, Nutritional Science program in either classified or conditionally classified standing. All prospective students submit one application to obtain approval for university-level admission and department-level admission into the M.S. in Nutritional Science program. A departmental selection committee will rank applicants for admission to classified standing on the basis of information provided in the application. Criteria include:</br>

-  BS degree in Nutritional Science, Food Science, Food Management, or equivalent</br>

- Grade point average of B.S. upper division coursework</br>

-  Grade point average of prerequisite science courses as described in the MS, Nutritional Science graduate handbook</br>

- GRE scores</br>

- Letter of intent</br>

- Letter of recommendations</br>

-  Research and professional experience</br>


### Requirements for Admission to Conditionally Classified Standing
Students seeking an MS, Nutritional Science degree who meet requirements for admission to the Graduate Division, but do not have a B.S. degree in Nutritional Science, Food Science, Foodservice Management, or equivalent, may apply for conditionally classified standing in the department. The decision to accept the student for study in this program will be made by a departmental selection committee. Criteria include:</br>

- BA or BS degree</br>

- Grade point average of B.S. or B.A. upper division coursework</br>

- Number of prerequisite course requirements completed and grade point average. Course requirements described in the MS, Nutritional Science graduate handbook.</br>

- GRE scores</br>

- Letter of intent</br>

- Letter of recommendations</br>

- Research and professional experience</br>


## Requirements for Advancement to Candidacy for the MS - Nutritional Science
Prior to registering for the first time (or upon re-entering), a student should consult with the Graduate Coordinator to develop a schedule of courses. Advancement to candidacy  for the Master’s degree in Nutritional Science requires favorable action of the Graduate Committee of the Department of Nutrition, Food Science and Packaging and of the university’s Office of Graduate Admissions & Program Evaluations (GAPE). In general, students will be recommended for candidacy when they:</br>

- Fulfill all university requirements for advancement to candidacy.</br>

- Attain classified graduate standing</br>

- Complete a minimum of 9 units of letter-graded approved courses.</br>

- Earn a minimum 3.0 grade point average in all classes listed on the candidacy form.</br>

- Successfully complete NUFS 217  with at least a “C” to meet the Graduation Writing Assessment Requirement (GWAR) .</br>

- Select a graduate advisor and thesis or project topic.</br>


## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### MS - Nutritional Science Graduation Requirements
Completion of 30 units of approved coursework including the core courses. Maintenance of a 3.0 GPA is necessary.  Completion of the culminating experience of such scope and manner as determined by the student’s graduate committee. The program consists of 30 semester units of approved work, including 6 units of Plan A (Thesis) or 3 units of Plan B (Project or Comprehensive Exam).</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Plan A (Thesis)</br>
For this plan, the student is required to complete 6 units of  NUFS 299 - Master’s Thesis . The student is required to complete a research project under advisement of a Nutrition, Food Science and Packaging faculty. The research must result in the generation of a thesis that meets the University Master’s Thesis and Doctoral Dissertation Guidelines. The student must pass an oral examination defending the research to a departmental faculty committee. The student must prepare an oral presentation or poster presentation for the public. </br>
Plan B (Project)</br>
For this plan, the student is required to complete 3 units of  NUFS 298 - Special Studies in Nutrition, Food Science and Packaging  and submit a written project in publication format. The student must pass an oral examination defending the research to a departmental faculty committee.  The student must prepare an oral presentation or poster presentation for the public, community partner, or industry.</br>
Plan B (Comprehensive Exam)</br>
For this plan, the student is required to complete 3 units of  NUFS 298 - Special Studies in Nutrition, Food Science and Packaging . All graduate students opting for the courses-only option must pass the Comprehensive Exam (given once a semester) to earn the MS in Nutritional Science degree. The Comprehensive Exam is the student’s opportunity to demonstrate mastery and integration of the knowledge and skills of the MS in Nutritional Science curriculum. The comprehensive exam is an oral and a written exam administered on campus.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- NUFS 201 - Colloquium in Nutrition, Food Science and Packaging 3 unit(s)</br>

- NUFS 217 - Issues in Nutrition, Food and Packaging 3 unit(s) (GWAR)</br>

- NUFS 257 - Biostatistics in Research 3 unit(s)</br>

- NUFS 295A - Research Methodology 3 unit(s)</br>


#### Complete one course:

- NUFS 219A - Advanced Nutrition and Metabolism 3 unit(s)</br>

- NUFS 219B - Seminar in Advanced Topics in Human Nutrition & Dietetics 3 unit(s)</br>

- NUFS 242 - Advanced Foodservice/Restaurant Management 3 unit(s)</br>

- NUFS 243 - Nutrition and Dietetics Leadership 3 unit(s)</br>

- PKG 270 - Package Design for End Use 3 unit(s)</br>


### Specialization Area (9-12 units)
9-12 units electives selected in consultation with the graduate advisor</br>

### Culminating Experience (3-6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Complete Plan A (Thesis) or Plan B (Project)</br>

#### Plan A (Thesis) (6 units)

- NUFS 299 - Master’s Thesis 1-6 unit(s)</br>


#### Plan B (Project) (3 units)

- NUFS 298 - Special Studies in Nutrition, Food Science and Packaging 1-6 unit(s) (3 units required)</br>


#### Plan B (Comprehensive Exam) (3 units)

- NUFS 298 - Special Studies in Nutrition, Food Science and Packaging 1-6 unit(s) (3 units required)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 9.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>