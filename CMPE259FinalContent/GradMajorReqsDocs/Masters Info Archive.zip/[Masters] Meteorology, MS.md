
# Meteorology, MS
 </br>

- Admission Requirements</br>

- Requirements for Advancement to Candidacy</br>

- Requirements for Graduation</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Meteorology prepares students for high-level professional responsibility, independent research, and continued graduate work in atmospheric science. Graduate-level theoretical and applied meteorology courses and a substantial research project lead to the preparation of the master’s thesis, the culmination of the degree plan of study. Departmental opportunities for financial support include research and teaching assistantships.</br>
The Department of Meteorology and Climate Science  has one of the most active research programs at SJSU. The meteorology faculty has a wide range of expertise and supports a broad range of research activity. Their areas of specialization include Weather Analysis and Forecasting, Fire Weather, Urban Meteorology and Air Pollution, Atmospheres of Other Planets, Tropical Meteorology, Radar and Satellite Remote Sensing, Cloud and Aerosol Physics, Atmospheric Dynamics, Meteorological Data Processing, Data Communications, and Data Acquisition and Display.</br>
Our graduates find employment in forecasting, research, consulting and media, and continue for the Ph.D. degree at top universities throughout the country. Department alumni include top scientists and forecasters in The National Oceanic and Atmospheric Administration (NOAA), the National Weather Service (NWS), the United States Air Force and Navy, NASA, various state and federal air pollution agencies, the aerospace industry, and aviation operations. Others of our alumni are university professors, high school and community college teachers, TV forecasters, meteorologists in the wind power, electric, gas and oil industries, science writers, and consultants for legal cases, air pollution problems and building design.</br>

## Admission Requirements
Applicants must submit a complete graduate application by applying through the CSU Cal State Apply system and meet all the university admission requirements. Applicants apply separately to the department to obtain admission into the MS, Meteorology program. See the Graduate Admissions website and this Catalog for general information about graduate admissions  at SJSU.</br>
Applicants from countries in which the native language is not English must achieve a minimum English-language proficiency test score as indicated on the Graduate Program Test Requirements webpage. For TOEFL Requirements, see the Policies and Procedures  section, Graduate and Post-Baccalaureate Information .</br>

### Requirements for Admission to Classified Standing
Students are admitted to the MS, Meteorology program in Classified or Conditional Standing. Admission to classified standing requires the following. Applicants must:</br>

- Possess the equivalent of an SJSU BS in Meteorology or, with the approval of the department graduate committee, a degree in physical science or mathematics. Students entering with degrees in other areas may be admitted to conditionally classified standing, and will be required to make up deficiencies (e.g., in meteorology and math) before enrolling in the core graduate classes.</br>

- Have earned a minimum GPA of 2.75 (on a scale of 0-4) in their BS degrees.</br>

- Submit Graduate Record Examination (GRE) scores. More information about the GRE can be found on the Graduate Program Test Requirements webpage.</br>


### Requirements for Admission to Conditionally Classified Standing
Those applicants who meet minimum requirements for graduate admission, but do not meet departmental requirements, may be admitted to conditionally classified standing on the approval of the department graduate committee. The individual admission notification will explain the required terms and conditions for attaining Classified standing. Resolving deficiencies usually involve the successful completion of undergraduate courses in meteorology courses and math. Upon completion of these courses, the student advances from conditional to classified standing via petition to Graduate Studies.</br>

## Requirements for Advancement to Candidacy
University requirements for advancement to candidacy  for the master’s degree are outlined in the Graduate Policies and Procedures  section. Competence in the general areas covered by METR 121A , METR 125 , either METR 60  or METR 171A  (Synoptic Meteorology, to be decided in consultation with the department graduate committee), and METR 100W  or METR 202 , must be demonstrated to the Department Graduate Committee prior to advancement to candidacy. This can be done by satisfactory completion of these courses (or their equivalent) with a minimum grade of “B” in each, or successful completion of a comprehensive written examination. Students should consult with the graduate advisor concerning these alternatives. A student admitted in classified standing may be advanced to candidacy after completion of the terms and conditions specified in the admission notification letter.</br>
The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. MS, Meteorology students are currently required to take METR 202  to satisfy this University requirement.</br>

## Requirements for Graduation

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures . Courses taken to meet the requirements for advancement to candidacy will not be counted as part of the MS program. All students must complete the Graduation Writing Assessment Requirement.</br>

### Graduation Writing Assessment Requirement
Students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students complete the Plan A (Thesis) as their MS, Meteorology degree program culminating experience. The Plan B (Project) option is only offered under exceptional circumstances and students may not choose it themselves.</br>
Plan A (Thesis)</br>
This option requires an acceptable written research thesis and a successful oral presentation of the thesis. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. Students in the thesis option enroll in one unit of METR 285  and two units of METR 299  in their final semester. Students who complete the METR 299  but not its associated thesis enroll in the 1290R until both are completed.</br>
Plan B (Project)</br>
The Project option is open to students who can demonstrate to the Departmental Graduate Committee that they possess adequate professional meteorological experience to substitute for the research thesis. It is only offered under exceptional circumstances and students may not choose it themselves. Students approved for the Plan B option will select a suitable topic in meteorology on which to prepare a carefully documented written report in consultation with the project advisor. They will enroll in one unit of METR 285  and an additional two units of METR 298 , Research in their final semester. Students who complete their final METR 298  but not its associated thesis enroll in the 1290R until both are completed.</br>

## Master’s Requirements (30 units)

### Core Courses (12 units)

- METR 202 - Research Methods in Meteorology 3 unit(s) (GWAR)</br>

- METR 205 - Advanced Atmospheric and Climate Dynamics 3 unit(s)</br>

- METR 215 - Advanced Physical Meteorology 3 unit(s)</br>

- METR 240 - Numerical Modeling 3 unit(s)</br>

- or METR 241 - Parameterization in NWP </br>

or METR 241 - Parameterization in NWP </br>

### Research (6 units)

- METR 298 - Research 1-4 unit(s) (At least 3 units of METR 298  in each of two semesters.)</br>


### Advanced Courses (3 units)

- METR 209 - Adv Fire Behavior 3 unit(s)</br>

- METR 280 - Recent Developments in Meteorology 1-3 unit(s)</br>


### Electives (6 units)
6 units of the following selected in consultation with the graduate advisor:</br>
Students may take 3 additional units of Advanced Courses as an elective. Students may also take approved elective(s) in physics, computer science, and/or mathematics. Elective units cannot include METR 285 , METR 298  or METR 299 .</br>

- METR 121B - Dynamic Meteorology 3 unit(s)</br>

- METR 123 - Advanced Climatology 3 unit(s)</br>

- METR 125 - Physical Meteorology 3 unit(s)</br>

- METR 130 - Boundary Layer Meteorology 3 unit(s)</br>

- METR 131 - Air Pollution Meteorology 3 unit(s)</br>

- METR 135 - The Global Carbon Cycle 3 unit(s)</br>

- METR 150 - Computers in Meteorology III 3 unit(s)</br>

- METR 155 - Remote Sensing 3 unit(s)</br>

- METR 163 - Meteorological Instrumentation 3 unit(s)</br>

- METR 164 - Introduction to Fire Weather 3 unit(s)</br>

- METR 165 - Mountain Meteorology 3 unit(s)</br>

- METR 172 - Mesoscale Meteorology 3 unit(s)</br>

- METR 173 - Global Climate Modeling 3 unit(s)</br>

- METR 185 - Special Topics 1-3 unit(s)</br>


### Culminating Experience (3 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
Students in this program complete a Plan A (Thesis)</br>

#### Plan A (Thesis)

- METR 285 - Colloquium 1 unit(s) (Minimum one unit)</br>

- METR 299 - Master’s Thesis 1-6 unit(s) (2 units METR 299  in the final semester)</br>


#### Plan B (Project)

- METR 285 - Colloquium 1 unit(s) (Minimum one unit)</br>

- METR 298 - Research 1-4 unit(s) (2 units METR 298  in the final semester)</br>


## Total Units Required (30 units)
Elective courses must be planned in consultation with the Graduate Advisor.</br>
The maximum number of upper-division undergraduate units that can be applied toward the master’s degree is 15.</br>
Upon completion of the degree requirements, the student must have achieved minimum candidacy and SJSU Cumulative grade point averages of 3.0 in order to graduate.</br>
 </br>