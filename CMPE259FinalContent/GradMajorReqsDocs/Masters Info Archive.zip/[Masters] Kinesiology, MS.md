
# Kinesiology, MS
 </br>

- Requirements for Admission to Classified Standing</br>

- Requirements for Admission to Conditionally Classified Standing</br>

- Requirements for Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The Master of Science in Kinesiology, offered by the Department of Kinesiology , includes five specializations. Our rapidly growing program regularly enrolls 70 to 90 students with varied interests, backgrounds, and goals. Our alumni successfully obtain jobs across the Bay Area, the state of California, the US, and abroad. In addition, the program has placed numerous students in top-tier doctoral programs across the US and Canada. Students are selected to the program based on undergraduate academic achievement and overall potential for success in the program, and in one of the following Graduate Specializations listed below. </br>
Graduate Coordinator: Dr. Cole Armstrong</br>

## Requirements for Admission to Classified Standing
The Department of Kinesiology requires the following of all applicants seeking admission to classified standing in the MS - Kinesiology program in addition to meeting requirements for admission to the Graduate Division:</br>

- A baccalaureate degree with a major or a minor in Kinesiology.</br>

- A minimum grade point average of 3.0 in the last 60 semester units (or 90 quarter units) of work.</br>

- A fully completed CSU Apply Application, including the Statement of Purpose on the application. Statement of purpose should include a thoughtful narrative about the applicant’s research interests, as the two core research methods courses necessitate that students think about their final culminating experiences upon acceptance into the program.</br>

- Two (2) letters of recommendation submitted with online application (or emailed directly to the Graduate Coordinator via verified work email).</br>


## Requirements for Admission to Conditionally Classified Standing
The graduate coordinator, in consultation with faculty, may approve admission of a student who meets the requirements for admission to the Graduate Division who:</br>

- satisfactory completion of a maximum of 12 units of upper-division foundation coursework assigned by the Graduate Coordinator or an assigned Academic Advisor. The number of foundation units are determined by the graduate coordinator based on an overall assessment of the applicant’s transcripts, experience, and overall portfolio. Foundation units may also be completed prior to entering the program (e.g., in the Spring semester prior to entering in the Fall).</br>

- 

completion of six units of graduate course work with a minimum grade point average of 3.0 in each course (if admitted with no foundation units and a GPA of below 3.0). 
</br>
completion of six units of graduate course work with a minimum grade point average of 3.0 in each course (if admitted with no foundation units and a GPA of below 3.0). </br>

## Requirements for Advancement to Candidacy
General university admission requirements  to candidacy for the Master of Science degree are outlined in detail in the Catalog. The University requires that all graduate students complete the Graduation Writing Assessment Requirement (GWAR)  as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.  Following are additional requirements of the Department of Kinesiology for the Master of Science degree.</br>
Upon admission to the Graduate Division and prior to registration, each student should meet with a graduate academic advisor in the student’s chosen specialization area. If there are any deficiencies in a student’s undergraduate work, additional upper-division undergraduate foundation courses (i.e., Foundation Courses) may be required. Foundation courses may not be counted for credit in the master’s program. If foundation units are required. additional upper-division KIN units will be assigned by the graduate advisor.</br>
A proposed program for the graduate objective selected should be developed as early as possible with the assistance of a graduate academic advisor in the student’s specialization area.</br>
The proposed program must be approved by the graduate advisor, the graduate coordinator, and the Office of Graduate Studies before the student is considered a candidate for the Master of Science degree.</br>

## Graduation Requirements

### University Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies and Procedures .</br>

### Graduation Writing Assessment Requirement
At SJSU, students must pass the Graduation Writing Assessment Requirement (GWAR) .  In Kinesiology, students must pass either KIN 250  or KIN 251  with a grade of B or better to satisfy this requirement.</br>

### Culminating Experience
Plan A (Master’s with Thesis)</br>
The purpose of this plan is to provide research-focused concentrated study in one of the subdisciplinary areas of Kinesiology. It is crucial that students electing Plan A identify the focus of their specialization early so that an appropriate thesis topic may be developed and a thesis committee selected. (6 units)</br>
Plan B (Master’s - Culminating Project)</br>
This plan is for students interested in producing a research-based creative project in Kinesiology. The plan requires a special project in place of a thesis. (3 units)</br>

## Master’s Requirements (30 units)
A minimum of 15 units must be 200-level courses. All specializations require KIN 250   (GWAR) and KIN 251  (GWAR).</br>

### Required Core Courses (6 units)

- KIN 250 - Fundamentals of Quantitative Research 3 unit(s) (GWAR)</br>

- KIN 251 - Fundamentals of Qualitative Research 3 unit(s) (GWAR)</br>


### Specializations (18 units)

#### Individualized
The M.S. in Kinesiology Individualized specialization is designed to accommodate students who desire an interdisciplinary program of study in Kinesiology. Students work directly with their academic advisor to select a set of courses that will aid them in meeting their specific academic goals. This pathway to the masters degree may be of interest to students needing considerable flexibility in designing a program of study to facilitate pursuit of an advanced degree (e.g., PhD) or a specific career which may require knowledge from multiple specializations within the M.S. in Kinesiology program. All coursework beyond the core courses (i.e., KIN 250 and KIN 251) must be selected in consultation with the student’s academic advisor and is expected to form a coherent program of study that meets the student’s personal and professional goals while also conforming to the requirements of a graduate degree at SJSU.</br>
Electives to be determined in consultation with an assigned advisor.</br>

#### Exercise Physiology
The Exercise Physiology specialization helps prepare students to meet societal challenges for health and wellness. This area of study provides an advanced theoretical and research background in exercise physiology, as well as hands-on experience gained through a required internship. There are 3 areas of focus in the exercise physiology graduate program: General Exercise Physiology, Clinical Exercise Physiology, and Strength & Conditioning.</br>

- KIN 255 - Advanced Exercise Physiology 3 unit(s)</br>

- KIN 256 - Environmental Exercise Physiology 3 unit(s)</br>

- KIN 285 - Internship in Kinesiology 1-3 unit(s)</br>

- KIN 152 - Theory of Sport and Fitness Management 3 unit(s)</br>

- KIN 154B - ECG Interpretations and “Graded” Exercise Testing 3 unit(s)</br>

- KIN 157 - Physiological Assessment 3 unit(s)</br>

- KIN 162 - Advanced Fitness Assessment and Exercise Prescription 3 unit(s) (Fall only)</br>

- KIN 168 - Psychology of Coaching 3 unit(s)</br>

- KIN 187 - Clinical Exercise Physiology 3 unit(s)</br>

- KIN 188 - Prevention and Care of Athletic Injuries 2 unit(s) and KIN 189 - Prevention and Care of Athletic Injuries Laboratory  (Lecture/Lab)</br>

- KIN 257 - Biomechanics 3 unit(s)</br>

- KIN 265 - Advanced Motor Development 3 unit(s)</br>

- KIN 266 - Principles and Concepts of Perceptual Motor Learning 3 unit(s)</br>

- KIN 267 - Advanced Sport Psychology 3 unit(s)</br>

- KIN 285 - Internship in Kinesiology 1-3 unit(s)</br>

- BIOL 124 - Systems Physiology 3 unit(s)</br>

- BIOL 131 - Endocrine Physiology 3 unit(s)</br>

- NUFS 108A - Nutrition and Metabolism 3 unit(s)</br>

- NUFS 123 - Nutrition for Sport 3 unit(s)</br>

- Other - Advisor Approval Required</br>

Other - Advisor Approval Required</br>

#### Movement Science
The graduate concentration in Movement Science provides advanced training on human movement analysis from biomechanical, neuromotor control, developmental and learning perspectives as they apply in various sport and physical activity settings. The focus of the Movement Science program specifically includes an interdisciplinary and integrative approach among motor development, motor learning, and biomechanics. Students learn to develop a specific set of skills to apply across various applications in academia, healthcare, and industry, as well as pursue further training at the doctoral level. Specifically, theoretical and practical research training ensures that graduate students have knowledge and skills to analyze human movement using new technologies in industry and applied healthcare.</br>

- KIN 257 - Biomechanics 3 unit(s)</br>

- KIN 265 - Advanced Motor Development 3 unit(s)</br>

- KIN 266 - Principles and Concepts of Perceptual Motor Learning 3 unit(s)</br>

- KIN 154B - ECG Interpretations and “Graded” Exercise Testing 3 unit(s)</br>

- KIN 157 - Physiological Assessment 3 unit(s)</br>

- KIN 162 - Advanced Fitness Assessment and Exercise Prescription 3 unit(s) (Fall only)</br>

- KIN 168 - Psychology of Coaching 3 unit(s)</br>

- KIN 187 - Clinical Exercise Physiology 3 unit(s)</br>

- KIN 255 - Advanced Exercise Physiology 3 unit(s) (Fall only)</br>

- KIN 256 - Environmental Exercise Physiology 3 unit(s) (Spring only)</br>

- KIN 267 - Advanced Sport Psychology 3 unit(s)</br>

- KIN 285 - Internship in Kinesiology 1-3 unit(s)</br>

- BME 177 - Physiology for Engineers 3 unit(s)</br>

- BME 207 - Experimental Methods in BME 3 unit(s)</br>

- ME 267 - Engineering Biomechanics 3 unit(s)</br>

- PSYC 129 - Neuroscience 3 unit(s)</br>

- PSYC 135 - Cognition 3 unit(s)</br>

- PSYC 155 - Human Learning 3 unit(s)</br>

- PSYC 160 - Clinical Psychology 3 unit(s)</br>

- Other - Advisor Approval Required</br>

Other - Advisor Approval Required</br>

#### Sport Management
The focus of the Sport Management specialization is to develop culturally informed professionals capable of management and leadership across the many sport industry professions. In addition, the balance between applied research and practical experiences ensures that our graduates have a deep and transferable knowledge base as they enter the job market, as well as potentially influencing sport scholarship by pursuing higher levels of education.</br>

- KIN 280 - Advanced Fieldwork in Sport Management 1-3 unit(s)</br>

- KIN 281 - Legal and Ethical Aspects of Sport 3 unit(s)</br>

- KIN 282 - Marketing and Social Aspects of Sport 3 unit(s)</br>

- KIN 283 - Management, Leadership and Communication in Sport 3 unit(s)</br>

- KIN 284 - Financial Aspects of Sport 3 unit(s)</br>

- KIN 151 - Sports and Fitness Marketing 3 unit(s)</br>

- KIN 152 - Theory of Sport and Fitness Management 3 unit(s)</br>

- KIN 153 - Sport Facility and Event Management 3 unit(s)</br>

- KIN 164 - Sociocultural Perspectives 3 unit(s)</br>

- KIN 168 - Psychology of Coaching 3 unit(s)</br>

- KIN 263 - International Sport and Physical Education 3 unit(s)</br>

- KIN 264 - Sport Sociology 3 unit(s)</br>

- AFAM 105 - Race and Health Inequities in the US 3 unit(s)</br>

- AFAM 106 - Black Diasporas 3 unit(s)</br>

- AFAM 115 - The Great Migration and Black Communities 3 unit(s)</br>

- AFAM 151 - Race, Class and the Environment 3 unit(s)</br>

- AFAM 158 - Race, Sport, Activism & Social Movements 3 unit(s)</br>

- AFAM 162 - The Aesthetics of Hip-Hop 3 unit(s)</br>

- BUS2 130 - Introduction to Marketing 3 unit(s)</br>

- MCOM 105 - Lifestyles, Diversity and the Media 3 unit(s)</br>

- MCOM 107 - Audio Podcasting, Aesthetics and Invention 3 unit(s)</br>

- Other - Advisor Approval Required</br>

Other - Advisor Approval Required</br>

#### Psychosocial Aspects of Sport and Physical Activity
The specialization in Psychosocial Aspects of Sport and Physical Activity encompasses a variety of approaches to the study of sport and the body and comprises theories and research methodologies from psychology, sociology, history, philosophy, and cultural studies of sport. Two areas of focus in this specialization include sport and exercise psychology, and critical sport studies. Coaches, students interested in sport and exercise psychology and/or critical social issues in sport, and individuals wishing to pursue advanced degrees in sport and exercise psychology or sport sociology/critical sport studies would benefit from this specialization.</br>

- KIN 264 - Sport Sociology 3 unit(s)</br>

- KIN 267 - Advanced Sport Psychology 3 unit(s)</br>

- KIN 156 - Introduction to Adapted Physical Activity 3 unit(s)</br>

- KIN 164 - Sociocultural Perspectives 3 unit(s)</br>

- KIN 167 - Sports Psychology 3 unit(s)</br>

- KIN 168 - Psychology of Coaching 3 unit(s)</br>

- KIN 176 - Exercise Psychology 3 unit(s)</br>

- KIN 260 - Philosophy of Sport and Embodiment 3 unit(s)</br>

- KIN 263 - International Sport and Physical Education 3 unit(s)</br>

- EDCO 218 - Counseling Process & Techniques 3 unit(s)</br>

- PSYC 135 - Cognition 3 unit(s)</br>

- PSYC 160 - Clinical Psychology 3 unit(s)</br>

- PSYC 165 - Theory and Methods of Counseling 3 unit(s)</br>

- PSYC 210 - Advanced Psychopathology 3 unit(s)</br>

- SOCI 164 - Social Action 3 unit(s)</br>

- SOCI 172 - Lesbian, Gay, Bi, Transgender Studies 3 unit(s)</br>

- SOCI 175 - Sociology of Masculinities and Femininities 3 unit(s)</br>

- WGSS 169 - Sexualities and the Body 3 unit(s)</br>

- Other - Advisor Approval Required</br>

Other - Advisor Approval Required</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>
An oral defense is required with both Thesis and Project.</br>

#### Plan A (Thesis) (6 units)

- KIN 299 - Master’s Thesis 1-6 unit(s)</br>


#### Plan B (Project) (6 units)

- KIN 298 - Special Studies 3 unit(s)</br>

- 3 additional units of electives selected in consultation with graduate advisor</br>

3 additional units of electives selected in consultation with graduate advisor</br>

## Total Units Required (30 units)
 </br>