
# Materials Engineering, MS
 </br>

- Requirements for Admission</br>

- Requirements for Candidacy</br>

- Major Requirements</br>

- Master’s Requirements (30 units)</br>

- Program Learning Outcomes  </br>

The MS Materials Engineering program is offered by the Department of Chemical and Materials Engineering . The program provides advanced study of materials engineering topics with an emphasis on both the fundamental and applied aspects. A multidisciplinary approach to education is evident in the materials engineering program’s specialization areas of semiconductor processing, polymers, ceramics, structural materials, and biomaterials. Elective courses are also available in science, business, and other engineering fields. This broad-based, multi-disciplinary educational program has proven to be an important factor for a student’s future success including leading Silicon Valley companies and in Ph.D. programs. Class schedules are designed for the convenience of employed engineers who wish to pursue graduate work on a part-time basis.</br>
Faculty are actively involved in research areas including electronic and magnetic materials, nanomaterials, energy materials, structural materials, computations, polymers, composites, and biomaterials. Research activity is sponsored by local industries as well as by government funding agencies.</br>
The MS Materials Engineering program welcomes students with undergraduate degrees in Materials Engineering or related science (biology, chemistry, physics) or engineering (chemical, electrical, biomedical, mechanical) degrees</br>
Department Website: www.sjsu.edu/cme
Department Email: chemical-materials-engineering@sjsu.edu</br>

## Requirements for Admission
Students can be admitted with conditionally classified standing if they have a MATE degree from a US accredited university in which they obtained a 2.7-2.99 GPA in the last 60 units; a MATE degree from a non-US institution; or if they have a BS degree in a related discipline, such as chemical engineering, chemistry, biology, or physics from an accredited institution. Students with conditionally classified standing will take a series of transition courses. Once these are completed satisfactorily, students can petition from classified standing. For more information on the transition courses, see the department website.</br>

## Requirements for Candidacy
Students must meet the university requirements for candidacy  which includes successful completion of the Graduation Writing Assessment Requirement (GWAR) . The University requires that all graduate students meet the Graduation Writing Assessment Requirement as a condition for advancement to candidacy. Courses that satisfy the GWAR are listed in the course requirements for the program.</br>

## Major Requirements
To meet the requirements for the MS - Materials Engineering degree, a student must complete 30 units of approved courses. Students must achieve a minimum of a “C” in each course and a cumulative GPA of 3.0 or better. Students should select a Culminating Experience in consultation with their SJSU research advisor, and a written thesis or project report and an oral defense of their thesis or project must be completed. </br>

### Graduation Writing Assessment Requirement
Students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

### Culminating Experience
Students in the MS, Chemical Engineering program will complete MATE 280 /MATE 280I  and MATE 281  and may complete 1-unit of MATE 298 /MATE 298I  or MATE 299 /MATE 299I  through their choice of a graduate project or master’s thesis, respectively.</br>
Thesis Requirements</br>
Students opting to complete a master’s thesis are responsible for securing the commitment of a full-time tenured or tenure-track faculty member who agrees to serve as the thesis committee chair. The student must also secure the commitments of two additional committee members, one of whom must be a full or part-time SJSU faculty member, to serve as the student’s thesis committee. If the student is completing their thesis research off-site, then one person of their thesis committee must be at least a supervisor-level employee from that off-site facility. The student must write a thesis proposal and have it approved by the thesis committee in order to pass MATE 281 . MATE 299  is taken in the semester the student expects to complete their final oral and written defense which will serve as their culminating experience. The MS candidate must successfully pass an oral defense and complete an approved thesis report in order to receive credit for MATE 299 . Students must be enrolled in courses every semester with the exception of an approved leave of absence for one semester. Students who have finished all their 30 units with the exception of an RP grade in MATE 299  are eligible for enrollment in CHE 1290R  for a reduced tuition fee. The thesis must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It will be written under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>
Project Requirements</br>
Students opting to complete a graduate project are responsible for securing the commitment of a full-time tenured or tenure-track faculty member who agrees to serve as the project committee chair. The student must also secure the commitments of an additional committee member to serve as the student’s project committee. If the student is completing their thesis project research off-site, then one person of their project committee must be at least a supervisor-level employee from that off-site facility. The student must write a project proposal and have it approved by the project committee in order to pass MATE 281 . MATE 298  is taken in the semester the student expects to complete their final oral defense and written project report, which will serve as their culminating experience. The MS candidate must successfully pass an oral and defense and complete an approved written project report in order to receive credit for MATE 298 . Students must be enrolled in courses every semester with the exception of an approved leave of absence for one semester. Students who have finished all their 30 units with the exception of an RP grade in MATE 298  are eligible for enrollment in CHE 1290R  for a reduced tuition fee.</br>

## Master’s Requirements (30 units)

### Core Courses (15 units)

- CHE 200 - Research Methods 3 unit(s) (GWAR)</br>

- MATE 205 - Advanced Mechanical Behavior of Solids 3 unit(s)</br>

- MATE 215 - Solid State Materials Engineering 3 unit(s)</br>

- MATE 241 - Advanced Methods of Materials Characterization 3 unit(s)</br>

- MATE 251 - Advanced Solid State Thermodynamics 3 unit(s)</br>


### Approved Electives (9 units)
9 units of electives selected in consultation with a graduate advisor. At least one technical elective needs to be an approved 200-level course.</br>
 Only students who are doing research on campus may be eligible for MATE 282 . MATE 282 may be taken 2 times for a maximum of 6 units of technical elective credit. Only one section of MATE 280 /MATE 280I /MATE 282  may be taken per semester.</br>

### Culminating Experience (6 units)
Program departments are required to certify when Plan A or Plan B has been completed satisfactorily via the Verification of Culminating Experience form.</br>

- ​MATE 281 - MS Thesis/Project Preparation Seminar  3 unit(s)</br>

- MATE 280 - Graduate Research  OR MATE 280I - Graduate Research Internship  2 unit(s)</br>

Complete one course for 1 unit:</br>

- MATE 298 - MS Research/Project 1-2 unit(s)</br>

- MATE 298I - Master’s Project Internship 1-2 unit(s)</br>

- MATE 299 - Master’s Thesis 1-3 unit(s)</br>

- MATE 299I - Master’s Thesis Internship 1-3 unit(s)</br>


## Total Units Required (30 units)
 </br>