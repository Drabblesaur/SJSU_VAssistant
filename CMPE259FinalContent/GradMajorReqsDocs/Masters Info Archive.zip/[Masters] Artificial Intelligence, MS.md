
# Artificial Intelligence, MS
 </br>

- Admissions Requirements </br>

- Advancement to Candidacy</br>

- Graduation Requirements</br>

- Master’s Requirements (33 units)</br>

- Program Learning Outcomes  </br>

MS in Artificial Intelligence program provides students with a state-of-the-art educational experience to become outstanding, socially responsible engineers of AI systems. Students will learn the theoretical foundations and gain practical skills to manage and engineer various data forms, to make predictive analyses, to derive actionable insights, and develop intelligent hardware and software systems and related cutting-edge AI technologies. The program will draw on insights from mathematics, statistical analysis, computer science, software engineering, and systems engineering and is, therefore, best suited for students with software/computer engineering, computer science, mathematics, and closely related backgrounds.</br>
The program offers specializations in Data Science and Autonomous Systems.</br>
Visit the program website at https://www.sjsu.edu/cmpe/academic/ms-ai/​. </br>

## Admission Requirements
Candidates must meet all university admission requirements . Applicants can be admitted in either classified or conditionally classified standing. If an applicant’s preparation for advanced graduate work is considered inadequate to meet the course prerequisites or other departmental requirements, the conditions will include taking preparatory courses to meet these requirements. These courses will not count as part of the master’s degree program requirements.</br>
For acceptance by the Department of Computer Engineering , the applicant must satisfy the following requirements:</br>

- Undergraduate degree in math, physics, computer science, engineering, or a closely related field, equivalent to a four-year U.S. undergraduate baccalaureate degree, with demonstrated college-level courses in programming, data structures, algorithm design, three-semester sequence of calculus, linear algebra and statistics.</br>

- Undergraduate GPA of 3.0 or higher.</br>

- If the undergraduate program is not ABET-accredited, GRE is required with a minimum GRE q+v of 305 and GRE AWA of 3.0. GRE q+v minimum higher than 305 may be required for successful admission depending on the number of applicants.</br>

- International applicants must meet SJSU’s minimum requirements on English-language proficiency tests.</br>


## Advancement to Candidacy
Students may advance to candidacy  after completing all admission conditions and all prerequisites for the culminating experience including the Graduation Writing Assessment Requirement (GWAR) .</br>

## Graduation Requirements
Students must complete all residency, curriculum, unit, GPA, and culminating experience requirements as outlined in the Graduation Requirements  section of the Graduate Policies & Procedures .</br>

## Master’s Requirements (33 units)

### Core Courses (9 units)

- CMPE 252 - Artificial Intelligence and Data Engineering 3 unit(s)</br>

- CMPE 257 - Machine Learning 3 unit(s)</br>

- ISE 201 - Math Foundations for Decision and Data Sciences 3 unit(s)</br>


### Specialization Courses (6 units)
Complete at least 6 units from the same specialization.</br>

#### Data Science (at least 6 units)

- CMPE 255 - Data Mining 3 unit(s)</br>

- CMPE 256 - Recommender Systems 3 unit(s)</br>

- CMPE 259 - Natural Language Processing 3 unit(s)</br>


#### Autonomous Systems (at least 6 units)

- CMPE 249 - Intelligent Autonomous Systems 3 unit(s)</br>

- CMPE 258 - Deep Learning 3 unit(s)</br>

- CMPE 260 - Reinforcement Learning 3 unit(s)</br>


### Elective Courses (9 units)
Select 3 courses (9 units) from the list below. At least 3 units need to be from Area A course list. The remaining 6 units can be selected from either list.</br>

#### Area A (at least 3 units)

- CMPE 249 - Intelligent Autonomous Systems 3 unit(s)</br>

- CMPE 255 - Data Mining 3 unit(s)</br>

- CMPE 256 - Recommender Systems 3 unit(s)</br>

- CMPE 258 - Deep Learning 3 unit(s)</br>

- CMPE 259 - Natural Language Processing 3 unit(s)</br>

- CMPE 260 - Reinforcement Learning 3 unit(s)</br>


#### Area B (up to 6 units)
For the most updated list of approved Area B technical electives please refer to the MS AI home page (https://www.sjsu.edu/cmpe/academic/ms-ai/msaiprogram-requirements.php). Courses not listed as approved Area B technical electives need prior approval from the MS AI program coordinator.</br>

### Graduate Writing Requirement (3 units)
Students must pass the Graduation Writing Assessment Requirement (GWAR) .</br>

- CMPE 294 - Computer Engineering Seminar 3 unit(s) (GWAR) (recommended)</br>

- ENGR 200W - Engineering Reports and Graduate Research 3 unit(s)</br>


### Culminating Experience (6 units)
All students must complete one of the following culminating experiences: thesis or project. Theses and projects are completed under the supervision of an advisor.</br>
Plan A (Thesis)</br>
A master’s thesis includes original research on a topic approved by the thesis committee and must meet university requirements as stipulated in this catalog and in the SJSU Master’s Thesis and Doctoral Dissertation Guidelines. It undergoes a thorough review and revision process under the guidance of the candidate’s thesis committee chair with the assistance of the thesis committee.</br>

- CMPE 299A - Master Thesis I    </br>

- CMPE 299B - Master Thesis II   </br>

Plan B (Project)</br>
A master’s project is a research or development effort performed by a student individually on a topic chosen by mutual agreement between an advisor and the student. The choice of project topic is also approved by the Graduate Advisor. The individual student projects could be distinct components of a larger integrated project performed by a team of students. Students complete CMPE 295A  and CMPE 295B . At the end of CMPE 295B , a project report is submitted for department review, and students present their project work in a department project exposition. </br>

## Total Units Required (33 units)
 </br>